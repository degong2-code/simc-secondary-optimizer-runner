#!/usr/bin/env python3
"""v015 bounded, evidence-pinned adaptive CHMV pilot; no global-optimum claim.

Reuses v013 and v014 independent real JSON2 (seven unique vectors). Performs up to
three sequential exploratory runs and two fresh higher-iteration confirmations.
Only the virtual 3000 budget pilot is executable; real-item feasibility is NOT
inferred from an unconstrained rating split. Offline plan mode never runs SimC.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import math
import os
import subprocess
import sys
import uuid
import zipfile
from pathlib import Path

import CHMV_PILOT_OPTIMIZER_v014 as legacy

HERE=Path(__file__).resolve().parent
SOURCE_014=HERE/'EVIDENCE'/'M0_CHMV_EXPLORATION_v014.zip'
SOURCE_014_SHA='c834da579d059b2239b2706779cd873d195f9b62634fe240da4424f9e88f9593'
BINARY_SHA=legacy.BINARY_SHA
BUDGET=legacy.BUDGET
STATS=legacy.STATS
SOURCE_C_INPUT_SHA=legacy.SOURCE_C_INPUT_SHA
SAMPLE_ACTOR='MID2_Mage_Arcane_Spellslinger'
SOURCE_FLASK_OFFSET=legacy.FLASK_OFFSET
DEFAULT_SIMC=legacy.DEFAULT_SIMC
MAX_WALL_SECONDS=1200
MAX_JSON_BYTES=50_000_000
DEFAULT_SETTINGS={
 'schema':'CHMVAdaptivePilotSettings-v015',
 'optimization_mode':'VIRTUAL_FIXED_BUDGET_PILOT',
 'test_profile':'MID2_Mage_Arcane_Spellslinger_SAMPLE_NOT_USER',
 'gear_rating_budget':3000,
 'rating_step':200,
 'scout_runs':3,
 'scout_iterations':1000,
 'confirmation_runs':2,
 'confirmation_iterations':3000,
 'thread_limit':1,
 'desired_targets':1,
 'fixed_time':1,
 'max_time':60,
 'vary_combat_length':0,
 'rating_min':{'crit':0,'haste':0,'mastery':0,'versatility':0},
 'rating_max':{'crit':3000,'haste':3000,'mastery':3000,'versatility':3000},
 'consumables_quality_policy':'HIGHEST_QUALITY_WHEN_VERIFIED_SAMPLE_GEMS_CRAFTED_UNVERIFIED',
 'max_total_new_iterations':9000,
}


def need(condition,reason):
 if not condition:raise ValueError(reason)


def sha(b):return hashlib.sha256(b).hexdigest()
def sha_file(path):return legacy.sha_file(path)
def read_json(data):return legacy.read_json(data)
def save_json(path,obj):return legacy.save_json(path,obj)
def vector_from_result(r):return tuple(r['raw_gear_rating'][k] for k in STATS)

def load_settings(path=None):
 doc=DEFAULT_SETTINGS.copy() if path is None else read_json(Path(path).read_bytes())
 need(set(doc)==set(DEFAULT_SETTINGS),'SETTINGS_KEYS_CHANGED')
 for key,val in DEFAULT_SETTINGS.items():
  if key in ('scout_runs','confirmation_iterations','rating_step','max_total_new_iterations'):
   continue
  if key=='rating_min' or key=='rating_max':
   need(isinstance(doc[key],dict) and set(doc[key])==set(STATS),'INVALID_RATING_BOUND')
   for st in STATS:need(type(doc[key][st]) is int and 0<=doc[key][st]<=3000,'INVALID_RATING_BOUND')
  else:
   need(type(doc[key])==type(val) and doc[key]==val,'UNSUPPORTED_SETTINGS_CHANGE:'+key)
 need(type(doc['rating_step']) is int and doc['rating_step'] in (100,200),'INVALID_RATING_STEP')
 need(type(doc['scout_runs']) is int and 1<=doc['scout_runs']<=3,'SCOUT_RUN_CAP_EXCEEDED')
 need(type(doc['confirmation_iterations']) is int and 1000<=doc['confirmation_iterations']<=4000,'CONFIRMATION_ITERATION_CAP_EXCEEDED')
 need(type(doc['max_total_new_iterations']) is int and 3000<=doc['max_total_new_iterations']<=11000,'TOTAL_ITERATION_CAP_INVALID')
 need(doc['scout_runs']*doc['scout_iterations']+doc['confirmation_runs']*doc['confirmation_iterations']<=doc['max_total_new_iterations'],'ITERATION_BUDGET_EXCEEDED')
 for st in STATS:need(doc['rating_min'][st]<=doc['rating_max'][st],'RATING_MIN_EXCEEDS_MAX')
 return doc


def verify_index(zip_handle):
 names=zip_handle.namelist()
 canonical=[s.replace('\\','/') for s in names]
 need(len(canonical)==len(set(canonical)),'DUPLICATE_CANONICAL_ZIP_PATH')
 index=read_json(legacy.archive_bytes(zip_handle,'file_index.json'))
 items=index['entries']
 need(len(items)==len(canonical)-1,'INDEX_ENTRY_COUNT_MISMATCH')
 need(set(canonical)-{'file_index.json'}=={e['path'] for e in items},'INDEX_PATH_SET_MISMATCH')
 for e in items:
  blob=legacy.archive_bytes(zip_handle,e['path'])
  need(len(blob)==e['size'] and sha(blob)==e['sha256'],'EVIDENCE_FILE_HASH_OR_SIZE_MISMATCH:'+e['path'])


def load_evidence():
 need(sha_file(SOURCE_014)==SOURCE_014_SHA,'V014_REAL_ARCHIVE_SHA_CHANGED')
 source, anchor=legacy.evidence()
 observed={vector_from_result(r):[r] for r in anchor.values()}
 case_by_vector={vector_from_result(r):key for key,r in anchor.items()}
 with zipfile.ZipFile(SOURCE_014) as z:
  need(z.testzip() is None,'V014_ZIP_CRC_ERROR')
  verify_index(z)
  receipt=read_json(legacy.archive_bytes(z,'chmv_exploration_receipt_v014.json'))
  need(receipt['status']=='PASS_FOUR_EXPLORATORY_SIMC_RUNS','V014_ORIGIN_NOT_PASS')
  need(receipt['binary_sha256']==BINARY_SHA and receipt['source_sha256']==legacy.SOURCE_SHA,'V014_IDENTITY_MISMATCH')
  need(set(receipt['completed_results'])==set(legacy.EXPLORATION),'V014_CASE_LIST_MISMATCH')
  for case,vec in legacy.EXPLORATION.items():
   doc=read_json(legacy.archive_bytes(z,f'{case}/result.json'))
   record=legacy.parse_result(doc,vec,case)
   raw=legacy.archive_bytes(z,f'{case}/input.simc')
   need(sha(raw)==receipt['completed_results'][case]['input_sha256'],'V014_INPUT_SHA_MISMATCH:'+case)
   need(sha(legacy.archive_bytes(z,f'{case}/result.json'))==receipt['completed_results'][case]['result_sha256'],'V014_JSON2_SHA_MISMATCH:'+case)
   need(abs(record['dps_mean']-receipt['completed_results'][case]['dps_mean'])<1e-5,'V014_RECEIPT_DPS_MISMATCH')
   need(vec not in observed,'HISTORICAL_DUPLICATE_VECTOR')
   observed[vec]=[record]
   case_by_vector[vec]=case
 need(len(observed)==7 and len(case_by_vector)==7,'HISTORICAL_CACHE_EXPECTS_7')
 return source,observed,case_by_vector


def boundaries_ok(vec,settings):
 return type(vec) is tuple and len(vec)==4 and all(type(x) is int for x in vec) and sum(vec)==BUDGET and all(settings['rating_min'][k]<=vec[i]<=settings['rating_max'][k] for i,k in enumerate(STATS))


def neighbors(anchor, settings, observed_vectors):
 step=settings['rating_step']; candidates=[]
 for source in range(4):
  for dest in range(4):
   if source==dest:continue
   v=list(anchor);v[source]-=step;v[dest]+=step;v=tuple(v)
   if boundaries_ok(v,settings) and v not in observed_vectors and v not in candidates:candidates.append(v)
 return candidates


def last_observation(records):return records[-1]

def leader(data):
 # No winner assertion: this only selects a search anchor based on raw mean.
 return max(data,key=lambda v:(last_observation(data[v])['dps_mean'],tuple(-x for x in v)))


def score_direction(anchor,v,data, step):
 # Mirrored-neighbor finite difference used to ORDER EXPERIMENTS ONLY.
 # No statistical claims are derived from this noisy local extrapolation.
 mirror=tuple(2*a-b for a,b in zip(anchor,v))
 if mirror in data:
  return max(-2500.0,min(2500.0,last_observation(data[anchor])['dps_mean']-last_observation(data[mirror])['dps_mean']))
 return 0.0


def choose_next(data,settings):
 eligible={v:r for v,r in data.items() if boundaries_ok(v,settings)}
 need(bool(eligible),'NO_ELIGIBLE_HISTORICAL_ANCHOR')
 anchor=leader(eligible)
 candidates=neighbors(anchor,settings,set(data))
 # Fall back to the next measured anchor if current anchor's neighborhood is exhausted.
 if not candidates:
  for vec in sorted(eligible,key=lambda v:last_observation(eligible[v])['dps_mean'],reverse=True):
   candidates=neighbors(vec,settings,set(data))
   if candidates:anchor=vec;break
 need(bool(candidates),'NO_MORE_FEASIBLE_NEIGHBORS')
 step=settings['rating_step']
 candidates.sort(key=lambda v:(-score_direction(anchor,v,data,step),v))
 return anchor,candidates[0],{'method':'LOCAL_MIRROR_EXTRAPOLATION_FOR_ORDER_ONLY','mirror_score_dps':score_direction(anchor,candidates[0],data,step)}


def make_input(source,case,output_json,vec,iterations,settings):
 need(boundaries_ok(vec,settings),'CANDIDATE_OUTSIDE_ALLOWED_VIRTUAL_BOUNDS')
 need(type(iterations) is int and iterations in (settings['scout_iterations'],settings['confirmation_iterations']),'ITERATIONS_NOT_ALLOWED')
 output_json=Path(output_json)
 need(output_json.is_absolute() and output_json.name=='result.json' and output_json.parent.name==case,'UNSAFE_ISOLATION_PATH')
 raw_path=str(output_json)
 need(not any(c in raw_path for c in ('\r','\n','"')),'UNSAFE_OUTPUT_PATH_CHAR')
 prefix=legacy.common_prefix(source)
 need(b'profileset.' not in prefix,'UNEXPECTED_PROFILESETS')
 rows=[f'# M0_CASE_ID=V015_{case}']
 rows.extend(f'gear_{k}_rating={v}' for k,v in zip(STATS,vec))
 opts={**legacy.OPTIONS,'iterations':iterations}
 rows.extend(f'{k}={value}' for k,value in opts.items())
 rows.append('json2='+raw_path)
 b=prefix+('\r\n'.join(rows)+'\r\n').encode('utf-8')
 need(b.startswith(prefix) and b.count(b'json2=')==1 and len(b)<100000,'GENERATED_INPUT_INVALID')
 return b


def parse_result(doc,vec,case,iterations,settings):
 need(doc.get('report_version')=='2.0.0','JSON2_REPORT_VERSION_MISMATCH')
 need(doc.get('version')=='1210-01' and doc.get('git_revision')=='7bc1071','SIMC_BUILD_MISMATCH')
 sim=doc['sim'];opt=sim['options']
 expected={**legacy.OPTIONS,'iterations':iterations}
 for k,v in expected.items():
  obs=opt.get(k)
  if type(obs) is bool:obs=int(obs)
  need(type(obs) in (int,float) and obs==v,'SIMC_OPTION_MISMATCH:'+k)
 need(opt['dbc']['Live']['build_level']==70448,'GAME_BUILD_MISMATCH')
 need(len(sim['players'])==1,'PLAYER_COUNT_MISMATCH')
 need(not sim.get('profilesets',{}).get('results',[]),'PROFILESETS_NOT_EXPECTED')
 p=sim['players'][0]
 need(p['name']==SAMPLE_ACTOR and p.get('flask') is not None,'ACTOR_OR_FLASK_MISMATCH')
 stats=p['collected_data']['buffed_stats']['stats']
 measured={}
 for i,k in enumerate(STATS):
  value=legacy.finite_num(stats[k+'_rating'],k)
  need(abs(value-(vec[i]+SOURCE_FLASK_OFFSET[i]))<1e-5,'EFFECTIVE_RATING_MISMATCH:'+k)
  measured[k]=value
 dps=p['collected_data']['dps']
 mean=legacy.finite_num(dps['mean'],'dps.mean')
 sem=legacy.finite_num(dps['mean_std_dev'],'dps.mean_std_dev')
 need(mean>0 and sem>0,'DPS_MEAN_OR_SEM_UNUSABLE')
 need(type(dps['count']) is int and dps['count']>=int(iterations*0.9),'DPS_SAMPLE_COUNT_TOO_LOW')
 z=legacy.finite_num(opt['confidence_estimator'],'confidence_estimator')
 need(abs(z-1.9599639854)<0.0001,'CONFIDENCE_ESTIMATOR_CHANGED')
 return {'case_id':case,'raw_gear_rating':dict(zip(STATS,vec)),
  'observed_effective_rating':measured,'flask_haste_bonus':165,
  'dps_mean':mean,'mean_standard_error':sem,'ci95_half_width':sem*z,
  'dps_sample_count':dps['count'],'iterations_requested':iterations,
  'simc_seed':opt.get('seed'),'origin':'REAL_V015',
  'actual_profile':'SAMPLE_ONLY','quality_verified_only_for':'flask/potion/oil rank2 pins'}


def confirmation_pair(data,settings):
 # Independent confirmation runs, not averaged with exploratory selected means.
 eligible={v:r for v,r in data.items() if boundaries_ok(v,settings)}
 need(len(eligible)>=2,'NEED_TWO_FEASIBLE_VECTORS_FOR_CONFIRMATION')
 return sorted(eligible,key=lambda v:last_observation(eligible[v])['dps_mean'],reverse=True)[:2]


def judge(pair,confirm):
 need(len(pair)==2 and set(pair)==set(confirm),'PAIR_NOT_MATCH_CONFIRMATIONS')
 a,b=pair;r1,r2=confirm[a],confirm[b]
 diff=r1['dps_mean']-r2['dps_mean']
 radius=1.9599639854*math.hypot(r1['mean_standard_error'],r2['mean_standard_error'])
 return {'method':'FRESH_SELECTED_PAIR_ONLY_NORMAL_APPROXIMATION','first_vector':dict(zip(STATS,a)),
 'second_vector':dict(zip(STATS,b)),'difference_first_minus_second_dps':diff,
 'ci95_half_width_dps':radius,
 'pairwise_direction_supported':abs(diff)>radius and r1.get('simc_seed') is not None and r2.get('simc_seed') is not None and r1.get('simc_seed')!=r2.get('simc_seed'),
 'distinct_observed_seeds':r1.get('simc_seed') is not None and r2.get('simc_seed') is not None and r1.get('simc_seed')!=r2.get('simc_seed'),
 'caution':'Selection based on exploratory means; the fresh confirmation comparison is independent only if run seeds are distinct. No tested-set or global-optimum guarantee.'}


def pack(run_dir):
 run_dir=Path(run_dir)
 rows=[]
 for p in sorted(run_dir.rglob('*')):
  if p.is_file() and p.name not in ('file_index_v015.json','M0_CHMV_ADAPTIVE_RESULTS_v015.zip'):
   rows.append({'path':p.relative_to(run_dir).as_posix(),'size':p.stat().st_size,'sha256':sha_file(p)})
 save_json(run_dir/'file_index_v015.json',{'schema':'CHMVAdaptiveEvidenceIndex-v015','entries':rows})
 archive=run_dir/'M0_CHMV_ADAPTIVE_RESULTS_v015.zip'
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(run_dir.rglob('*')):
   if p.is_file() and p!=archive:z.write(p,p.relative_to(run_dir).as_posix())
 with zipfile.ZipFile(archive) as z:need(z.testzip() is None,'ARCHIVE_CRC_FAILURE')
 return archive


def run_case(binary,source,path,case,vec,iterations,settings,attempts=None):
 folder=path/case;folder.mkdir(exist_ok=False)
 input_path=folder/'input.simc';result_path=folder/'result.json'
 with input_path.open('xb') as f:f.write(make_input(source,case,result_path,vec,iterations,settings))
 input_hash=sha_file(input_path)
 need(sha_file(binary)==BINARY_SHA,'BINARY_CHANGED_BEFORE_CASE')
 with (folder/'simc_stdout.txt').open('xb') as stdout, (folder/'simc_stderr.txt').open('xb') as stderr:
  if attempts is not None:attempts.append({'case_id':case,'candidate_vector':dict(zip(STATS,vec)),'iterations':iterations,'status':'CALL_ATTEMPTED'})
  proc=subprocess.run([str(binary),str(input_path)],cwd=str(binary.parent),stdout=stdout,stderr=stderr,
                      stdin=subprocess.DEVNULL,timeout=MAX_WALL_SECONDS,check=False)
 need(proc.returncode==0,'SIMC_EXIT_NONZERO:'+case+':'+str(proc.returncode))
 need(sha_file(binary)==BINARY_SHA,'BINARY_CHANGED_AFTER_CASE')
 need(result_path.is_file() and 0<result_path.stat().st_size<MAX_JSON_BYTES,'JSON2_MISSING_OR_OVERSIZE:'+case)
 output=parse_result(read_json(result_path.read_bytes()),vec,case,iterations,settings)
 output.update({'input_sha256':input_hash,'result_sha256':sha_file(result_path),'exit_code':proc.returncode})
 return output


def plan(settings,source,data,paths=None):
 anchor,next_vec,rationale=choose_next(data,settings)
 return {'schema':'CHMVAdaptivePlan-v015','status':'OFFLINE_ONLY',
 'source_v013_sha256':legacy.SOURCE_SHA,'source_v014_sha256':SOURCE_014_SHA,
 'observations_reused':len(data),'planned_max_new_simc_runs':settings['scout_runs']+settings['confirmation_runs'],
 'planned_max_new_iterations':settings['scout_runs']*settings['scout_iterations']+settings['confirmation_runs']*settings['confirmation_iterations'],
 'first_anchor':dict(zip(STATS,anchor)),'first_scout_vector':dict(zip(STATS,next_vec)),
 'first_scout_ordering_heuristic':rationale,'future_scouts':'ADAPTS_AFTER_PREVIOUS_JSON2',
 'future_confirmation_pair':'TOP_TWO_BY_EXPLORATORY_MEAN_AFTER_SCOUTS',
 'mode':'VIRTUAL_CHMV_BUDGET_NOT_REAL_EQUIPMENT_FEASIBILITY',
 'highest_quality_policy':'FLASK_POTION_OIL_KNOWN_RANK2_GEMS_CRAFTED_NOT_VERIFIED',
 'actual_simc_invocations':0,'global_optimum_claimed':False}


def run(binary,results_root,settings):
 source,data,labels=load_evidence()
 binary=Path(binary).resolve()
 need(binary.is_file(),'SIMC_NOT_FOUND')
 need(sha_file(binary)==BINARY_SHA,'SIMC_BINARY_SHA256_MISMATCH')
 root=Path(results_root).resolve();root.mkdir(parents=True,exist_ok=True)
 path=root/('ADAPTIVE_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:8])
 path.mkdir(exist_ok=False)
 status='DENIED_OR_PARTIAL';error=None;scouts=[];confirmations=[];pair=[];judgment=None;attempts=[]
 try:
  save_json(path/'run_settings_v015.json',settings)
  for index in range(1,settings['scout_runs']+1):
   anchor,vec,hint=choose_next(data,settings)
   case=f'SCOUT_{index:02d}'
   print(f'[SCOUT {index}/{settings["scout_runs"]}] anchor={anchor} candidate={vec} heuristic={hint["mirror_score_dps"]:.1f}',flush=True)
   rec=run_case(binary,source,path,case,vec,settings['scout_iterations'],settings,attempts)
   rec['anchor_vector']=dict(zip(STATS,anchor));rec['priority_method']=hint
   scouts.append(rec);data[vec]=[rec];labels[vec]=case
   print(f'[PASS] {case}: DPS={rec["dps_mean"]:.1f} ±{rec["ci95_half_width"]:.1f}; leader={leader(data)}',flush=True)
  pair=confirmation_pair(data,settings)
  for i,vec in enumerate(pair,1):
   case=f'CONFIRM_{i:02d}'
   print(f'[CONFIRM {i}/2] candidate={vec}, iterations={settings["confirmation_iterations"]}',flush=True)
   rec=run_case(binary,source,path,case,vec,settings['confirmation_iterations'],settings,attempts)
   confirmations.append(rec)
   print(f'[PASS] {case}: DPS={rec["dps_mean"]:.1f} ±{rec["ci95_half_width"]:.1f}',flush=True)
  by_vec={tuple(r['raw_gear_rating'][k] for k in STATS):r for r in confirmations}
  judgment=judge(pair,by_vec)
  status='PASS_BOUNDED_ADAPTIVE_SEARCH_WITH_FRESH_PAIR_CONFIRMATION'
 except Exception as exc:
  error=f'{type(exc).__name__}: {exc}'
  print('[DENIED_OR_PARTIAL]',error,flush=True)
 finally:
  receipt={'schema':'CHMVAdaptivePilotReceipt-v015','status':status,'error':error,
   'binary_sha256':BINARY_SHA,'source_v014_sha256':SOURCE_014_SHA,
   'source_v013_sha256':legacy.SOURCE_SHA,
   'historical_cached_unique_vectors':7,'completed_scouts':scouts,
   'completed_confirmations':confirmations,'selected_confirmation_vectors':[dict(zip(STATS,v)) for v in pair],
   'confirmation_judgment':judgment,
   'actual_new_simc_call_attempts':attempts,'actual_new_simc_call_attempt_count':len(attempts),
   'planned_max_runs':settings['scout_runs']+settings['confirmation_runs'],
   'sum_successful_requested_iterations':sum(r['iterations_requested'] for r in scouts+confirmations),
   'global_optimum_claimed':False,'real_item_feasibility':'NOT_DEFINED',
   'fully_max_quality_sample_gear':'NOT_VERIFIED',
   'notes':['Only seven past vectors are cached from independently pinned SimC JSON2.',
            'Local mirrored gradients order tests only and are not a validated response model.',
            'Actual equipment feasible set and user character profile remain for configuration.',
            'A fresh pair test cannot establish a global optimum; simultaneous comparisons with previous seven not confirmed.']}
  save_json(path/'adaptive_receipt_v015.json',receipt)
  archive=pack(path)
  print('[RESULT_DIR]',path,flush=True)
  print('[RESULT_ZIP]',archive,flush=True)
  if os.name=='nt':
   try:os.startfile(str(path))
   except OSError:pass
 return 0 if status.startswith('PASS_') else 2


def main(argv=None):
 parser=argparse.ArgumentParser(description='CHMV v015 bounded adaptive search with provenance and strict settings')
 parser.add_argument('--mode',choices=('plan','run'),default='run')
 parser.add_argument('--simc',default=DEFAULT_SIMC)
 parser.add_argument('--results-root',default=str(HERE/'CHMV_V015_RESULTS'))
 parser.add_argument('--settings',default=str(HERE/'RUN_SETTINGS_v015.json'))
 args=parser.parse_args(argv)
 try:
  settings=load_settings(args.settings)
  if args.mode=='plan':
   source,data,_=load_evidence()
   p=Path(args.results_root);p.mkdir(parents=True,exist_ok=True)
   dest=p/('PLAN_'+uuid.uuid4().hex[:8]);dest.mkdir(exist_ok=False)
   save_json(dest/'adaptive_plan_v015.json',plan(settings,source,data))
   print('[OFFLINE_PLAN]',dest/'adaptive_plan_v015.json')
   if os.name=='nt':
    try:os.startfile(str(dest))
    except OSError:pass
   return 0
  return run(args.simc,args.results_root,settings)
 except Exception as exc:
  print('[DENIED]',type(exc).__name__,str(exc),file=sys.stderr);return 2

if __name__=='__main__':raise SystemExit(main())
