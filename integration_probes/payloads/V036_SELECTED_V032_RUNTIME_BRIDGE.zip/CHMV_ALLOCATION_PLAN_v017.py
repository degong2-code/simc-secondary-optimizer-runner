#!/usr/bin/env python3
"""Offline v017 CHMV allocation bridge. Never invokes SimC or reads WEQUIP on its own.

Uses the validated v016 scenario/budget boundary. Produces bounded integer CHMV
candidate vectors and checks locked fixed stats. No item-level budgets are guessed.
Output is NOT a SimC-ready input, not a proven attainable gear/gem arrangement,
and not a DPS or optimality conclusion.
"""
from __future__ import annotations
import argparse
import datetime as dt
import json
import math
import os
from pathlib import Path
import sys
import uuid

import SCENARIO_CONTRACT_v016 as scenario

STATS = scenario.STAT_KEYS
SCHEMA = 'CHMVAllocationOfflinePlan-v017'


def _need(ok, reason):
    if not ok:
        raise scenario.ContractError(reason)


def _candidate_doc(vector, budget):
    total = budget['total']
    return {
        'chmv_absolute': {k: int(vector[i]) for i, k in enumerate(STATS)},
        'reference_share': {k: vector[i] / total for i, k in enumerate(STATS)},
        'total_rating': total,
        'locked_fixed_secondary': dict(budget['locked_special_secondary']),
        'adjustable_secondary': {
            k: vector[i] - budget['locked_special_secondary'][k]
            for i, k in enumerate(STATS)
        },
        'dps': None,
        'real_simc_verified': False,
        'physical_gear_and_gem_feasibility_verified': False,
    }


def verify_candidate(vector, budget):
    """Checks integer amount, inclusive per-stat cap, and immutable locked floors."""
    _need(type(vector) in (tuple, list) and len(vector) == 4, 'CANDIDATE_VECTOR_SHAPE_INVALID')
    _need(budget.get('budget_resolved') is True, 'BUDGET_NOT_RESOLVED')
    _need(all(type(x) is int and x >= 0 for x in vector), 'CANDIDATE_RATING_NOT_NONNEGATIVE_INTEGER')
    _need(sum(vector) == budget['total'], 'CANDIDATE_TOTAL_MISMATCH')
    for i, k in enumerate(STATS):
        _need(budget['minimum_absolute_inclusive'][k] <= vector[i] <= budget['maximum_absolute_inclusive'][k],
              'CANDIDATE_STAT_OUT_OF_BOUNDS:' + k)
        _need(vector[i] >= budget['locked_special_secondary'][k],
              'LOCKED_SPECIAL_GEAR_STAT_NOT_PRESERVED:' + k)
    return True


def project_integer_target(target_weights, budget):
    """Project weighted preference to closest feasible integer bounded-sum vector.

    The continuous solution is clamp(target_i + lambda, lower_i, upper_i),
    with lambda found by bisection, then deterministic residual apportionment.
    This is a candidate SEED ONLY; it is not an optimum DPS calculation.
    """
    _need(type(target_weights) in (list, tuple) and len(target_weights) == 4, 'INVALID_TARGET_WEIGHTS')
    _need(all(type(v) in (int, float) and math.isfinite(v) and v >= 0 for v in target_weights),
          'INVALID_TARGET_WEIGHTS')
    weight_sum = float(sum(target_weights))
    _need(weight_sum > 0, 'ZERO_TARGET_WEIGHTS')
    _need(budget.get('budget_resolved') is True, 'BUDGET_NOT_RESOLVED')
    total = budget['total']
    lowers = [budget['minimum_absolute_inclusive'][k] for k in STATS]
    uppers = [budget['maximum_absolute_inclusive'][k] for k in STATS]
    _need(sum(lowers) <= total <= sum(uppers), 'INTEGER_SHARE_BOUNDS_INFEASIBLE')
    desired = [total * float(w) / weight_sum for w in target_weights]
    def clamp(x, i):
        return max(lowers[i], min(uppers[i], x))
    left, right = -2.0 * total - 1., 2.0 * total + 1.
    for _ in range(96):
        mid = (left + right) * 0.5
        if sum(clamp(desired[i] + mid, i) for i in range(4)) < total:
            left = mid
        else:
            right = mid
    continuous = [clamp(desired[i] + (left + right) * 0.5, i) for i in range(4)]
    integers = [min(uppers[i], max(lowers[i], math.floor(continuous[i]))) for i in range(4)]
    remaining = total - sum(integers)
    _need(remaining >= 0, 'PROJECTION_ROUNDING_UNDERFLOW')
    rank = sorted(range(4), key=lambda i: (-(continuous[i] - math.floor(continuous[i])), i))
    while remaining > 0:
        moved = False
        for i in rank:
            if integers[i] < uppers[i] and remaining:
                integers[i] += 1
                remaining -= 1
                moved = True
        _need(moved, 'PROJECTION_NO_INTEGER_CAPACITY')
    vector = tuple(integers)
    verify_candidate(vector, budget)
    return vector


def seed_preferences():
    """Cover balanced, single-stat, pair-stat, triple-stat and skewed directions."""
    prefs = [('BALANCED', (1, 1, 1, 1))]
    for i, stat in enumerate(STATS):
        v = [0] * 4; v[i] = 1
        prefs.append(('FOCUS_' + stat.upper(), tuple(v)))
    for i in range(4):
        for j in range(i + 1, 4):
            v = [0] * 4; v[i] = v[j] = 1
            prefs.append(('PAIR_' + STATS[i].upper() + '_' + STATS[j].upper(), tuple(v)))
    for omitted in range(4):
        v = [1] * 4; v[omitted] = 0
        prefs.append(('THREE_EXCEPT_' + STATS[omitted].upper(), tuple(v)))
    for i in range(4):
        for j in range(4):
            if i == j: continue
            v = [1] * 4; v[i] = 6; v[j] = 3
            prefs.append(('BIASED_' + STATS[i].upper() + '_' + STATS[j].upper(), tuple(v)))
    return prefs


def diverse_seeds(budget, max_seeds=20, diversity_fraction=0.10):
    _need(type(max_seeds) is int and 1 <= max_seeds <= 64, 'INVALID_MAX_SEEDS')
    _need(type(diversity_fraction) in (int, float) and math.isfinite(diversity_fraction)
          and 0 <= diversity_fraction <= 1, 'INVALID_DIVERSITY_FRACTION')
    _need(budget.get('budget_resolved') is True, 'BUDGET_NOT_RESOLVED')
    candidates = []
    encountered = set()
    for label, weights in seed_preferences():
        vec = project_integer_target(weights, budget)
        if vec in encountered:
            continue
        encountered.add(vec)
        if any(sum(abs(a - b) for a, b in zip(vec, item['vector'])) < diversity_fraction * budget['total']
               for item in candidates):
            continue
        candidates.append({'seed_label': label, 'vector': vec})
        if len(candidates) == max_seeds:
            break
    _need(bool(candidates), 'NO_FEASIBLE_ALLOCATION_SEEDS')
    return candidates


def build_plan(config, table=None, max_seeds=20, diversity_fraction=None):
    """A budget-only plan may exist even while SimC preflight is blocked."""
    _need(type(max_seeds) is int and 1 <= max_seeds <= 64, 'INVALID_MAX_SEEDS')
    pre = scenario.preflight(config, table)
    budget = pre['budget']
    fraction = (config['search']['meaningful_l1_distance_min_fraction'] if diversity_fraction is None
                else diversity_fraction)
    _need(type(fraction) in (int, float) and math.isfinite(fraction) and 0 <= fraction <= 1,
          'INVALID_DIVERSITY_FRACTION')
    report = {
        'schema': SCHEMA,
        'status': 'BUDGET_UNRESOLVED' if not budget['budget_resolved'] else 'OFFLINE_CHMV_ALLOCATION_READY',
        'origin_scenario_schema': config['schema'],
        'budget': budget,
        'scenario_preflight': pre,
        'max_requested_seeds': max_seeds,
        'diversity_l1_fraction_of_total': fraction,
        'candidates': [],
        'simc_executed': False,
        'simc_input_ready': False,
        'itemlevel_budget_guessed': False,
        'dps_measured': False,
        'v015_evidence_reused_as_new_scenario': False,
        'out_of_budget_fixed_effects_applied_to_simc': False,
        'warnings': [
            'Candidate seeds are only numerical CHMV allocations, not equipment/gem recipes or estimated DPS.',
            'Flask and gem CHMV budgets are abstract and cannot be injected into SimC until double-count prevention is verified.',
            'Self-declared VERIFIED_RAW source_status does not independently authenticate a source record.',
        ],
    }
    if budget['budget_resolved']:
        seeds = diverse_seeds(budget, max_seeds, fraction)
        report['candidates'] = [dict(seed_index=i + 1, seed_label=item['seed_label'], **_candidate_doc(item['vector'], budget))
                                for i, item in enumerate(seeds)]
        report['minimum_l1_between_selected'] = (min(
            sum(abs(x['chmv_absolute'][k] - y['chmv_absolute'][k]) for k in STATS)
            for i, x in enumerate(report['candidates']) for y in report['candidates'][i + 1:]
        ) if len(seeds) > 1 else None)
    return report


def main(argv=None):
    parser = argparse.ArgumentParser(description='v017 offline rating allocation candidate planner; never runs SimC')
    parser.add_argument('--scenario', default=str(scenario.DEFAULT_CONFIG))
    parser.add_argument('--budget-export', default=None)
    parser.add_argument('--max-seeds', type=int, default=20)
    parser.add_argument('--diversity-fraction', type=float, default=None)
    parser.add_argument('--output-root', default=str(Path(__file__).resolve().parent / 'V017_ALLOCATION_RESULTS'))
    args = parser.parse_args(argv)
    scenario_path = Path(args.scenario).resolve()
    export_path = Path(args.budget_export).resolve() if args.budget_export else None
    try:
        doc = scenario.load_strict(scenario_path)
        table = scenario.load_strict(export_path) if export_path else None
        receipt = build_plan(doc, table, args.max_seeds, args.diversity_fraction)
        receipt['scenario_sha256'] = scenario.sha(scenario_path)
        receipt['budget_export_sha256'] = scenario.sha(export_path) if export_path else None
        code = 0
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as ex:
        receipt = {'schema': SCHEMA, 'status': 'DENIED', 'reason': type(ex).__name__ + ': ' + str(ex),
                   'simc_executed': False, 'simc_input_ready': False, 'dps_measured': False}
        code = 2
    root = Path(args.output_root).resolve()
    root.mkdir(parents=True, exist_ok=True)
    output = root / (dt.datetime.now(dt.timezone.utc).strftime('ALLOCATION_%Y%m%dT%H%M%S_%fZ_') + uuid.uuid4().hex[:7])
    output.mkdir()
    dest = output / 'chmv_allocation_plan_v017.json'
    scenario.write_json(dest, receipt)
    print('[' + ('PASS_OFFLINE' if code == 0 else 'DENIED') + '] ' + receipt['status'])
    print('[PLAN] ' + str(dest))
    print('[CANDIDATES] ' + str(len(receipt.get('candidates', []))))
    try:
        if os.name == 'nt': os.startfile(str(output))
    except (OSError, AttributeError):
        pass
    return code


if __name__ == '__main__':
    sys.exit(main())
