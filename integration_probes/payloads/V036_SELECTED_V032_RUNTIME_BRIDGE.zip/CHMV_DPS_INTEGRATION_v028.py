#!/usr/bin/env python3
"""v028 bounded native DPS search integration (general product test, not Work OS M0).

Uses v027's user-measured gemmed arcane profile as an actual sample (not
unverified historical v015 DPS measurements); reuses v015 selection heuristics,
final pair judgment, and v022's constrained CHMV model. The SimC binary owns
all item, 4pc and special gem effects. No direct effect/DPS reconstruction.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid
import zipfile

import CHMV_ADAPTIVE_v015 as adaptive
import CHMV_FINAL_APPLIED_v022 as model
import CHMV_FIXED_FLOOR_INJECTION_v025 as injection
import SIMC_STAT_ATTRIBUTION_v021 as native
import SIMC_NATIVE_GEM_PROBE_v027 as gems

HERE = Path(__file__).resolve().parent
EVIDENCE = HERE/'EVIDENCE_V028_INPUTS'/'GEM_NATIVE_PROBE_RESULTS_v027_USER_PC.zip'
EVIDENCE_SHA = 'b25b95fda79a8c54357a04dd4a3a3ee3ab6f614db40ce2a57729e82bad8a1224'
STATS = tuple(native.STATS)
GEAR_BUDGET = 2847  # ONLY the pinned v020-v027 Arcane 334 real SimC sample
GEM_BUDGET = 138
FLASK_BUDGET = 165
OIL = model.OIL
FINAL_TOTAL = GEAR_BUDGET+GEM_BUDGET+FLASK_BUDGET+sum(OIL.values())
FLASK_NATIVE = {k:(165 if k=='haste_rating' else 0) for k in STATS}
EXPECTED_REV = '7bc1071'
EXPECTED_BUILD = '12.1.5.70448'
SCOUTS = 3
CONFIRMS = 2
MOVE_STEP = 200
GEM_CHOICES = {'primary32':'override_primary32',
               'primary23_four_colors':'override_primary23_four_colors'}
RAW_CHOICES = {'primary32':'raw_primary32',
               'primary23_four_colors':'raw_primary23_four_colors'}
REQUIRED_OPTIONS = {'desired_targets':'1','fight_style':'Patchwerk',
                    'fixed_time':'1','vary_combat_length':'0',
                    'max_time':'300','optimal_raid':'1','threads':'1',
                    'calculate_scale_factors':'0','item_db_source':'local'}

class Rejected(ValueError):pass

def need(flag,reason):
    if not flag:raise Rejected(reason)

def digest(data):return hashlib.sha256(data).hexdigest()
def sha_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for p in iter(lambda:f.read(1<<20),b''):h.update(p)
    return h.hexdigest()

def save(path,doc):
    Path(path).write_text(json.dumps(doc,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')

def load_pinned(choice):
    need(choice in GEM_CHOICES,'UNKNOWN_SPECIAL_GEM_CHOICE')
    need(EVIDENCE.is_file() and sha_file(EVIDENCE)==EVIDENCE_SHA,'V027_USER_EVIDENCE_IDENTITY_MISMATCH')
    with zipfile.ZipFile(EVIDENCE) as z:
        need(z.testzip() is None,'V027_EVIDENCE_ZIP_CRC_INVALID')
        r=json.loads(z.read('GEM_NATIVE_PROBE_RECEIPT_v027.json'))
        need(r['status']=='NATIVE_GEM_STAT_PROBES_PASS','V027_NOT_PASSED')
        need(all(r['results'][n]['pass'] for n in (*GEM_CHOICES.values(),*RAW_CHOICES.values())),
             'V027_CASE_NOT_PASSED')
        output=json.loads(z.read(GEM_CHOICES[choice]+'.json'))
        raw=json.loads(z.read(RAW_CHOICES[choice]+'.json'))
        profile=z.read(GEM_CHOICES[choice]+'.simc').decode('utf-8-sig')
    observed=native.snapshot(output);raw_observed=native.snapshot(raw)
    need(observed['simc_git_revision']==EXPECTED_REV and observed['simc_build']==EXPECTED_BUILD,
         'V027_SIMC_IDENTITY_MISMATCH')
    need(observed['buffed_rating']==r['gear_override_final_target'],'V027_FINAL_STAT_MISMATCH')
    need(sum(raw_observed['buffed_rating'].values())==FINAL_TOTAL,'V027_RAW_BUDGET_MISMATCH')
    need(observed['item_identity']==raw_observed['item_identity'],'V027_ITEM_IDENTITY_CHANGED')
    expected_gems={slot:list(gems.ids_for_slot(slot,choice)) for slot in gems.SLOTS}
    need(gems.parse_gem_ids(output['sim']['players'][0]['gear'])==expected_gems,'V027_GEM_ITEM_ID_MISMATCH')
    need('temporary_enchant=main_hand:thalassian_phoenix_oil_2' in profile,
         'V027_OIL_MISSING')
    need('flask=flask_of_the_blood_knights_2' in profile,'V027_FLASK_MISSING')
    return {'source_simc':profile,'reference':observed,
            'raw_base':raw_observed['buffed_rating'],
            'gem_ids':expected_gems,'special_choice':choice,
            'simc_gear_secondary':observed['gear_secondary'],
            'pinned_sample':True}

def settings(scout_iterations,confirm_iterations):
    need(type(scout_iterations) is int and 60<=scout_iterations<=600,'SCOUT_ITERATIONS_OUT_OF_BOUNDS')
    need(type(confirm_iterations) is int and 150<=confirm_iterations<=1500,'CONFIRM_ITERATIONS_OUT_OF_BOUNDS')
    need(confirm_iterations>=scout_iterations,'CONFIRM_LESS_THAN_SCOUT')
    return {'scouts':SCOUTS,'confirmations':CONFIRMS,'scout_iterations':scout_iterations,
            'confirmation_iterations':confirm_iterations,'max_new_calls':SCOUTS+CONFIRMS,
            'max_new_iterations':SCOUTS*scout_iterations+CONFIRMS*confirm_iterations,
            'fight_seconds':300,'single_target':True,'optimal_raid':True,
            'bloodlust':'START_BY_SIMC_OPTIMAL_RAID','move_step':MOVE_STEP,
            'min_share':0.0,'max_share':0.5,'no_old_v015_dps_cache':True}

def valid(vec):
    if type(vec) is not tuple or len(vec)!=len(STATS) or any(type(v) is not int or v<0 for v in vec):return False
    if sum(vec)!=FINAL_TOTAL:return False
    for i,k in enumerate(STATS):
        if vec[i]<OIL[k] or vec[i]>math.floor(FINAL_TOTAL*.5+1e-9):return False
    try:
        injection.verify_fixed_floor(dict(zip(STATS,vec)),oil=OIL)
        injection.gear_override_for_final(dict(zip(STATS,vec)),FLASK_NATIVE)
    except (ValueError,KeyError):return False
    return True

def neighbors(anchor,seen,step=MOVE_STEP):
    out=[]
    for src in range(4):
        for dest in range(4):
            if src==dest:continue
            arr=list(anchor);arr[src]-=step;arr[dest]+=step
            v=tuple(arr)
            if valid(v) and v not in seen and v not in out:out.append(v)
    return out

def choose_candidate(data,baseline,step=MOVE_STEP):
    # Reuse v015 observed-leader and mirrored-neighbor ordering without its
    # obsolete 3000-rating hard-code or foreign historical DPS evidence.
    if not data:
        need(valid(baseline),'PINNED_SAMPLE_BASELINE_INFEASIBLE')
        return baseline,{'method':'V027_NATIVE_RAW_SEED'}
    anchor=adaptive.leader(data)
    choices=neighbors(anchor,set(data),step)
    if not choices:
        for backup in sorted(data,key=lambda v:-data[v][-1]['dps_mean']):
            choices=neighbors(backup,set(data),step)
            if choices:anchor=backup;break
    need(bool(choices),'NO_FEASIBLE_ADAPTIVE_NEIGHBOR')
    choices.sort(key=lambda v:(-adaptive.score_direction(anchor,v,data,step),v))
    selected=choices[0]
    return selected,{'method':'V015_MIRRORED_NEIGHBOR_ADAPTED_TO_V028',
                     'anchor':list(anchor),
                     'mirror_score':adaptive.score_direction(anchor,selected,data,step)}

def top_two(data):
    need(len(data)>=2,'NOT_ENOUGH_EXPLORATION_RESULTS')
    return sorted(data,key=lambda v:(-data[v][-1]['dps_mean'],v))[:2]

def profile_for_case(source,output,vec,iterations):
    need(valid(vec),'INVALID_FINAL_CHMV_CANDIDATE')
    need(type(iterations) is int and 60<=iterations<=1500,'INVALID_ITERATION_COUNT')
    override=injection.gear_override_for_final(dict(zip(STATS,vec)),FLASK_NATIVE)
    # Preserve every native item/gem/season-set/effect row. Replace ONLY the
    # former diagnostic simulation options, gear_* and json2 output.
    replace={**REQUIRED_OPTIONS,'iterations':str(iterations)}
    lines=[];seen={}
    for row in source.splitlines():
        if not row.strip():
            lines.append(row);continue
        if row.startswith('json2=') or re.match(r'^gear_(?:crit|haste|mastery|versatility)_rating=',row):continue
        key=row.partition('=')[0]
        if key in replace:
            seen[key]=seen.get(key,0)+1
            need(seen[key]==1,'DUPLICATE_PROFILE_OPTION:'+key)
            lines.append(key+'='+replace[key]);continue
        need(key not in override,'DUPLICATE_GEAR_OVERRIDE')
        lines.append(row)
    need(set(seen).issuperset({'iterations','max_time','desired_targets','fight_style','fixed_time',
                              'vary_combat_length','threads','calculate_scale_factors','item_db_source'}),
         'V027_PROFILE_MISSING_REQUIRED_OPTION')
    if 'optimal_raid' not in seen:lines.append('optimal_raid=1')
    else:need(seen['optimal_raid']==1,'DUPLICATE_OPTIMAL_RAID')
    for k,v in override.items():lines.append(k+'='+str(v))
    path=Path(output).resolve()
    need(path.name.endswith('.json') and '\n' not in str(path),'UNSAFE_OUTPUT_PATH')
    lines.append('json2='+str(path))
    text='\n'.join(lines)+'\n'
    need(text.count('json2=')==1,'OUTPUT_NOT_UNIQUE')
    need(text.count('temporary_enchant=main_hand:thalassian_phoenix_oil_2')==1,'OIL_LOST')
    need(text.count('flask=flask_of_the_blood_knights_2')==1,'FLASK_LOST')
    need(sum(1 for line in lines if line.startswith('gear_') and line.partition('=')[0] in override)==4,
         'OVERRIDES_NOT_FOUR')
    return text,override

def parse_dps(doc,vec,iterations,reference):
    need(doc.get('report_version')=='2.0.0','JSON2_SCHEMA_CHANGED')
    snap=native.snapshot(doc)
    need(snap['simc_git_revision']==EXPECTED_REV and snap['simc_build']==EXPECTED_BUILD,
         'SIMC_BUILD_CHANGED')
    need(snap['item_identity']==reference['reference']['item_identity'],
         'NATIVE_ITEMS_CHANGED')
    need(snap['gear_secondary']==reference['simc_gear_secondary'],
         'NATIVE_GEAR_STATS_CHANGED')
    actual_gem_ids=gems.parse_gem_ids(doc['sim']['players'][0]['gear'])
    need(actual_gem_ids==reference['gem_ids'],'GEM_OR_SPECIAL_DIAMOND_CHANGED')
    need('thalassian_phoenix_oil' in str(snap['temporary_enchant']), 'NATIVE_OIL_NOT_CONFIGURED')
    need(snap['flask']=='flask_of_the_blood_knights_2','NATIVE_FLASK_NOT_CONFIGURED')
    target=dict(zip(STATS,vec));actual=snap['buffed_rating']
    need(actual==target,'FINAL_APPLIED_CHMV_MISMATCH:'+str(actual)+' != '+str(target))
    opts=doc['sim']['options']
    def close(name,value):
        obs=opts.get(name)
        need(isinstance(obs,(int,float,bool)) and float(obs)==float(value),'SIMC_OPTION_MISMATCH:'+name)
    for k,v in [('iterations',iterations),('max_time',300),('vary_combat_length',0),
                ('fixed_time',1),('desired_targets',1),('optimal_raid',1)]:close(k,v)
    need(str(opts.get('fight_style'))=='Patchwerk','FIGHT_STYLE_MISMATCH')
    p=doc['sim']['players'][0]
    need(len(doc['sim']['players'])==1,'MULTIPLE_PLAYERS_UNSUPPORTED')
    dps=p['collected_data']['dps']
    mean=float(dps['mean']);se=float(dps['mean_std_dev']);count=dps['count']
    need(math.isfinite(mean) and mean>0,'INVALID_DPS_MEAN')
    need(math.isfinite(se) and se>0,'INVALID_DPS_SEM')
    need(type(count) is int and count>=int(iterations*.9),'INSUFFICIENT_DPS_SAMPLES')
    need(isinstance(opts.get('seed'),(int,float)),'SIMC_SEED_MISSING')
    z=float(opts.get('confidence_estimator',1.9599639854))
    need(math.isfinite(z) and 1.8<z<2.2,'UNEXPECTED_CONFIDENCE_ESTIMATOR')
    return {'dps_mean':mean,'mean_standard_error':se,'ci95_half_width':se*z,
            'dps_sample_count':count,'iterations_requested':iterations,
            'simc_seed':opts['seed'],'final_applied_rating':actual,
            'profile_items_and_gems_unchanged':True,
            'special_item_effects_owned_by_simc':True}

def run_case(binary,source,folder,tag,vec,iterations,reference):
    folder.mkdir(exist_ok=False)
    out=folder/'result.json';inputfile=folder/'input.simc'
    content,override=profile_for_case(source,out,vec,iterations)
    inputfile.write_text(content,encoding='utf-8')
    info={'case':tag,'candidate':dict(zip(STATS,vec)),
          'gear_override':override,'iterations':iterations,'input_sha256':sha_file(inputfile),
          'status':'SIMC_CALL_ATTEMPTED'}
    need(sha_file(binary)==native.BINARY_SHA,'SIMC_BINARY_HASH_CHANGED_PRE_CALL')
    try:
        with (folder/'stdout.txt').open('w',encoding='utf-8') as so, (folder/'stderr.txt').open('w',encoding='utf-8') as se:
            proc=subprocess.run([str(binary),str(inputfile)],cwd=str(binary.parent),
                    stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=900,check=False)
        info['exit_code']=proc.returncode
        need(proc.returncode==0,'SIMC_EXIT_NONZERO:'+str(proc.returncode))
        need(out.is_file() and 0<out.stat().st_size<50_000_000,'SIMC_JSON2_NOT_FOUND')
        need(sha_file(binary)==native.BINARY_SHA,'SIMC_BINARY_HASH_CHANGED_POST_CALL')
        result=parse_dps(json.loads(out.read_text(encoding='utf-8-sig')),vec,iterations,reference)
        info.update(result);info['output_sha256']=sha_file(out);info['status']='SIMC_DPS_AND_CHMV_PASS'
        return info
    finally:save(folder/'case_attempt_v028.json',info)

def make_plan(reference,cfg):
    model_plan=model.plan_from_budget(GEAR_BUDGET,gem_budget=GEM_BUDGET,
                  flask_budget=FLASK_BUDGET,oil=OIL,max_seeds=8)
    base=tuple(reference['raw_base'][k] for k in STATS)
    need(valid(base),'INITIAL_NATIVE_CANDIDATE_NOT_IN_BOUNDS')
    need(model_plan['final_applied_total']==FINAL_TOTAL,'MODEL_TOTAL_CHANGED')
    return {'schema':'SIMCNativeAdaptiveDPSPlan-v028','status':'OFFLINE_ONLY',
            'user_approved_general_simc_product_test':True,
            'simc_version':'1210-01 / '+EXPECTED_REV,
            'source_v027_evidence_sha256':EVIDENCE_SHA,
            'reuse_v015_logic':['observed_leader','mirror_priority','fresh_pair_judgment'],
            'reuse_v015_measured_DPS':False,
            'model_budget':{'native_gear':GEAR_BUDGET,'gems':GEM_BUDGET,'flask':FLASK_BUDGET,
                            'fixed_oil':OIL,'total':FINAL_TOTAL},
            'v027_native_raw_seed':dict(zip(STATS,base)),
            'locked_special_gear':{k:0 for k in STATS},
            'outside_pool_fixed_secondary':{k:0 for k in STATS},
            'limitation':'Pinned sample only; no selectable special gear/embellishment compiler yet.',
            'stat_max_share':0.5,'native_flask_rating_outside_gear_override':FLASK_NATIVE,
            'other_seed_samples':[c['final_applied_chmv_target'] for c in model_plan['candidates'][:4]],
            'scout2_and_scout3':'Selected adaptively after preceding actual DPS observations',
            'settings':cfg,'new_simc_calls':0,'global_optimum_claim':False}

def archive(folder):
    path=folder/'NATIVE_ADAPTIVE_DPS_RESULTS_v028.zip'
    files=[p for p in sorted(folder.rglob('*')) if p.is_file() and p!=path]
    save(folder/'FILE_INDEX_v028.json',{'schema':'v028-evidence-index','entries':[
        {'path':p.relative_to(folder).as_posix(),'size':p.stat().st_size,'sha256':sha_file(p)}
        for p in files]})
    files=[p for p in sorted(folder.rglob('*')) if p.is_file() and p!=path]
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in files:z.write(p,p.relative_to(folder).as_posix())
    with zipfile.ZipFile(path) as z:need(z.testzip() is None,'OUTPUT_ZIP_CRC_FAILED')
    return path

def run(args,reference,cfg,folder,report):
    binary=Path(args.simc_executable).resolve()
    need(binary.is_file(),'SIMC_EXE_NOT_FOUND')
    need(sha_file(binary)==native.BINARY_SHA,'SIMC_BINARY_SHA256_MISMATCH')
    base=tuple(reference['raw_base'][k] for k in STATS)
    seen={};records=[];confirms=[];attempts=[]
    try:
        for i in range(SCOUTS):
            vec,hint=choose_candidate(seen,base)
            tag='SCOUT_%02d'%(i+1)
            attempts.append({'tag':tag,'candidate':list(vec),'status':'ATTEMPTED'})
            print('[SCOUT]',i+1,'/',SCOUTS,list(vec),flush=True)
            rec=run_case(binary,reference['source_simc'],folder/tag,tag,vec,cfg['scout_iterations'],reference)
            rec['priority']=hint
            seen[vec]=[rec];records.append(rec)
            attempts[-1]['status']='PASS';save(folder/'PROGRESS_v028.json',{'stage':tag,'attempts':attempts})
        pair=top_two(seen)
        for i,vec in enumerate(pair):
            tag='CONFIRM_%02d'%(i+1)
            attempts.append({'tag':tag,'candidate':list(vec),'status':'ATTEMPTED'})
            print('[CONFIRM]',i+1,'/',CONFIRMS,list(vec),flush=True)
            rec=run_case(binary,reference['source_simc'],folder/tag,tag,vec,cfg['confirmation_iterations'],reference)
            confirms.append(rec)
            attempts[-1]['status']='PASS';save(folder/'PROGRESS_v028.json',{'stage':tag,'attempts':attempts})
        fresh={tuple(rec['candidate'][k] for k in STATS):rec for rec in confirms}
        comparison=adaptive.judge(pair,fresh)
        report.update({'status':'PASS_BOUNDED_NATIVE_ADAPTIVE_DPS_PILOT',
                       'scouts':records,'confirmation_runs':confirms,
                       'fresh_pair_judgment':comparison,
                       'selected_top_two':[dict(zip(STATS,p)) for p in pair]})
    except (Exception, KeyboardInterrupt) as e:
        report.update({'status':'PARTIAL_OR_BLOCKED','error':type(e).__name__+':'+str(e),
                       'scouts':records,'confirmation_runs':confirms,'fresh_pair_judgment':None})
    report.update({'attempts':attempts,'actual_new_call_attempts':len(attempts),
                   'total_successful_iterations':sum(v['iterations_requested'] for v in records+confirms),
                   'global_optimum_claimed':False,
                   'full_product_complete':False})
    return report

def main(argv=None):
    ap=argparse.ArgumentParser(description='v028 bounded 300-second DPS integration, native gems and rating')
    ap.add_argument('--mode',choices=('plan','local-probe'),default='plan')
    ap.add_argument('--gem-choice',choices=tuple(GEM_CHOICES),default='primary23_four_colors')
    ap.add_argument('--simc-executable',default=None)
    ap.add_argument('--output-root',default=str(HERE/'V028_OUTPUTS'))
    ap.add_argument('--scout-iterations',type=int,default=120)
    ap.add_argument('--confirm-iterations',type=int,default=320)
    args=ap.parse_args(argv)
    try:
        cfg=settings(args.scout_iterations,args.confirm_iterations)
        need(args.mode=='plan' or args.simc_executable is not None,'SIMC_EXE_PATH_REQUIRED')
        reference=load_pinned(args.gem_choice)
        base_plan=make_plan(reference,cfg)
        root=Path(args.output_root).resolve()
        root.mkdir(parents=True,exist_ok=True)
        folder=root/('RUN_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ_')+uuid.uuid4().hex[:8]);folder.mkdir(exist_ok=False)
        save(folder/'PLAN_v028.json',base_plan)
        baseline=tuple(reference['raw_base'][k] for k in STATS)
        first,_=profile_for_case(reference['source_simc'],folder/'PREVIEW_SEED.json',baseline,cfg['scout_iterations'])
        (folder/'PREVIEW_SEED.simc').write_text(first,encoding='utf-8')
        report={'schema':'SIMCNativeAdaptiveDPSReceipt-v028',
                'status':'OFFLINE_PLAN_PASS' if args.mode=='plan' else 'PENDING',
                'gem_choice':args.gem_choice,'v027_evidence_sha256':EVIDENCE_SHA,
                'settings':cfg,'pinned_sample_native_gear_rating':GEAR_BUDGET,
                'actual_new_call_attempts':0,'no_cross_scenario_v015_DPS_cache':True,
                'main_work_os_changed':False,'simc_owned_effects_not_recalculated':True}
        if args.mode=='local-probe':report=run(args,reference,cfg,folder,report)
        save(folder/'NATIVE_ADAPTIVE_DPS_RECEIPT_v028.json',report)
        note=['SIMC SECONDARY OPTIMIZER v028 — 결과 요약',
              '상태: '+report['status'],
              '특수보석: '+args.gem_choice,
              '대표 사례: 비전 마법사 334 / Patchwerk 300초 / 최종 정적 CHMV 3182',
              '사용자 PC 실제 SimC 실행 완료 여부: '+str(report['status']=='PASS_BOUNDED_NATIVE_ADAPTIVE_DPS_PILOT'),
              '전역 최적해 입증 여부: 아니오',
              '']
        if report.get('scouts'):
            note.append('탐색 후보 DPS (통계 오차 포함):')
            for item in report['scouts']:
                note.append('  '+str(item['candidate'])+' -> '+
                            f"{item['dps_mean']:.2f} DPS ±{item['ci95_half_width']:.2f} (95% 개별 CI 반폭)")
        if report.get('confirmation_runs'):
            note.append('')
            note.append('독립 재확인 후보:')
            for item in report['confirmation_runs']:
                note.append('  '+str(item['candidate'])+' -> '+
                            f"{item['dps_mean']:.2f} DPS ±{item['ci95_half_width']:.2f}")
        if report.get('fresh_pair_judgment'):
            note.append('')
            note.append('독립 2후보 우열 판정 근거: '+str(report['fresh_pair_judgment']))
        if report.get('error'):note.append('중단/오류: '+report['error'])
        (folder/'RESULT_SUMMARY_KO_v028.txt').write_text('\n'.join(note)+'\n',encoding='utf-8')
        outzip=archive(folder)
        print('[STATUS]',report['status'],flush=True)
        print('[RESULT_ZIP]',outzip,flush=True)
        print('[RESULT_FOLDER]',folder,flush=True)
        if os.name=='nt':
            try:os.startfile(str(folder))
            except (OSError,AttributeError):pass
        return 0 if report['status'] in ('OFFLINE_PLAN_PASS','PASS_BOUNDED_NATIVE_ADAPTIVE_DPS_PILOT') else 2
    except Exception as e:
        print('[BLOCKED]',type(e).__name__,str(e),file=sys.stderr)
        return 2

if __name__=='__main__':sys.exit(main())
