#!/usr/bin/env python3
"""v022: native v021 stat boundary, fixed-oil aware CHMV plans, and isolated oil probe.

NO live optimization, actual gem injection, four-piece validation, or season-wide
native budget approval is implied. Existing v015-v021 code/evidence stays immutable.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import subprocess
import sys
import uuid
import zipfile

import CHMV_ALLOCATION_PLAN_v017 as allocation
import SIMC_STAT_ATTRIBUTION_v021 as attribution

ROOT=Path(__file__).resolve().parent
V021_PC=ROOT/'EVIDENCE_V022_INPUTS'/'STAT_ATTRIBUTION_RESULTS_v021_USER_PC.zip'
V021_PC_SHA='3251bd266f03f00dca74684d1742b0951171ddb9fccc96b76582fcf62b2a47aa'
STATS=attribution.STATS
# User-established, fixed CHMV vector for the identified highest-quality weapon oil.
OIL={'crit_rating':16,'haste_rating':16,'mastery_rating':0,'versatility_rating':0}
GEMS=138
FLASK=165
DEFAULT_MIN=0.0
DEFAULT_MAX=0.5


def sha_file(path):
    h=hashlib.sha256()
    with open(path,'rb') as f:
        for part in iter(lambda:f.read(1<<20),b''):h.update(part)
    return h.hexdigest()


def check(cond,reason):
    if not cond:raise ValueError(reason)


def read_v021(path=V021_PC):
    path=Path(path)
    check(path.is_file(),'V021_PC_RESULTS_MISSING')
    check(sha_file(path)==V021_PC_SHA,'V021_PC_RESULTS_SHA_MISMATCH')
    with zipfile.ZipFile(path) as z:
        check(z.testzip() is None,'V021_PC_BAD_ZIP_CRC')
        expected=['STAT_ATTRIBUTION_RECEIPT_v021.json','neutral.json','flask_only.json']
        check(all(n in z.namelist() for n in expected),'V021_PC_EVIDENCE_MISSING')
        data=json.loads(z.read(expected[0]))
        neutral=json.loads(z.read('neutral.json'))
        flask=json.loads(z.read('flask_only.json'))
    check(data['status']=='CONTROLLED_CONSUMABLE_PROBE_PASS','V021_PC_NOT_PASS')
    check(data['local_probe']['both_runs_success'],'V021_PC_RUNS_NOT_SUCCESS')
    n=attribution.snapshot(neutral);f=attribution.snapshot(flask)
    gear={'crit_rating':792,'haste_rating':920,'mastery_rating':822,'versatility_rating':313}
    check(n['gear_secondary']==gear and f['gear_secondary']==gear,'V021_GEAR_CHANGED')
    check(n['buffed_rating']==gear,'V021_NEUTRAL_NOT_ZERO')
    diff={k:f['buffed_rating'][k]-n['buffed_rating'][k] for k in STATS}
    check(diff=={'crit_rating':0,'haste_rating':165,'mastery_rating':0,'versatility_rating':0},'V021_FLASK_NOT_EXPECTED_165')
    check(n['temporary_enchant']=='disabled','V021_NEUTRAL_OIL_NOT_DISABLED')
    check(f['temporary_enchant']=='disabled','V021_FLASK_OIL_NOT_DISABLED')
    return {'evidence_sha256':sha_file(path),'native_gear':gear,'gear_total':sum(gear.values()),
            'flask_delta_observed':diff,'flask_native_verified_for_case':True,
            'oil_fixed_user_confirmed':dict(OIL),'oil_isolated_simc_verified':False,
            'four_piece_verified':False,'actual_six_gems_verified':False}


def plan_from_budget(gear_total, gem_budget=GEMS, flask_budget=FLASK, oil=OIL,
                     external_fixed=None, locked_special_gear=None,
                     min_share=DEFAULT_MIN, max_share=DEFAULT_MAX,
                     max_seeds=20, diversity=0.10):
    """Engine optimizes candidate FINAL APPLIED rating with fixed offsets intact.

    gear, gems, flask are the abstract redistributable pool except locked special
    gear. Oil is fixed; other fixed secondaries (trinket/enchant/food) stay outside
    the pool but are included in applied-target caps and actual SimC evaluation.
    """
    check(type(gear_total) is int and gear_total >= 0,'BAD_GEAR_BUDGET')
    check(type(gem_budget) is int and gem_budget >= 0,'BAD_GEM_BUDGET')
    check(type(flask_budget) is int and flask_budget >= 0,'BAD_FLASK_BUDGET')
    check(type(max_seeds) is int and 1<=max_seeds<=64,'BAD_SEED_COUNT')
    check(all(type(v) in (int,float) and math.isfinite(v) for v in (min_share,max_share,diversity)),'INVALID_RATIO')
    check(0 <= min_share <= max_share <=1 and 0<=diversity<=1,'INVALID_RATIO')
    fix=dict(oil);extra=dict(external_fixed or {k:0 for k in STATS})
    special=dict(locked_special_gear or {k:0 for k in STATS})
    for record in (fix,extra,special):
        check(set(record)==set(STATS),'INCOMPLETE_FIXED_STAT_VECTOR')
        check(all(type(record[k]) is int and record[k]>=0 for k in STATS),'INVALID_FIXED_STAT_VECTOR')
    pool=gear_total+gem_budget+flask_budget
    check(sum(special.values())<=gear_total,'LOCKED_SPECIAL_EXCEEDS_GEAR')
    total=pool+sum(fix.values())+sum(extra.values())
    mins={k:max(special[k],0,math.ceil(min_share*total-1e-10)-fix[k]-extra[k]) for k in STATS}
    maxs={k:min(pool,math.floor(max_share*total+1e-10)-fix[k]-extra[k]) for k in STATS}
    check(all(mins[k]<=maxs[k] for k in STATS),'FINAL_APPLIED_CAP_BLOCKED_BY_FIXED_STAT')
    check(sum(mins.values())<=pool<=sum(maxs.values()),'FINAL_APPLIED_BOUNDS_INFEASIBLE')
    # v017 uses compact names crit/haste/mastery/vers; JSON2 uses *_rating.
    compact = dict(zip(allocation.STATS, STATS))
    v017_budget={'budget_resolved':True,'total':pool,
                 'locked_special_secondary':{s:special[k] for s,k in compact.items()},
                 'minimum_absolute_inclusive':{s:mins[k] for s,k in compact.items()},
                 'maximum_absolute_inclusive':{s:maxs[k] for s,k in compact.items()}}
    seeds=allocation.diverse_seeds(v017_budget,max_seeds,diversity)
    result=[]
    for i,s in enumerate(seeds,1):
        vector={k:int(s['vector'][j]) for j,k in enumerate(STATS)}
        applied={k:vector[k]+fix[k]+extra[k] for k in STATS}
        check(sum(applied.values())==total,'FINAL_APPLIED_TOTAL_MISMATCH')
        check(all(applied[k]>=special[k]+fix[k]+extra[k] for k in STATS),'LOCKED_GEAR_OR_OIL_REASSIGNED')
        result.append({'index':i,'seed_label':s['seed_label'],'redistributable_pool_target':vector,
                       'final_applied_chmv_target':applied,'final_applied_total':total,
                       'simc_actual_gems_applied':False,'simc_chmv_injection_verified':False,'dps':None})
    return {'schema':'SimCFinalAppliedCHMVOfflinePlan-v022','status':'OFFLINE_FIXED_OIL_AWARE_SEEDS',
            'gear_budget_type':'NATIVE_SAMPLE_OR_EXPLICIT_INPUT','gear_budget':gear_total,
            'general_gems_abstract':gem_budget,'flask_abstract':flask_budget,
            'oil_fixed':fix,'other_fixed_outside_pool':extra,
            'locked_special_gear_within_pool':special,'pool_total':pool,
            'final_applied_total':total,'final_applied_share_bounds':[min_share,max_share],
            'candidate_count':len(result),'candidates':result,
            'oil_isolated_simc_verified':False,'gem_injection_verified':False,
            'final_chmv_injection_verified':False,'simc_executed':False,
            'four_piece_verified':False,'full_optimizer_ready':False,
            'warnings':['The flask/gem pool uses the approved continuous-budget approximation; discrete physical items are not yet represented.',
                        'Weapon oil grants fixed +16 crit and +16 haste; it cannot be reassigned.',
                        'Actual SimC gear, gems, flask, oil, trinket, enchant and food effects must reconcile before live CHMV optimizer runs.',
                        'Existing v016/v017 legacy contract totals omit oil: do not label them final-applied totals.']}


def make_case_profile(original,out_json,variant):
    check(variant in ('oil_only','flask_and_oil'),'UNKNOWN_VARIANT')
    profile=attribution.make_profile(original,out_json,'neutral' if variant=='oil_only' else 'flask_only')
    check('temporary_enchant=disabled' in profile,'OIL_DISABLED_LINE_MISSING')
    profile=profile.replace('temporary_enchant=disabled','temporary_enchant=main_hand:thalassian_phoenix_oil_2')
    check(profile.count('temporary_enchant=')==1,'MULTIPLE_OIL_CONFIG_LINES')
    check('food=disabled' in profile and 'augmentation=disabled' in profile,'OTHER_BUFFS_NOT_NEUTRAL')
    return profile


def local_probe(executable, original, neutral, output):
    exe=Path(executable).resolve()
    check(exe.is_file(),'SIMC_BINARY_MISSING')
    check(sha_file(exe)==attribution.BINARY_SHA,'SIMC_BINARY_SHA_MISMATCH')
    reports={}
    for variant in ('oil_only','flask_and_oil'):
        jp=output/(variant+'.json'); sp=output/(variant+'.simc')
        sp.write_text(make_case_profile(original,jp,variant),encoding='utf-8')
        try:
            p=subprocess.run([str(exe),str(sp)],timeout=90,capture_output=True,text=True,encoding='utf-8',errors='replace')
            code,stdout,stderr=p.returncode,p.stdout,p.stderr
        except subprocess.TimeoutExpired as e:
            code,stdout,stderr=None,str(e.stdout or ''),str(e.stderr or '')+'\nTIMEOUT'
        (output/(variant+'_stdout.txt')).write_text(stdout,encoding='utf-8')
        (output/(variant+'_stderr.txt')).write_text(stderr,encoding='utf-8')
        obj={'exit_code':code,'json2_created':jp.is_file(),'stat_delta_verified':False}
        if code==0 and jp.is_file():
            try:
                doc=json.loads(jp.read_text(encoding='utf-8-sig'))
                snap=attribution.snapshot(doc)
                check(snap['gear_secondary']==neutral['native_gear'],'GEAR_CHANGED_IN_OIL_PROBE')
                expected={k:neutral['native_gear'][k]+OIL[k]+(FLASK if variant=='flask_and_oil' and k=='haste_rating' else 0) for k in STATS}
                obj.update({'expected_applied_stats':expected,'observed':snap,'stat_delta_verified':snap['buffed_rating']==expected})
            except (KeyError,ValueError,TypeError,IndexError) as exc:
                obj['analysis_error']=str(exc)
        reports[variant]=obj
    reports['all_verified']=all(reports[v]['stat_delta_verified'] for v in ('oil_only','flask_and_oil'))
    return reports


def make_report(args):
    observed=read_v021()
    plan=plan_from_budget(observed['gear_total'])
    # Original sample baseline is already attached as v020 immutable evidence; no SimC rerun.
    _,original=attribution.inspect()
    outroot=Path(args.output_root).resolve();outroot.mkdir(parents=True,exist_ok=True)
    output=outroot/(dt.datetime.now(dt.timezone.utc).strftime('RUN_%Y%m%dT%H%M%S_%fZ_')+uuid.uuid4().hex[:8]);output.mkdir()
    report={'schema':'SimCFinalAppliedCHMVReceipt-v022','phase':'V022_FIXED_OIL_BUDGET_AND_PROBE',
            'v021_actual_evidence':observed,'plan':plan,
            'user_oil_policy':'FIXED_16_CRIT_AND_16_HASTE_INCLUDED_IN_FINAL_SIMC_TARGET',
            'user_input_values_confirmed':True,'mode':args.mode,'oil_probe':None,
            'simc_executed_new':False,'actual_gems_applied':False,
            'dps_optimization_performed':False,'work_os_state_changed':False}
    if args.mode=='local-probe':
        check(args.simc_executable,'SIMC_BINARY_REQUIRED')
        report['oil_probe']=local_probe(args.simc_executable,original,observed,output)
        report['simc_executed_new']=True
    report['status']=('OIL_PROBE_PASS' if report['oil_probe']['all_verified'] else 'OIL_PROBE_REQUIRES_REVIEW') if report['oil_probe'] is not None else 'OFFLINE_PLAN_PASS'
    report_path=output/'FINAL_APPLIED_CHMV_RECEIPT_v022.json'
    report_path.write_text(json.dumps(report,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
    archive=output/'FINAL_APPLIED_CHMV_RESULTS_v022.zip'
    with zipfile.ZipFile(archive,'w',compression=zipfile.ZIP_DEFLATED) as z:
        for f in sorted(output.iterdir()):
            if f.is_file() and f != archive:z.write(f,arcname=f.name)
    with zipfile.ZipFile(archive) as z:check(z.testzip() is None,'OUTPUT_ZIP_BAD_CRC')
    print('[RESULT]',report['status'])
    print('[NATIVE_GEAR_CHMV]',observed['gear_total'])
    print('[POOL_GEAR_GEM_FLASK]',plan['pool_total'])
    print('[FIXED_OIL]',plan['oil_fixed'])
    print('[FINAL_APPLIED_TARGET_WITHOUT_EXTERNAL_FIXED]',plan['final_applied_total'])
    print('[REAL_SIMC_GEMS_INJECTION_VERIFIED] false')
    print('[RESULT_FILE]',archive)
    print('[OUTPUT_FOLDER]',output)
    try:
        if os.name=='nt':os.startfile(str(output))
    except (OSError,AttributeError):pass
    return 0 if report['status']!='OIL_PROBE_REQUIRES_REVIEW' else 2


def main():
    p=argparse.ArgumentParser(description='v022 fixed oil aware CHMV target; no DPS optimization')
    p.add_argument('--mode',choices=['inspect','local-probe'],default='inspect')
    p.add_argument('--simc-executable',default=None)
    p.add_argument('--output-root',default=str(ROOT/'V022_OUTPUTS'))
    args=p.parse_args()
    try:return make_report(args)
    except (ValueError,OSError,KeyError,TypeError,zipfile.BadZipFile) as exc:
        print('[FAIL]',type(exc).__name__,exc)
        return 2

if __name__=='__main__':sys.exit(main())
