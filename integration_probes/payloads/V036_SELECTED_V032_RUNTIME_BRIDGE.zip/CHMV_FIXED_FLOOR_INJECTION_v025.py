#!/usr/bin/env python3
"""v025: conservative CHMV candidate injection + two-case pinned SimC probe.

User-approved identity: native gear budget; gems/flask abstract CHMV; oil and
special-item raw secondary floors fixed; external fixed trinket/enchant ratings
outside optimization pool. Actual gear_* stat contribution (including gems,
trinket static and enchants) is a probe hypothesis for the pinned SimC binary.

No gem socketing, 4pc semantics, or adaptive DPS optimizer execution is claimed.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid
import zipfile

import CHMV_FINAL_APPLIED_v022 as budget
import SIMC_STAT_ATTRIBUTION_v021 as stat
import SIMC_NATIVE_CHMV_AUTHORITY_v023 as native

ROOT=Path(__file__).resolve().parent
STATS=stat.STATS
OVERRIDE_OPTIONS={
    'crit_rating':'gear_crit_rating',
    'haste_rating':'gear_haste_rating',
    'mastery_rating':'gear_mastery_rating',
    'versatility_rating':'gear_versatility_rating',
}
ZERO={k:0 for k in STATS}
FLASK_OIL={k:(165 if k=='haste_rating' else 0)+budget.OIL[k] for k in STATS}
PINNED_SIMC_BINARY_SHA=stat.BINARY_SHA
PROBE_GEAR={'crit_rating':892,'haste_rating':820,'mastery_rating':822,'versatility_rating':313}


def need(ok,code):
    if not ok:raise ValueError(code)


def read_vector(vec,label):
    need(type(vec) is dict and set(vec)==set(STATS),label+'_STAT_KEY_MISMATCH')
    need(all(type(vec[k]) is int and vec[k]>=0 for k in STATS),label+'_INVALID_NONNEGATIVE_INTEGER')
    return dict(vec)


def verify_fixed_floor(final_target,oil=None,special=None,external=None):
    """Allow only candidates meeting independent fixed vectors and their sum."""
    final=read_vector(final_target,'FINAL')
    oil=read_vector(budget.OIL if oil is None else oil,'OIL')
    special=read_vector(ZERO if special is None else special,'SPECIAL')
    external=read_vector(ZERO if external is None else external,'EXTERNAL')
    for k in STATS:
        need(final[k]>=oil[k]+special[k]+external[k],'FIXED_FLOOR_VIOLATION:'+k)
    return True


def gear_override_for_final(final_target,nongear_native):
    """gear_* encodes ALL overridden equipment contribution, including static
    item/gem/enchant/trinket ratings. Subtract only separately applied nongear
    effects (e.g. active native flask/oil), NOT the equipment-fixed E vector.

    Zero is blocked because SimC docs warn gear_*=0 may mean no override.
    Actual binary semantics remain probe-gated.
    """
    final=read_vector(final_target,'FINAL')
    outside=read_vector(nongear_native,'NONGEAR')
    mapped={k:final[k]-outside[k] for k in STATS}
    need(all(mapped[k]>0 for k in STATS),'UNREPRESENTABLE_NONPOSITIVE_GEAR_OVERRIDE')
    return {OVERRIDE_OPTIONS[k]:mapped[k] for k in STATS}


def candidate_contract(gear_budget,selected_index=0,special=None,external=None,max_seeds=20):
    """Uses v022/v017 math unchanged; a demonstration, not a real special item."""
    special=read_vector(ZERO if special is None else special,'SPECIAL')
    external=read_vector(ZERO if external is None else external,'EXTERNAL')
    plan=budget.plan_from_budget(gear_budget,locked_special_gear=special,
                                 external_fixed=external,max_seeds=max_seeds)
    need(0<=selected_index<len(plan['candidates']),'UNKNOWN_SEED_INDEX')
    item=plan['candidates'][selected_index]
    pool=read_vector(item['redistributable_pool_target'],'POOL')
    final=read_vector(item['final_applied_chmv_target'],'FINAL')
    verify_fixed_floor(final,special=special,external=external)
    need(sum(pool.values())==plan['pool_total'],'POOL_SUM_CHANGED')
    need(sum(final.values())==plan['final_applied_total'],'APPLIED_SUM_CHANGED')
    residual={k:pool[k]-special[k] for k in STATS}
    need(all(v>=0 for v in residual.values()),'SPECIAL_FLOOR_REASSIGNED')
    need(sum(residual.values())==plan['pool_total']-sum(special.values()),'FREE_POOL_DOUBLE_COUNT')
    return {'schema':'CHMVFixedFloorCandidate-v025','budget':{
              'native_gear':gear_budget,'six_gems_abstract':138,'flask_abstract':165,
              'oil_fixed':dict(budget.OIL),'special_gear_fixed_inside_native_gear':special,
              'outside_pool_fixed_equipment':external,'free_total':sum(residual.values()),
              'pool_total':plan['pool_total'],'final_total':plan['final_applied_total']},
            'candidate_index':item['index'],'seed_label':item['seed_label'],
            'free_movable':residual,'pool_including_special':pool,'final_applied_target':final,
            'actual_simc_injection_verified':False,'gem_equipped':False,'dps':None,
            'synthetic_special_floor_if_nonzero':any(special.values()),
            'note':'No special item ID supplied: any synthetic floor is an offline math example.'}


def injection_contract(candidate,nongear_native):
    """Produce explicit intended options. This does not prove SimC support."""
    external=candidate['budget']['outside_pool_fixed_equipment']
    special=candidate['budget']['special_gear_fixed_inside_native_gear']
    a=candidate['final_applied_target']
    verify_fixed_floor(a,special=special,external=external)
    overrides=gear_override_for_final(a,nongear_native)
    # External trinket/enchant stat E MUST remain in gear_* if overwritten.
    need(sum(overrides.values())+sum(nongear_native.values())==sum(a.values()),'DUPLICATED_OR_MISSING_STATIC_RATING')
    return {'schema':'CHMVCandidateInjection-v025','target_final':dict(a),
            'expected_nongear_additive_native':dict(nongear_native),
            'gear_override_total_includes_external_equipment_fixed':True,
            'gear_override_options':overrides,'stat_sum_exact_offline':True,
            'binary_injection_observed':False,
            'blocked_if_any_gear_override_nonpositive':True,
            'warning':'Only actual JSON2 after SimC execution can prove the final applied CHMV and nonstat effects.'}


def make_probe_profile(baseline_profile,out_json,case):
    """Two low-cost profile probes with identical pinned items/talents/APL.

    Case 'neutral': no flask, oil or food; final expected == PROBE_GEAR.
    Case 'flask_oil': +165 haste flask and +16crit/+16haste oil; final
                        expected == PROBE_GEAR + FLASK_OIL.
    """
    need(case in ('neutral','flask_oil'),'UNKNOWN_PROBE_CASE')
    for line in baseline_profile.splitlines():
        need(not re.match(r'\s*gear_(?:crit|haste|mastery|versatility)_rating\s*=',line),
             'BASELINE_ALREADY_HAS_GEAR_OVERLAY')
    p=stat.make_profile(baseline_profile,Path(out_json),'neutral' if case=='neutral' else 'flask_only')
    if case=='flask_oil':
        need('temporary_enchant=disabled' in p,'OIL_SWITCH_MISSING')
        p=p.replace('temporary_enchant=disabled','temporary_enchant=main_hand:thalassian_phoenix_oil_2')
    offsets=ZERO if case=='neutral' else FLASK_OIL
    final_target={k:PROBE_GEAR[k]+offsets[k] for k in STATS}
    options=gear_override_for_final(final_target,offsets)
    # Keep explicit overrides unambiguous and after class/items, before output.
    need(p.count('json2=')==1,'JSON2_OUTPUT_NOT_UNIQUE')
    anchor='json2='+str(Path(out_json).resolve())
    need(anchor in p,'JSON2_PATH_NOT_FOUND')
    injection='\n'.join(f'{key}={val}' for key,val in options.items())
    p=p.replace(anchor,injection+'\n'+anchor)
    need(all(p.count(opt+'=')==1 for opt in options),'DUPLICATE_GEAR_OVERLAYS')
    need('source=local' in p,'LOCAL_ITEM_SOURCE_MISSING')
    return p,final_target,options


def judge_json2(doc,expected,reference_gear):
    observed=stat.snapshot(doc)
    need(observed['simc_git_revision']=='7bc1071','SIMC_BUILD_CHANGED')
    need(observed['simc_build']=='12.1.5.70448','SIMC_GAME_BUILD_CHANGED')
    need(observed['gear_secondary']==reference_gear,'GEAR_ITEMS_CHANGED')
    expected=read_vector(expected,'EXPECTED')
    applied=observed['buffed_rating']
    exact={k:(applied[k]==expected[k]) for k in STATS}
    return {'observed_final':applied,'expected_final':expected,'per_stat_exact':exact,
            'all_stats_exact':all(exact.values()),'native_gear_item_stats_unchanged':True,
            'simc_build':observed['simc_build'],'git_revision':observed['simc_git_revision'],
            'flask':observed['flask'],'temporary_enchant':observed['temporary_enchant']}


def run_user_pc(executable,profile,reference_gear,out):
    exe=Path(executable).resolve()
    need(exe.is_file(),'SIMC_BINARY_NOT_FOUND')
    need(stat.sha_file(exe)==PINNED_SIMC_BINARY_SHA,'SIMC_BINARY_SHA_CHANGED')
    result={}
    for case in ('neutral','flask_oil'):
        jp=out/f'{case}.json';sp=out/f'{case}.simc'
        src,expected,opts=make_probe_profile(profile,jp,case)
        sp.write_text(src,encoding='utf-8')
        record={'exit_code':None,'json2_created':False,'exact_chmv':False,
                'expected_final':expected,'gear_overrides':opts,'reason':None}
        try:
            p=subprocess.run([str(exe),str(sp)],capture_output=True,text=True,
                     encoding='utf-8',errors='replace',timeout=90)
            record['exit_code']=p.returncode;so=p.stdout;se=p.stderr
        except subprocess.TimeoutExpired as err:
            so=str(err.stdout or '');se=str(err.stderr or '')+'\nTIMEOUT';record['reason']='TIMEOUT'
        (out/f'{case}_stdout.txt').write_text(so,encoding='utf-8')
        (out/f'{case}_stderr.txt').write_text(se,encoding='utf-8')
        record['json2_created']=jp.is_file()
        if record['exit_code']==0 and jp.is_file():
            try:
                check=judge_json2(json.loads(jp.read_text(encoding='utf-8-sig')),expected,reference_gear)
                record['observed']=check
                record['exact_chmv']=check['all_stats_exact']
                if not record['exact_chmv']:record['reason']='FINAL_APPLIED_CHMV_MISMATCH'
            except (KeyError,ValueError,TypeError,IndexError) as err:
                record['reason']=type(err).__name__+':'+str(err)
        elif record['reason'] is None:record['reason']='SIMC_EXIT_OR_JSON2_MISSING'
        result[case]=record
    result['both_exact']=all(result[c]['exact_chmv'] for c in ('neutral','flask_oil'))
    return result


def save(out,rec):
    out.write_text(json.dumps(rec,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')


def main(argv=None):
    ap=argparse.ArgumentParser(description='v025 fixed floor + low-cost native gear override probe')
    ap.add_argument('--mode',choices=('inspect','local-probe'),default='inspect')
    ap.add_argument('--simc-executable',default=None)
    ap.add_argument('--output-root',default=str(ROOT/'V025_OUTPUTS'))
    args=ap.parse_args(argv)
    try:
        baseline,receipt,profile=stat.load_baseline()
        native_receipt,oil,both=native.read_v022()
        authority=native.authority_record(native_receipt,oil,both)
        gear=authority['native_gear_rating_total']
        need(gear==2847,'NATIVE_BUDGET_UNEXPECTED')
        known=stat.snapshot(baseline)
        need(known['gear_total']==gear,'NATIVE_BASELINE_MISMATCH')
        # Synthetic example demonstrates floor; it is NOT an observed special item.
        sample_lock={'crit_rating':150,'haste_rating':0,'mastery_rating':100,'versatility_rating':0}
        demo=candidate_contract(gear,special=sample_lock)
        zero_lock=candidate_contract(gear)
        injection=injection_contract(zero_lock,ZERO)
        out=Path(args.output_root).resolve()/('RUN_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ_')+uuid.uuid4().hex[:8])
        out.mkdir(parents=True,exist_ok=False)
        probe=None
        if args.mode=='local-probe':
            need(args.simc_executable is not None,'SIMC_EXECUTABLE_REQUIRED')
            probe=run_user_pc(args.simc_executable,profile,known['gear_secondary'],out)
        report={'schema':'SIMCSecondaryCHMVInjectionReceipt-v025',
                'status':'OFFLINE_INJECTION_CONTRACT_ONLY' if probe is None else
                         ('GEAR_OVERRIDE_NATIVE_PROBE_PASS' if probe['both_exact'] else 'GEAR_OVERRIDE_NATIVE_PROBE_FAIL_REVIEW'),
                'mode':args.mode,'simc_executed':probe is not None,
                'user_pc_native_probe':probe,
                'native_gear_source':'V020_V021_V022_JSON2_334_ARCANE_TWO_HAND',
                'native_gear_budget':gear,'v024_special_gem_choice_untouched':True,
                'synthetic_floor_example_not_real_gear':demo,
                'no_special_floor_example':zero_lock,
                'candidate_injection_offline_example':injection,
                'gear_override_semantics_in_this_binary_verified':bool(probe and probe['both_exact']),
                'special_gear_with_effects_preserved_verified':False,
                'trinket_and_enchant_fixed_injection_verified':False,
                'six_gems_physically_socketed_and_crit_damage_verified':False,
                'four_piece_effect_verified':False,
                'full_optimizer_ready':False,
                'warnings':['SimC official gear_* docs include gems and enchants within overridden gear contribution.',
                            'Trinket/enchant static rating E must be present inside the gear override target, not added again.',
                            'The selected actual binary and item effects require direct JSON2 evidence.',
                            'Native haste flask introduces a fixed +165 to this physical probe; low-haste continuous targets may require a different nongear configuration.',
                            'SimC zero gear override may not mean zero; refuse nonpositive gear input until alternate method is verified.',
                            'This is a constrained one-profile injection probe, not the actual-gems DPS optimizer.']}
        save(out/'CHMV_INJECTION_RECEIPT_v025.json',report)
        zip_path=out/'CHMV_INJECTION_RESULTS_v025.zip'
        with zipfile.ZipFile(zip_path,'w',zipfile.ZIP_DEFLATED) as z:
            for f in sorted(out.iterdir()):
                if f!=zip_path and f.is_file():z.write(f,f.name)
        with zipfile.ZipFile(zip_path) as z:need(z.testzip() is None,'OUTPUT_ZIP_CORRUPTED')
        print('[RESULT]',report['status'])
        print('[NATIVE_GEAR]',gear,'[ABSTRACT_GEMS]',138,'[FLASK]',165,'[OIL]',32)
        print('[RESULT_ZIP]',zip_path)
        print('[OUTPUT_FOLDER]',out)
        try:
            if os.name=='nt':os.startfile(str(out))
        except (OSError,AttributeError):pass
        return 0 if probe is None or probe['both_exact'] else 2
    except (ValueError,KeyError,TypeError,OSError,zipfile.BadZipFile) as exc:
        print('[FAIL]',type(exc).__name__,str(exc));return 2


if __name__=='__main__':sys.exit(main())
