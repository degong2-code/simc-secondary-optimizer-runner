#!/usr/bin/env python3
"""v029 bounded four-stat exploratory search, with candidate-specific native flasks.

Uses v027 native gem profile and v028 real DPS evidence only on byte-semantic
matching. SimC owns all effect/DPS semantics. This is a bounded product pilot.
Not a global optimum or season-wide equipment/embellishment compiler.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid
import zipfile

import CHMV_ADAPTIVE_v015 as adaptive
import CHMV_FIXED_FLOOR_INJECTION_v025 as injection
import CHMV_DPS_INTEGRATION_v028 as old

HERE=Path(__file__).resolve().parent
STATS=old.STATS
OIL=old.OIL
TOTAL=old.FINAL_TOTAL
GEM_CHOICES=old.GEM_CHOICES
EXPECTED_REV=old.EXPECTED_REV
EXPECTED_BUILD=old.EXPECTED_BUILD
FLASK_AMOUNT=165
FLASKS={
    'crit_rating':'flask_of_the_shattered_sun_2',
    'haste_rating':'flask_of_the_blood_knights_2',
    'mastery_rating':'flask_of_the_magisters_2',
    'versatility_rating':'flask_of_thalassian_resistance_2',
}
ALIAS={'crit':'crit_rating','haste':'haste_rating','mastery':'mastery_rating','versatility':'versatility_rating'}
LEGACY=HERE/'EVIDENCE_V029_INPUTS'/'NATIVE_ADAPTIVE_DPS_RESULTS_v028_USER_PC.zip'
LEGACY_SHA='9d7687e90c5261bb10f7ac3819a56c8ca5d6e075c49090c42fd7097b52c7f286'
SCOUTS=6
CONFIRMS=2
ADAPT_STEP=240

class Rejected(ValueError):pass

def need(cond,code):
    if not cond:raise Rejected(code)

def sha(data:bytes)->str:return hashlib.sha256(data).hexdigest()
def sha_file(file):
    h=hashlib.sha256()
    with open(file,'rb') as f:
        for part in iter(lambda:f.read(1<<20),b''):h.update(part)
    return h.hexdigest()

def save(file,data):
    Path(file).write_text(json.dumps(data,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')

def valid(vec,locked=None):
    if not isinstance(vec,tuple) or len(vec)!=4 or any(type(x)!=int or x<0 for x in vec):return False
    if sum(vec)!=TOTAL:return False
    locked=locked or dict.fromkeys(STATS,0)
    if set(locked)!=set(STATS):return False
    if any(type(locked[k])!=int or locked[k]<0 for k in STATS):return False
    if any(vec[i]<OIL[k]+locked[k] or vec[i]>TOTAL//2 for i,k in enumerate(STATS)):return False
    return True

def select_flask(vec,policy='auto'):
    need(valid(vec),'INVALID_FINAL_CHMV_CANDIDATE')
    need(policy=='auto' or policy in ALIAS,'UNKNOWN_FLASK_POLICY')
    if policy=='auto':
        stat=max(STATS,key=lambda x:(vec[STATS.index(x)],-STATS.index(x)))
    else:stat=ALIAS[policy]
    need(vec[STATS.index(stat)]>=FLASK_AMOUNT,'SELECTED_FLASK_STAT_TOO_LOW:'+stat)
    return stat,FLASKS[stat]

def overrides(vec,policy='auto'):
    stat,token=select_flask(vec,policy)
    contribution={k:(FLASK_AMOUNT if k==stat else 0) for k in STATS}
    actual=dict(zip(STATS,vec))
    over=injection.gear_override_for_final(actual,contribution)
    need(all(type(x)==int and x>=0 for x in over.values()),'INVALID_NATIVE_OVERRIDE')
    need(sum(over.values())+FLASK_AMOUNT==TOTAL,'OVERRIDE_SUM_MISMATCH')
    return stat,token,over

def seed_candidates(baseline):
    """One measured baseline plus 4 wide four-coordinate seeds.

    Each focus stat receives about 43% of TOTAL and the other three split the
    remainder, independent of v028's one-direction nearest-neighbor limitation.
    This is a scouting policy, *not* an asserted optimizer optimum.
    """
    need(valid(baseline),'BAD_NATIVE_BASELINE')
    out=[baseline]
    focus=round(TOTAL*.43)
    low=(TOTAL-focus)//3
    for axis in range(4):
        vals=[low]*4
        vals[axis]=focus
        vals[(axis+1)%4]+=TOTAL-sum(vals)
        v=tuple(vals)
        need(valid(v),'INVALID_FOCUSED_SEED')
        if v not in out:out.append(v)
    need(len(out)==5,'NOT_FIVE_DISTINCT_INITIAL_SEEDS')
    return tuple(out)

def adaptive_candidate(records,step=ADAPT_STEP):
    need(bool(records),'MISSING_OBSERVATIONS')
    # Real v015 directional-score heuristic, all 12 possible directed exchanges.
    data={tuple(r['candidate'][k] for k in STATS):[r] for r in records}
    seen=set(data)
    for anchor in sorted(seen,key=lambda v:(-data[v][-1]['dps_mean'],v)):
        options=[]
        for i in range(4):
            for j in range(4):
                if i==j:continue
                vec=list(anchor);vec[i]-=step;vec[j]+=step
                candidate=tuple(vec)
                if valid(candidate) and candidate not in seen and candidate not in options:
                    options.append(candidate)
        if options:
            options.sort(key=lambda v:(-adaptive.score_direction(anchor,v,data,step),v))
            return options[0],{'anchor':list(anchor),'method':'V015_ALL_12_DIRECTIONS','step':step,
                               'directional_score':adaptive.score_direction(anchor,options[0],data,step)}
    raise Rejected('NO_NEW_ADAPTIVE_CANDIDATE')

def semantic_profile(inp):
    """Only json2 path is intentionally non-semantic for cached SimC jobs."""
    lines=[]
    for line in inp.replace('\r\n','\n').lstrip('\ufeff').split('\n'):
        if line.startswith('json2='):
            lines.append('json2=<OUTPUT>')
        else:lines.append(line)
    return '\n'.join(lines).strip()+'\n'

def make_profile(source,out,vec,iterations,policy='auto'):
    need(valid(vec),'INVALID_FINAL_CHMV_CANDIDATE')
    need(type(iterations)==int and 60<=iterations<=1500,'INVALID_ITERATION_COUNT')
    stat,token,over=overrides(vec,policy)
    replace={**old.REQUIRED_OPTIONS,'iterations':str(iterations)}
    lines=[];seen={};flask_found=0
    for row in source.replace('\r\n','\n').splitlines():
        if row.startswith('json2=') or re.match(r'^gear_(?:crit|haste|mastery|versatility)_rating=',row):continue
        if row.startswith('flask='):
            flask_found+=1
            need(flask_found==1,'DUPLICATE_FLASK')
            lines.append('flask='+token)
            continue
        key=row.partition('=')[0]
        if key in replace:
            seen[key]=seen.get(key,0)+1
            need(seen[key]==1,'DUPLICATE_SIMC_OPTION:'+key)
            lines.append(key+'='+replace[key])
        else:lines.append(row)
    need(flask_found==1,'MISSING_FLASK_CONFIGURATION')
    need(set(seen).issuperset({'iterations','max_time','desired_targets','fight_style',
                              'fixed_time','vary_combat_length','threads',
                              'calculate_scale_factors','item_db_source'}),'REQUIRED_OPTION_MISSING')
    if 'optimal_raid' not in seen:lines.append('optimal_raid=1')
    else:need(seen['optimal_raid']==1,'DUPLICATE_RAID_OPTION')
    for k,val in over.items():lines.append(k+'='+str(val))
    output=Path(out).resolve()
    need(output.name.endswith('.json') and '\n' not in str(output),'INVALID_OUTPUT_PATH')
    lines.append('json2='+str(output))
    content='\n'.join(lines)+'\n'
    need(content.count('temporary_enchant=main_hand:thalassian_phoenix_oil_2')==1,'OIL_CONFIGURATION_MISSING')
    need(content.count('flask=')==1,'FLASK_CONFIGURATION_NOT_SINGLE')
    need(len([x for x in lines if x.partition('=')[0] in over])==4,'NOT_FOUR_GEAR_OVERRIDES')
    return content,{'stat':stat,'token':token,'gear_override':over}

def parse_native(doc,vec,iterations,ref,flask_token):
    need(doc.get('report_version')=='2.0.0','SIMC_JSON2_SCHEMA_CHANGED')
    snap=old.native.snapshot(doc)
    need(snap['simc_git_revision']==EXPECTED_REV and snap['simc_build']==EXPECTED_BUILD,
         'SIMC_VERSION_OR_BUILD_MISMATCH')
    need(snap['item_identity']==ref['reference']['item_identity'],'EQUIPMENT_IDENTITY_CHANGED')
    need(snap['gear_secondary']==ref['simc_gear_secondary'],'NATIVE_GEAR_SECONDARY_CHANGED')
    need(old.gems.parse_gem_ids(doc['sim']['players'][0]['gear'])==ref['gem_ids'],
         'GEM_IDENTITY_CHANGED')
    need('thalassian_phoenix_oil' in str(snap['temporary_enchant']),'OIL_REMOVED')
    need(snap['flask']==flask_token,'NATIVE_FLASK_DIFFERENT:'+str(snap['flask']))
    target=dict(zip(STATS,vec))
    need(snap['buffed_rating']==target,'FINAL_APPLIED_CHMV_MISMATCH:'+str(snap['buffed_rating']))
    opts=doc['sim']['options']
    for name,val in [('iterations',iterations),('max_time',300),('vary_combat_length',0),
                     ('fixed_time',1),('desired_targets',1),('optimal_raid',1)]:
        observed=opts.get(name)
        need(isinstance(observed,(bool,int,float)) and float(observed)==float(val),'OPTION_MISMATCH:'+name)
    need(opts.get('fight_style')=='Patchwerk','FIGHT_STYLE_CHANGED')
    need(len(doc['sim']['players'])==1,'UNEXPECTED_PLAYER_COUNT')
    p=doc['sim']['players'][0];d=p['collected_data']['dps']
    mean=float(d['mean']);sem=float(d['mean_std_dev']);count=d['count']
    need(math.isfinite(mean) and mean>0,'BAD_DPS_MEAN')
    need(math.isfinite(sem) and sem>0,'BAD_DPS_SEM')
    need(type(count)==int and count>=int(iterations*.9),'INSUFFICIENT_SAMPLES')
    need(isinstance(opts.get('seed'),(int,float)),'SIMC_SEED_MISSING')
    z=float(opts.get('confidence_estimator',1.9599639854))
    need(1.8<z<2.2,'UNKNOWN_CONFIDENCE_ESTIMATOR')
    return {'dps_mean':mean,'mean_standard_error':sem,'ci95_half_width':sem*z,
            'dps_sample_count':count,'iterations_requested':iterations,'simc_seed':opts['seed'],
            'final_applied_rating':snap['buffed_rating'],
            'flask_selected':flask_token,'native_items_and_gems_unchanged':True}

class Cache:
    def __init__(self,reference,gem_choice,enabled=True):
        self.records={};self.enabled=False;self.source_identity=LEGACY_SHA
        if not enabled:return
        need(LEGACY.is_file() and sha_file(LEGACY)==LEGACY_SHA,'V028_PREVIOUS_EVIDENCE_SHA_MISMATCH')
        with zipfile.ZipFile(LEGACY) as z:
            need(z.testzip() is None,'V028_PREVIOUS_EVIDENCE_CRC_FAIL')
            receipt=json.loads(z.read('NATIVE_ADAPTIVE_DPS_RECEIPT_v028.json'))
            need(receipt['status']=='PASS_BOUNDED_NATIVE_ADAPTIVE_DPS_PILOT', 'V028_NOT_COMPLETE')
            if receipt['gem_choice']!=gem_choice:return
            need(receipt['v027_evidence_sha256']==old.EVIDENCE_SHA,'V028_SOURCE_GEM_IDENTITY_MISMATCH')
            for case in ('SCOUT_01','SCOUT_02','SCOUT_03','CONFIRM_01','CONFIRM_02'):
                base=case+'/'
                meta=json.loads(z.read(base+'case_attempt_v028.json'))
                if meta['status']!='SIMC_DPS_AND_CHMV_PASS':continue
                prof=z.read(base+'input.simc')
                native_bytes=z.read(base+'result.json')
                need(sha(prof)==meta['input_sha256'] and sha(native_bytes)==meta['output_sha256'],
                     'V028_CASE_FILE_TAMPERING')
                vec=tuple(meta['candidate'][k] for k in STATS)
                payload=parse_native(json.loads(native_bytes),vec,meta['iterations_requested'],reference,
                                     FLASKS['haste_rating'])
                signature=sha(semantic_profile(prof.decode('utf-8-sig')).encode())
                self.records[signature]={'source_case':case,'run':payload,'candidate':vec,
                                         'iterations':meta['iterations_requested']}
        self.enabled=True
    def get(self,input_data,vec,iterations):
        sig=sha(semantic_profile(input_data).encode())
        r=self.records.get(sig)
        if r and r['candidate']==vec and r['iterations']==iterations:return r
        return None

def run_case(binary,source,folder,tag,vec,iterations,reference,policy,cache):
    folder.mkdir(exist_ok=False)
    input_path=folder/'input.simc';out=folder/'result.json'
    profile,flask=make_profile(source,out,vec,iterations,policy)
    input_path.write_text(profile,encoding='utf-8')
    rec={'case':tag,'candidate':dict(zip(STATS,vec)),
         'gear_override':flask['gear_override'], 'flask_stat':flask['stat'],
         'flask_token':flask['token'],'iterations_requested':iterations,
         'input_sha256':sha_file(input_path),'status':'ATTEMPTED', 'new_simc_call':False}
    try:
        cached=cache.get(profile,vec,iterations)
        if cached is not None:
            rec.update(cached['run']);rec['status']='VALIDATED_V028_CACHE_REUSE'
            rec['cache_source_case']=cached['source_case']
            (folder/'CACHE_PROVENANCE_v029.txt').write_text(
               'Validated user v028 result '+cached['source_case']+'; exact normalized SimC input,\n'
               'same simulation binary identity, case settings, CHMV and item profile.\n',encoding='utf-8')
            return rec
        need(sha_file(binary)==old.native.BINARY_SHA,'SIMC_BINARY_SHA_CHANGED_PRE_CALL')
        rec['new_simc_call']=True
        with (folder/'stdout.txt').open('w',encoding='utf-8') as so, (folder/'stderr.txt').open('w',encoding='utf-8') as se:
            proc=subprocess.run([str(binary),str(input_path)],cwd=str(binary.parent),
                stdout=so,stderr=se,stdin=subprocess.DEVNULL,timeout=900,check=False)
        rec['exit_code']=proc.returncode
        need(proc.returncode==0,'SIMC_EXIT_NONZERO:'+str(proc.returncode))
        need(out.is_file() and 0<out.stat().st_size<50_000_000,'SIMC_JSON2_MISSING')
        need(sha_file(binary)==old.native.BINARY_SHA,'SIMC_BINARY_SHA_CHANGED_POST_CALL')
        rec.update(parse_native(json.loads(out.read_text(encoding='utf-8-sig')),vec,iterations,
                                reference,flask['token']))
        rec['output_sha256']=sha_file(out)
        rec['status']='NATIVE_DPS_AND_STAT_PASS'
        return rec
    finally:save(folder/'case_attempt_v029.json',rec)

def settings(scout_iterations=120,confirm_iterations=320,policy='auto'):
    need(type(scout_iterations)==int and 60<=scout_iterations<=600,'SCOUT_ITERATIONS_OUT_OF_RANGE')
    need(type(confirm_iterations)==int and 150<=confirm_iterations<=1500,'CONFIRM_ITERATIONS_OUT_OF_RANGE')
    need(confirm_iterations>=scout_iterations,'CONFIRM_LT_SCOUT')
    need(policy=='auto' or policy in ALIAS,'UNKNOWN_FLASK_POLICY')
    return {'scouts':SCOUTS,'confirmations':CONFIRMS,'iterations_scout':scout_iterations,
            'iterations_confirm':confirm_iterations,'max_new_simc_calls':SCOUTS+CONFIRMS,
            'max_new_iterations':SCOUTS*scout_iterations+CONFIRMS*confirm_iterations,
            'flask_policy':policy,'full_four_stat_variation':True,'true_degrees_of_freedom':3,
            'user_approved_general_product_test':True,'not_work_os_m0':True,
            'fight_seconds':300,'desired_targets':1,'optimal_raid':True,
            'max_share':0.5,'native_budget_source':'V027_VALIDATED_ARCANE_334'}

def run(binary,reference,cfg,folder,cache):
    need(binary.is_file(),'SIMC_BINARY_MISSING')
    need(sha_file(binary)==old.native.BINARY_SHA,'SIMC_BINARY_HASH_MISMATCH')
    baseline=tuple(reference['raw_base'][k] for k in STATS)
    seeds=seed_candidates(baseline)
    scouting=[];confirms=[];attempts=[]
    report={'schema':'SIMCFourStatFlaskReceipt-v029','status':'PENDING',
            'settings':cfg,'budget':{'gear':old.GEAR_BUDGET,'gems':old.GEM_BUDGET,
                                    'flask':FLASK_AMOUNT,'fixed_oil':OIL,'total':TOTAL},
            'external_scenario_cache_reuse':cache.enabled,'legacy_v028_sha256':cache.source_identity,
            'global_optimum_claimed':False,'full_product_complete':False}
    try:
        for idx in range(SCOUTS):
            if idx<5:
                vec=seeds[idx];strategy='BASELINE' if idx==0 else f'FOCUS_{STATS[idx-1]}'
            else:
                vec,why=adaptive_candidate(scouting)
                strategy='DPS_GUIDED_ALL_12_DIRECTIONS';report['adaptive_rationale']=why
            tag='SCOUT_%02d'%(idx+1)
            attempts.append({'case':tag,'candidate':list(vec),'status':'ATTEMPTED'})
            print('[SCOUT]',idx+1,'/',SCOUTS,'CHMV',vec,'flask',select_flask(vec,cfg['flask_policy'])[1],flush=True)
            rec=run_case(binary,reference['source_simc'],folder/tag,tag,vec,cfg['iterations_scout'],
                         reference,cfg['flask_policy'],cache)
            rec['strategy']=strategy;scouting.append(rec)
            attempts[-1]['status']=rec['status']
            save(folder/'PROGRESS_v029.json',{'attempts':attempts,'current':tag})
        ranked=sorted(scouting,key=lambda r:(-r['dps_mean'],tuple(r['candidate'][k] for k in STATS)))
        pair=ranked[:2]
        for idx,seed in enumerate(pair):
            vec=tuple(seed['candidate'][k] for k in STATS)
            tag='CONFIRM_%02d'%(idx+1)
            attempts.append({'case':tag,'candidate':list(vec),'status':'ATTEMPTED'})
            print('[CONFIRM]',idx+1,'/',CONFIRMS,'CHMV',vec,flush=True)
            rec=run_case(binary,reference['source_simc'],folder/tag,tag,vec,cfg['iterations_confirm'],
                         reference,cfg['flask_policy'],cache)
            confirms.append(rec);attempts[-1]['status']=rec['status']
            save(folder/'PROGRESS_v029.json',{'attempts':attempts,'current':tag})
        # Reuse proven v015 uncertainty judgement, but only from fresh/equivalent
        # confirmation data and without accepting false significant differences.
        data={tuple(x['candidate'][k] for k in STATS):x for x in confirms}
        order=[tuple(x['candidate'][k] for k in STATS) for x in pair]
        judge=adaptive.judge(order,data)
        report.update({'status':'PASS_BOUNDED_FOUR_STAT_NATIVE_DPS',
                       'selected_top_two':[dict(zip(STATS,p)) for p in order],
                       'fresh_pair_judgment':judge})
    except (Exception,KeyboardInterrupt) as exc:
        report.update({'status':'PARTIAL_OR_BLOCKED','error':type(exc).__name__+':'+str(exc)})
    # Include a failed/aborted SimC attempt in live API call accounting as well;
    # a partial failure is never silently counted as zero work.
    attempt_receipts=[]
    for a in attempts:
        path=folder/a['case']/'case_attempt_v029.json'
        if path.is_file():attempt_receipts.append(json.loads(path.read_text(encoding='utf-8')))
    report.update({'scouts':scouting,'confirmations':confirms,'attempts':attempts,
                   'total_attempts':len(attempts),
                   'actual_new_simc_calls':sum(int(r.get('new_simc_call',False)) for r in attempt_receipts),
                   'exact_cache_hits':sum(int(r['status']=='VALIDATED_V028_CACHE_REUSE') for r in attempt_receipts),
                   'total_scored_iterations':sum(r['iterations_requested'] for r in scouting+confirms)})
    return report

def archive(folder):
    path=folder/'FOUR_STAT_FLASK_DPS_RESULTS_v029.zip'
    current=[p for p in sorted(folder.rglob('*')) if p.is_file() and p!=path]
    save(folder/'FILE_INDEX_v029.json',{'schema':'v029-evidence-index','entries':[
        {'path':p.relative_to(folder).as_posix(),'sha256':sha_file(p),'size':p.stat().st_size} for p in current]})
    current=[p for p in sorted(folder.rglob('*')) if p.is_file() and p!=path]
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in current:z.write(p,p.relative_to(folder).as_posix())
    with zipfile.ZipFile(path) as z:need(z.testzip() is None,'OUTPUT_ZIP_CRC_INVALID')
    return path

def main(argv=None):
    ap=argparse.ArgumentParser(description='v029 bounded native full-four-stat DPS with dynamic flasks')
    ap.add_argument('--mode',choices=('plan','local-probe'),default='plan')
    ap.add_argument('--gem-choice',choices=tuple(GEM_CHOICES),default='primary23_four_colors')
    ap.add_argument('--flask-policy',choices=('auto',*ALIAS.keys()),default='auto')
    ap.add_argument('--reuse-v028',action=argparse.BooleanOptionalAction,default=True)
    ap.add_argument('--simc-executable',default=None)
    ap.add_argument('--output-root',default=str(HERE/'V029_OUTPUTS'))
    ap.add_argument('--scout-iterations',type=int,default=120)
    ap.add_argument('--confirm-iterations',type=int,default=320)
    args=ap.parse_args(argv)
    try:
        cfg=settings(args.scout_iterations,args.confirm_iterations,args.flask_policy)
        need(args.mode=='plan' or args.simc_executable,'SIMC_EXE_REQUIRED_FOR_LIVE')
        reference=old.load_pinned(args.gem_choice)
        cache=Cache(reference,args.gem_choice,args.reuse_v028)
        base=tuple(reference['raw_base'][k] for k in STATS)
        candidates=seed_candidates(base)
        root=Path(args.output_root).resolve();root.mkdir(parents=True,exist_ok=True)
        folder=root/('RUN_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ_')+uuid.uuid4().hex[:8])
        folder.mkdir(exist_ok=False)
        plan={'schema':'SIMCFourStatFlaskPlan-v029','status':'OFFLINE_PLAN_PASS',
              'v027_reference_sha256':old.EVIDENCE_SHA,'v028_cache_provenance':LEGACY_SHA,
              'sample':'Arcane 334, native SimC gear 2847, gem 138, flask 165, fixed oil 32',
              'config':cfg,'first_five_seed_vectors':[dict(zip(STATS,v)) for v in candidates],
              'model_total':TOTAL,'fixed_oil':OIL,'locked_special_gear':dict.fromkeys(STATS,0),
              'other_scenarios_in_scope':False,'v015_dps_caches_not_cross_reused':True,
              'effect_semantics_calculated_by_simc':True}
        save(folder/'PLAN_v029.json',plan)
        for i,vec in enumerate(candidates):
            preview,info=make_profile(reference['source_simc'],folder/f'PREVIEW_{i+1:02d}.json',vec,cfg['iterations_scout'],cfg['flask_policy'])
            (folder/f'PREVIEW_{i+1:02d}.simc').write_text(preview,encoding='utf-8')
        if args.mode=='plan':
            receipt={'schema':'SIMCFourStatFlaskReceipt-v029','status':'OFFLINE_PLAN_PASS',
                     'settings':cfg,'native_simc_executed':False,
                     'flask_tokens':list(FLASKS.values()),'planned_scouts':len(candidates),
                     'planned_confirmations':CONFIRMS,'cache_enabled':cache.enabled}
        else:
            receipt=run(Path(args.simc_executable).resolve(),reference,cfg,folder,cache)
        save(folder/'FOUR_STAT_FLASK_DPS_RECEIPT_v029.json',receipt)
        notes=['SIMC SECONDARY OPTIMIZER v029 — 네 스탯 탐색·영약 선택 결과',
               '상태: '+receipt['status'],
               '대표 사례: 비전 마법사 334 / CHMV 3182 / 기름 고정 치명타16·가속16',
               '영약 정책: '+cfg['flask_policy']+' (기본 auto: 후보별 적절한 실제 영약)',
               '전체 탐색 아님: 6 scout + 2 confirmation만 확인',
               '일반 SimC 제품 시험; Work OS M0 실행 또는 상태 승격 아님','']
        for label,key in [('초기 탐색','scouts'),('독립 재확인','confirmations')]:
            if receipt.get(key):
                notes.append(label+':')
                for item in receipt[key]:
                    notes.append('  '+str(item['candidate'])+'  '+str(item['flask_token'])+' '+
                                 f"{item['dps_mean']:.1f} ±{item['ci95_half_width']:.1f} DPS (95% CI halfwidth)"+
                                 (' [v028 exact cache]' if item['status']=='VALIDATED_V028_CACHE_REUSE' else ''))
        if receipt.get('fresh_pair_judgment'):
            notes.append('상위2 비교: '+str(receipt['fresh_pair_judgment']))
        if receipt.get('error'):notes.append('오류: '+receipt['error'])
        (folder/'RESULT_SUMMARY_KO_v029.txt').write_text('\n'.join(notes)+'\n',encoding='utf-8')
        result=archive(folder)
        print('[STATUS]',receipt['status'],flush=True)
        print('[RESULT_ZIP]',result,flush=True)
        print('[RESULT_FOLDER]',folder,flush=True)
        if os.name=='nt':
            try:os.startfile(str(folder))
            except (OSError,AttributeError):pass
        return 0 if receipt['status'] in ('OFFLINE_PLAN_PASS','PASS_BOUNDED_FOUR_STAT_NATIVE_DPS') else 2
    except Exception as exc:
        print('[BLOCKED]',type(exc).__name__,str(exc),file=sys.stderr)
        return 2

if __name__=='__main__':raise SystemExit(main())
