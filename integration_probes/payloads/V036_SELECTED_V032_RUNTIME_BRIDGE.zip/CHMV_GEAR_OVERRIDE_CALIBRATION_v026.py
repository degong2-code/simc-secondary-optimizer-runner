#!/usr/bin/env python3
"""v026: evidence-bound gear_* compensation, one bounded user-PC SimC probe.

v025 proved: with identical gear overrides, a disabled-consumable run applied
(892,820,822,313), while a flask+oil run applied (892,985,822,313).
For this SPECIFIC pinned profile/binary, +165 haste was outside gear override;
oil's rated +16/+16 were not additionally present. Fixed oil remains in
the TARGET and therefore must be represented in the gear override values.

This is neither general calibration for arbitrary temporary enchants nor proof
that socketed gems, tier 4pc, crafted embellishments, or trinket effects survive.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid
import zipfile

import CHMV_FIXED_FLOOR_INJECTION_v025 as previous
import SIMC_STAT_ATTRIBUTION_v021 as stat

ROOT=Path(__file__).resolve().parent
EVIDENCE=ROOT/'EVIDENCE_V026_INPUTS'/'CHMV_INJECTION_RESULTS_v025_USER_PC.zip'
STATS=previous.STATS
NEUTRAL_GEAR=dict(previous.PROBE_GEAR)
FLASK_NATIVE={k:165 if k=='haste_rating' else 0 for k in STATS}
OIL_FIXED=dict(previous.budget.OIL)
TARGET={k:NEUTRAL_GEAR[k]+FLASK_NATIVE[k]+OIL_FIXED[k] for k in STATS}
EXPECTED_OVERRIDES=previous.gear_override_for_final(TARGET,FLASK_NATIVE)
EXPECTED_OBSERVED_OLD={k:NEUTRAL_GEAR[k]+FLASK_NATIVE[k] for k in STATS}


def check(condition,msg):
    if not condition: raise ValueError(msg)


def sha256(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def check_fixture(path=EVIDENCE):
    """Reject unrelated or corrupted receipts; derive what old pair DID show."""
    with zipfile.ZipFile(path) as z:
        check(z.testzip() is None,'V025_EVIDENCE_ZIP_INTEGRITY_FAIL')
        receipt=json.loads(z.read('CHMV_INJECTION_RECEIPT_v025.json'))
        neutral=json.loads(z.read('neutral.json'))
        combined=json.loads(z.read('flask_oil.json'))
        old_combined_profile=z.read('flask_oil.simc').decode('utf-8')
    check(receipt['schema']=='SIMCSecondaryCHMVInjectionReceipt-v025','V025_SCHEMA_CHANGED')
    check(receipt['status']=='GEAR_OVERRIDE_NATIVE_PROBE_FAIL_REVIEW','V025_STATUS_UNEXPECTED')
    tests=receipt['user_pc_native_probe']
    check(tests['neutral']['exact_chmv'] is True,'V025_NEUTRAL_NOT_PASS')
    check(tests['flask_oil']['exact_chmv'] is False,'V025_COMBINED_SHOULD_HAVE_FAILED')
    for name,doc,expected in [('neutral',neutral,NEUTRAL_GEAR),('flask_oil',combined,EXPECTED_OBSERVED_OLD)]:
        snap=stat.snapshot(doc)
        check(snap['buffed_rating']==expected,'V025_OBSERVED_MISMATCH:'+name)
        check(snap['simc_git_revision']=='7bc1071','SIMC_REVISION_DIFFERENT')
        check(snap['simc_build']=='12.1.5.70448','SIMC_BUILD_DIFFERENT')
        check(tests[name]['gear_overrides']=={previous.OVERRIDE_OPTIONS[k]:NEUTRAL_GEAR[k] for k in STATS},'V025_INPUT_OVERRIDE_DIFFERENT:'+name)
        check(tests[name]['observed']['observed_final']==expected,'V025_RECEIPT_JSON2_MISMATCH:'+name)
    check('temporary_enchant=main_hand:thalassian_phoenix_oil_2' in old_combined_profile,'V025_OIL_NOT_CONFIGURED')
    check('flask=flask_of_the_blood_knights_2' in old_combined_profile,'V025_FLASK_NOT_CONFIGURED')
    check(sum(TARGET.values())==sum(NEUTRAL_GEAR.values())+165+32,'FINAL_TARGET_TOTAL_MISMATCH')
    return {'source':'V025_USER_PC_TWO_CASE_JSON2','evidence_sha256':sha256(path),
            'observed_native_added_between_pair':FLASK_NATIVE,
            'oil_fixed_inside_target':OIL_FIXED,
            'v025_neutral_observed':NEUTRAL_GEAR,
            'v025_flask_oil_observed':EXPECTED_OBSERVED_OLD,
            'corrected_target_final':TARGET,
            'corrected_gear_override':EXPECTED_OVERRIDES,
            'isolated_individual_effects':'V021 flask-only and V022 oil-only independently observed; combined gear override is calibrated only for this pinned profile.',
            'calibration_scope':'SINGLE_SIMC_BUILD_SINGLE_MAGE_334_PROFILE_FLASK_OIL',
            'real_corrected_simc_probed':False}


def make_profile(original,out_json):
    """Same 334 mage/equipment/consumables as v025 combined; only gear overrides changed."""
    for line in original.splitlines():
        check(not re.match(r'\s*gear_(?:crit|haste|mastery|versatility)_rating\s*=',line),
              'BASELINE_HAS_GEAR_OVERRIDE')
    profile=stat.make_profile(original,Path(out_json),'flask_only')
    check(profile.count('temporary_enchant=disabled')==1,'OIL_SWITCH_AMBIGUOUS')
    profile=profile.replace('temporary_enchant=disabled','temporary_enchant=main_hand:thalassian_phoenix_oil_2')
    check(profile.count('flask=flask_of_the_blood_knights_2')==1,'FLASK_SWITCH_UNEXPECTED')
    check('food=disabled' in profile and 'augmentation=disabled' in profile,'OTHER_CONSUMABLES_NOT_DISABLED')
    check('item_db_source=local' in profile,'NATIVE_ITEM_DB_REQUIRED')
    check('iterations=1' in profile and 'max_time=5' in profile,'BOUND_PROBE_REQUIRED')
    anchor='json2='+str(Path(out_json).resolve())
    check(profile.count(anchor)==1,'JSON2_PATH_UNEXPECTED')
    inject='\n'.join(f'{k}={v}' for k,v in EXPECTED_OVERRIDES.items())
    profile=profile.replace(anchor,inject+'\n'+anchor)
    check(all(profile.count(key+'=')==1 for key in EXPECTED_OVERRIDES),'DUPLICATE_GEAR_OVERRIDE')
    return profile


def judge(doc,reference_gear):
    return previous.judge_json2(doc,TARGET,reference_gear)


def run_native(executable,baseline_profile,reference_gear,out):
    exe=Path(executable).resolve()
    check(exe.is_file(),'SIMC_BINARY_MISSING')
    check(sha256(exe)==previous.PINNED_SIMC_BINARY_SHA,'SIMC_BINARY_SHA_CHANGED')
    json_file=out/'corrected_flask_oil.json'
    simc_file=out/'corrected_flask_oil.simc'
    simc_file.write_text(make_profile(baseline_profile,json_file),encoding='utf-8')
    record={'exit_code':None,'json2_created':False,'all_stats_exact':False,
            'expected_final':TARGET,'gear_overrides':EXPECTED_OVERRIDES,'reason':None}
    try:
        call=subprocess.run([str(exe),str(simc_file)],capture_output=True,text=True,encoding='utf-8',errors='replace',timeout=90)
        record['exit_code']=call.returncode
        stdout=call.stdout;stderr=call.stderr
    except subprocess.TimeoutExpired as exc:
        record['reason']='TIMEOUT'
        stdout=str(exc.stdout or '');stderr=str(exc.stderr or '')+'\nTIMEOUT'
    (out/'corrected_flask_oil_stdout.txt').write_text(stdout,encoding='utf-8')
    (out/'corrected_flask_oil_stderr.txt').write_text(stderr,encoding='utf-8')
    record['json2_created']=json_file.is_file()
    if record['exit_code']==0 and record['json2_created']:
        try:
            observed=judge(json.loads(json_file.read_text(encoding='utf-8-sig')),reference_gear)
            record['observed']=observed
            record['all_stats_exact']=observed['all_stats_exact']
            check(observed['flask']=='flask_of_the_blood_knights_2','FLASK_REMOVED')
            check('thalassian_phoenix_oil' in str(observed['temporary_enchant']),'OIL_REMOVED')
            if not record['all_stats_exact']:record['reason']='FINAL_CHMV_MISMATCH'
        except (ValueError,KeyError,TypeError,IndexError) as err:
            record['reason']=type(err).__name__+':'+str(err)
    elif record['reason'] is None:record['reason']='SIMC_EXIT_OR_JSON2_MISSING'
    return record


def main(argv=None):
    ap=argparse.ArgumentParser(description='v026 gear* additive calibration / single bounded real test')
    ap.add_argument('--mode',choices=('inspect','local-probe'),default='inspect')
    ap.add_argument('--simc-executable')
    ap.add_argument('--output-root',default=str(ROOT/'V026_OUTPUTS'))
    args=ap.parse_args(argv)
    try:
        fixture=check_fixture()
        baseline,_,profile=stat.load_baseline()
        snapshot=stat.snapshot(baseline)
        check(snapshot['gear_secondary']=={'crit_rating':792,'haste_rating':920,'mastery_rating':822,'versatility_rating':313},'BASELINE_GEAR_CHANGED')
        dest=Path(args.output_root).resolve()/('RUN_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ_')+uuid.uuid4().hex[:8])
        dest.mkdir(parents=True,exist_ok=False)
        test=None
        if args.mode=='local-probe':
            check(args.simc_executable is not None,'SIMC_EXECUTABLE_REQUIRED')
            test=run_native(args.simc_executable,profile,snapshot['gear_secondary'],dest)
        receipt={'schema':'SIMCSecondaryCHMVGearOverrideCalibration-v026',
                 'status': 'OFFLINE_CALIBRATION_ONLY' if test is None else
                           ('CORRECTED_SINGLE_PROBE_PASS' if test['all_stats_exact'] else 'CORRECTED_SINGLE_PROBE_FAIL_REVIEW'),
                 'v025_finding':'FLASK_ONLY_ADDEND_OBSERVED_UNDER_GEAR_OVERLAY; OIL_RATING_NOT_ADDITIVELY_OBSERVED',
                 'calibration':fixture,'simc_native_probe':test,
                 'simc_executed':test is not None,
                 'full_optimizer_ready':False,'actual_gems_verified':False,
                 'special_item_fixed_and_proc_preservation_verified':False,
                 'trinket_enchant_static_semantics_verified':False,'four_piece_verified':False,
                 'warnings':[
                     'Treat gear overrides as encompassing static weapon oil rating for this verified combination; retain oil item configuration for non-rating semantics.',
                     'Do not subtract oil rating as a separate native additive from an overridden final target.',
                     'This single probe does not validate arbitrary items/enchants/gems/consumables/classes or zero-rating gear override.',
                     'The 165 flask remains physically present and outside overridden gear rating for this profile; general abstract flexible flask requires future calibration.'
                 ]}
        (dest/'GEAR_OVERRIDE_CALIBRATION_RECEIPT_v026.json').write_text(json.dumps(receipt,ensure_ascii=False,sort_keys=True,indent=2)+'\n',encoding='utf-8')
        outfile=dest/'GEAR_OVERRIDE_CALIBRATION_RESULTS_v026.zip'
        with zipfile.ZipFile(outfile,'w',zipfile.ZIP_DEFLATED) as z:
            for p in sorted(dest.iterdir()):
                if p.is_file() and p!=outfile:z.write(p,p.name)
        with zipfile.ZipFile(outfile) as z:check(z.testzip() is None,'RESULT_ZIP_CORRUPTED')
        print('[RESULT]',receipt['status'])
        print('[TARGET_FINAL]',TARGET)
        print('[CORRECTED_GEAR_OVERRIDE]',EXPECTED_OVERRIDES)
        print('[RESULT_ZIP]',outfile)
        print('[OUTPUT_FOLDER]',dest)
        try:
            if os.name=='nt':os.startfile(str(dest))
        except (OSError,AttributeError):pass
        return 0 if test is None or test['all_stats_exact'] else 2
    except (OSError,ValueError,KeyError,TypeError,zipfile.BadZipFile) as exc:
        print('[FAIL]',type(exc).__name__,str(exc));return 2

if __name__=='__main__':sys.exit(main())
