#!/usr/bin/env python3
"""v014 bounded CHMV pilot: real SimC runs on 4 controlled local neighbours.

Scope: canned Arcane example profile only.  This is a local exploratory search,
not a proof of the optimal stat split or of max-quality gems/crafted items.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import math
import os
import re
import statistics
import subprocess
import sys
import uuid
import zipfile
from pathlib import Path

HERE=Path(__file__).resolve().parent
SOURCE=HERE/'EVIDENCE'/'M0_T5_INDEPENDENT_RESULTS_v013.zip'
SOURCE_SHA='17ab1056619084bb63ebbe4bba8842c8f4d4edb9241a688454b6f4d2310b7b74'
SOURCE_C_INPUT_SHA='01c3aa7be6dcf163d845f83a6bc6fc471ac6fd269a5acf1e75986aafc14a9893'
BINARY_SHA='b0ea12ee3ac233a4a590609e2a5bd4c4db45c5f8ae6f8994b1b8d0de4d5acff4'
STATS=('crit','haste','mastery','versatility')
FLASK='flask_of_the_blood_knights_2'
FLASK_OFFSET=(0,165,0,0)
OPTIONS={'iterations':1000,'threads':1,'desired_targets':1,'fixed_time':1,'max_time':60,'vary_combat_length':0}
BUDGET=3000
# Historical independent T5 observations form the only measured anchors.
ANCHORS={'T5_PROFILESET_A':(1000,800,1100,100),'T5_PROFILESET_B':(800,1000,1000,200),'T5_PROFILESET_C':(600,1200,900,300)}
STEP_RATING=200
# Deterministic bounded exploratory directions, not fitted to noisy DPS ordering.
DIRECTIONS=(
 ('E01_HASTE_TO_MASTERY','haste','mastery'),
 ('E02_MASTERY_TO_CRIT','mastery','crit'),
 ('E03_HASTE_TO_VERS','haste','versatility'),
 ('E04_CRIT_TO_HASTE','crit','haste'),
)

def plan_candidates(anchor, step, directions):
 assert len(anchor)==4 and all(type(n)==int and n>=0 for n in anchor)
 assert sum(anchor)==BUDGET and type(step)==int and 0<step<=BUDGET
 result={}
 for name,source,destination in directions:
  assert name not in result and source in STATS and destination in STATS and source!=destination
  v=list(anchor);i=STATS.index(source);j=STATS.index(destination)
  assert v[i]>=step
  v[i]-=step;v[j]+=step
  assert min(v)>=0 and sum(v)==BUDGET
  result[name]=tuple(v)
 assert len(set(result.values()))==len(result)
 return result

EXPLORATION=plan_candidates(ANCHORS['T5_PROFILESET_C'],STEP_RATING,DIRECTIONS)

MAX_WALL_SECONDS=1200
MAX_JSON_BYTES=50_000_000
DEFAULT_SIMC=r'C:\Users\yesfprop\Desktop\법인, 기타\python\03_TOOLS\SimulationCraft\simc-1210.01.7bc1071-win64\simc.exe'


def need(condition, reason):
 if not condition: raise ValueError(reason)


def sha_bytes(b): return hashlib.sha256(b).hexdigest()

def sha_file(p):
 h=hashlib.sha256()
 with Path(p).open('rb') as f:
  for chunk in iter(lambda:f.read(1<<20),b''):h.update(chunk)
 return h.hexdigest()


def pairs_unique(pairs):
 d={}
 for k,v in pairs:
  need(k not in d,'DUPLICATE_KEY:'+str(k));d[k]=v
 return d

def no_constant(tok):raise ValueError('NONFINITE_TOKEN:'+str(tok))

def read_json(raw):
 need(len(raw)<MAX_JSON_BYTES,'OVERSIZED_JSON')
 d=json.loads(raw.decode('utf-8-sig'),object_pairs_hook=pairs_unique,parse_constant=no_constant)
 need(type(d) is dict,'JSON_ROOT_NOT_OBJECT')
 return d

def save_json(path, obj):
 path=Path(path)
 need(not path.exists(),'REFUSE_OVERWRITE:'+str(path))
 path.write_text(json.dumps(obj,ensure_ascii=False,indent=2,allow_nan=False,sort_keys=True)+'\n',encoding='utf-8')

def archive_bytes(z,canonical):
 key=canonical.replace('\\','/')
 matches=[n for n in z.namelist() if n.replace('\\','/')==key]
 need(len(matches)==1,'MISSING_OR_COLLIDING_ZIP_ENTRY:'+key)
 return z.read(matches[0])

def finite_num(x,label):
 need(type(x) in (int,float) and math.isfinite(x),'NONFINITE_OR_WRONG_TYPE:'+label)
 return float(x)


def evidence(path=SOURCE):
 need(Path(path).is_file(),'MISSING_EMBEDDED_REAL_EVIDENCE')
 need(sha_file(path)==SOURCE_SHA,'REAL_EVIDENCE_ARCHIVE_SHA_CHANGED')
 with zipfile.ZipFile(path) as z:
  need(z.testzip() is None,'EVIDENCE_CRC_FAILURE')
  names=[s.replace('\\','/') for s in z.namelist()]
  need(len(names)==len(set(names)),'EVIDENCE_CANONICAL_DUPLICATE_NAME')
  src_input=archive_bytes(z,'T5_PROFILESET_C/input.simc')
  need(sha_bytes(src_input)==SOURCE_C_INPUT_SHA,'SOURCE_C_SHA_CHANGED')
  source_cases={}
  for case,vec in ANCHORS.items():
   label=case[-1]
   raw=archive_bytes(z,f'{case}/result.json')
   doc=read_json(raw)
   source_cases[case]=parse_result(doc,vec,case,source_case=True)
   inp=archive_bytes(z,f'{case}/input.simc')
   need(('flask='+FLASK).encode() in inp,'SOURCE_FLASK_CHANGED')
  meta=read_json(archive_bytes(z,'t5_independent_receipt.json'))
  need(meta['status']=='PASS_THREE_INDEPENDENT_SIMC_RUNS','SOURCE_RECEIPT_NOT_PASS')
  need(meta['binary_sha256']==BINARY_SHA,'SOURCE_BINARY_IDENTITY_CHANGED')
  need(meta['actual_simc_invocation_count']==3,'SOURCE_ACTUAL_RUN_COUNT_NOT_3')
  return src_input,source_cases


def common_prefix(source):
 need(sha_bytes(source)==SOURCE_C_INPUT_SHA,'INPUT_C_SOURCE_NOT_PINNED')
 marker=b'# M0_CASE_ID=V013_T5_PROFILESET_C\r\n'
 need(source.count(marker)==1,'CASE_MARKER_NOT_EXACT')
 prefix,tail=source.split(marker)
 need(prefix.endswith(b'\r\n\r\n'),'PREFIX_CRLF_MISMATCH')
 expected=[f'gear_{k}_rating={v}' for k,v in zip(STATS,ANCHORS['T5_PROFILESET_C'])]
 expected.extend(f'{k}={v}' for k,v in OPTIONS.items())
 lines=tail.decode('utf-8').split('\r\n')
 need(lines[-1]=='' and lines[:len(expected)]==expected and len(lines)==len(expected)+2 and lines[len(expected)].startswith('json2='),'SOURCE_C_TRAILER_MISMATCH')
 # Exact fixed consumables; no claim that every gem/crafted gear bonus is highest quality.
 need(b'flask=flask_of_the_blood_knights_2\r\n' in prefix,'FLASK_NOT_RANK2')
 need(b'potion=lights_potential_2\r\n' in prefix,'POTION_NOT_RANK2')
 need(b'temporary_enchant=main_hand:thalassian_phoenix_oil_2\r\n' in prefix,'WEAPON_OIL_NOT_RANK2')
 need(b'profileset.' not in prefix,'PROFILESET_IN_COMMON_PREFIX')
 return prefix


def make_input(source,case,output_json):
 need(case in EXPLORATION,'CASE_UNKNOWN')
 output_json=Path(output_json)
 need(output_json.is_absolute() and output_json.name=='result.json' and output_json.parent.name==case,'PATH_NOT_ISOLATED_ABSOLUTE')
 dest=str(output_json)
 need(not any(x in dest for x in ['\r','\n','"']),'PATH_UNSAFE')
 prefix=common_prefix(source)
 v=EXPLORATION[case]
 need(sum(v)==BUDGET and min(v)>=0,'STAT_BUDGET_INVALID')
 tail=[f'# M0_CASE_ID=V014_{case}']
 tail += [f'gear_{k}_rating={x}' for k,x in zip(STATS,v)]
 tail += [f'{k}={n}' for k,n in OPTIONS.items()]
 tail += ['json2='+dest]
 raw=prefix+('\r\n'.join(tail)+'\r\n').encode('utf-8')
 need(raw.startswith(prefix) and raw.count(b'json2=')==1,'GENERATED_INPUT_WRONG')
 need(len(raw)<100_000,'OVERSIZED_INPUT')
 return raw


def parse_result(doc,vector,case,source_case=False):
 need(doc.get('report_version')=='2.0.0','JSON2_VERSION_CHANGED:'+case)
 need(doc.get('version')=='1210-01' and doc.get('git_revision')=='7bc1071','SIMC_VERSION_CHANGED:'+case)
 sim=doc['sim'];opt=sim['options']
 for k,v in OPTIONS.items():
  observed=opt[k]
  if type(observed) is bool:observed=int(observed)
  need(type(observed) in (int,float) and observed==v,'SIMC_OPTIONS_CHANGED:'+case+':'+k)
 need(opt['dbc']['Live']['build_level']==70448,'GAME_DATA_BUILD_CHANGED:'+case)
 need(len(sim['players'])==1,'PLAYER_COUNT_CHANGED:'+case)
 need(not sim.get('profilesets',{}).get('results',[]),'UNEXPECTED_PROFILESETS:'+case)
 actor=sim['players'][0]
 need(actor['name']=='MID2_Mage_Arcane_Spellslinger','ACTOR_CHANGED:'+case)
 need(actor.get('flask') is not None,'MISSING_FLASK_IN_JSON2:'+case)
 ratings=actor['collected_data']['buffed_stats']['stats']
 observed=[]
 for k,raw in zip(STATS,vector):
  obs=finite_num(ratings[f'{k}_rating'],case+':'+k)
  need(abs(obs-(raw+FLASK_OFFSET[STATS.index(k)]))<1e-5,'ACTUAL_RATING_MISMATCH:'+case+':'+k)
  observed.append(obs)
 dps=actor['collected_data']['dps']
 mean=finite_num(dps['mean'],case+':dps')
 sem=finite_num(dps['mean_std_dev'],case+':sem')
 need(mean>0 and sem>0 and type(dps['count'])==int and dps['count']>=900,'DPS_NOT_USABLE:'+case)
 z=finite_num(opt['confidence_estimator'],'confidence_estimator')
 need(abs(z-1.9599639854)<0.0001,'CONFIDENCE_ESTIMATOR_CHANGED')
 return {
  'case_id':case,'raw_gear_rating':dict(zip(STATS,vector)),
  'observed_effective_rating':dict(zip(STATS,observed)),
  'observed_flask_offset':dict(zip(STATS,FLASK_OFFSET)),
  'flask':FLASK,'dps_mean':mean,'mean_standard_error':sem,'ci95_half_width':sem*z,
  'dps_sample_count':dps['count'],'simc_seed':opt.get('seed'),
  'origin':'INDEPENDENT_V013' if source_case else 'REAL_V014',
 }


def compare(old,new):
 total={**old,**new}
 # Familywise conservative pairwise test: Bonferroni across ALL pairs; exploratory post-selection.
 keys=list(total)
 m=len(keys);pairs=m*(m-1)//2
 z=statistics.NormalDist().inv_cdf(1-0.05/(2*pairs))
 lead=max(keys,key=lambda name:total[name]['dps_mean'])
 best=total[lead]
 all_diffs={}
 supported=True
 for c in keys:
  if c==lead:continue
  r=total[c]
  diff=best['dps_mean']-r['dps_mean']
  radius=z*math.hypot(best['mean_standard_error'],r['mean_standard_error'])
  all_diffs[c]={'difference_dps':diff,'conservative_half_width_dps':radius,'resolved_positive':diff>radius}
  supported = supported and diff>radius
 return {
  'scope':'ONLY_SEVEN_TESTED_VECTORS_NOT_GLOBAL_OPTIMUM',
  'nominal_leader':lead,
  'ranking_by_observed_mean':sorted(keys,key=lambda name:total[name]['dps_mean'],reverse=True),
  'familywise_alpha':0.05,'bonferroni_z':z,
  'leader_exceeds_all_other_tested_candidates':supported,
  'decision':'TESTED_SET_LEADER_STATISTICALLY_SUPPORTED_NOT_GLOBAL_OPTIMUM' if supported else 'NO_STATISTICALLY_RESOLVED_WINNER',
  'comparison':all_diffs,'statistical_assumptions':'Independent run means; Gaussian normal approximation; conservative multiple-comparison control; does not establish causal/statistical optimality beyond measured vectors.',
 }


def write_read_only_plan(target):
 source,old=evidence()
 target=Path(target)
 need(not target.exists(),'REFUSE_OVERWRITE_EXISTING_OUTPUT_DIR')
 target.mkdir(parents=True)
 try:
  plan={'schema':'CHMVPilotPlan-v014','status':'OFFLINE_ONLY', 'source_evidence_sha256':SOURCE_SHA,
        'binary_sha256_required':BINARY_SHA,'budget':BUDGET,'run_options':OPTIONS,
        'candidate_vectors':{c:dict(zip(STATS,v)) for c,v in EXPLORATION.items()},
        'historical_dps':{c:old[c]['dps_mean'] for c in old},
        'quality_policy':'FIXED_RANK2_FLASK_POTION_OIL_GEM_AND_CRAFTED_ITEM_QUALITY_NOT_VERIFIED',
        'actual_simc_invocations':0,'best_candidate':None,'global_optimum_claimed':False}
  save_json(target/'chmv_plan_v014.json',plan)
  return target/'chmv_plan_v014.json'
 except Exception:raise


def make_zip(run_dir):
 entries=[]
 for p in sorted(Path(run_dir).rglob('*')):
  if not p.is_file() or p.name in ('M0_CHMV_EXPLORATION_v014.zip','file_index.json'):continue
  rel=p.relative_to(run_dir).as_posix()
  entries.append({'path':rel,'size':p.stat().st_size,'sha256':sha_file(p)})
 save_json(Path(run_dir)/'file_index.json',{'schema':'CHMVv014EvidenceIndex','entries':entries})
 archive=Path(run_dir)/'M0_CHMV_EXPLORATION_v014.zip'
 need(not archive.exists(),'ZIP_WOULD_OVERWRITE')
 with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in sorted(Path(run_dir).rglob('*')):
   if p.is_file() and p!=archive:z.write(p,p.relative_to(run_dir).as_posix())
 with zipfile.ZipFile(archive) as z:
  need(z.testzip() is None,'OUT_ARCHIVE_BAD_CRC')
 return archive


def run(binary,results_root,source_path=SOURCE):
 source,old=evidence(source_path)
 common_prefix(source)
 binary=Path(binary).resolve()
 need(binary.is_file(),'SIMC_EXECUTABLE_NOT_FOUND')
 need(sha_file(binary)==BINARY_SHA,'SIMC_EXECUTABLE_SHA_MISMATCH')
 root=Path(results_root).resolve()
 root.mkdir(parents=True,exist_ok=True)
 tag=dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%SZ')+'_'+uuid.uuid4().hex[:8]
 path=root/('CHMV_REAL_'+tag)
 path.mkdir(exist_ok=False)
 results={};runs=[]
 status='DENIED_OR_PARTIAL'; err=None
 try:
  for case,vector in EXPLORATION.items():
   need(sha_file(binary)==BINARY_SHA,'SIMC_EXECUTABLE_CHANGED_BEFORE_CASE')
   folder=path/case;folder.mkdir()
   input_path=folder/'input.simc';json_path=folder/'result.json'
   input_data=make_input(source,case,json_path)
   with input_path.open('xb') as f:f.write(input_data)
   item={'case_id':case,'input_sha256':sha_file(input_path),'vector':dict(zip(STATS,vector))}
   runs.append(item)
   with (folder/'simc_stdout.txt').open('xb') as stdout, (folder/'simc_stderr.txt').open('xb') as stderr:
    try:
     proc=subprocess.run([str(binary),str(input_path)],cwd=str(binary.parent),stdout=stdout,stderr=stderr,stdin=subprocess.DEVNULL,timeout=MAX_WALL_SECONDS,check=False)
     item['exit_code']=proc.returncode
    except subprocess.TimeoutExpired:
     raise ValueError('SIMC_WALL_TIMEOUT:'+case)
   need(item['exit_code']==0,'SIMC_EXIT_NONZERO:'+case)
   need(json_path.is_file() and 0<json_path.stat().st_size<MAX_JSON_BYTES,'SIMC_JSON2_MISSING_OR_INVALID_SIZE:'+case)
   need(sha_file(binary)==BINARY_SHA,'SIMC_EXECUTABLE_CHANGED_AFTER_CASE')
   # Validate identity/statistics and save raw reports without replacing existing files.
   doc=read_json(json_path.read_bytes())
   report=parse_result(doc,vector,case)
   report['input_sha256']=item['input_sha256'];report['result_sha256']=sha_file(json_path)
   results[case]=report
   item['result_sha256']=report['result_sha256']
   print(f'[PASS] {case}: {report["dps_mean"]:.1f} ±{report["ci95_half_width"]:.1f} DPS; gear={vector}',flush=True)
  status='PASS_FOUR_EXPLORATORY_SIMC_RUNS'
 except Exception as exc:
  err=f'{type(exc).__name__}: {exc}'
  print('[DENIED_OR_PARTIAL]',err,flush=True)
 finally:
  summary={'schema':'CHMVPilotExploration-v014','status':status,'source_sha256':SOURCE_SHA,
     'binary_sha256':BINARY_SHA,'quality_policy':'RANK2_FLASK_POTION_OIL_FIXED_GEMS_CRAFTED_QUALITY_UNVERIFIED',
     'user_authorized_actual_simc_runs':True,'planned_new_cases':len(EXPLORATION),
     'actual_simc_invocation_records':runs,'completed_results':results,
     'historical_anchor_results':old,'error':err,'global_optimum_claimed':False,
     'notes':['Example profile only; not the user character.',
       'The gear stat budget 3000 is an artificial pilot constraint.',
       'Flask of the Blood Knights rank2 provides haste +165. Flask is fixed while optimizing gear rating.',
       'Other gems/crafted items not verified as maximum quality; kept unchanged.',
       'No M1 sweep or formal optimization winner.']}
  if status=='PASS_FOUR_EXPLORATORY_SIMC_RUNS':summary['comparison']=compare(old,results)
  save_json(path/'chmv_exploration_receipt_v014.json',summary)
  archive=make_zip(path)
  print('[RESULT_DIR]',path,flush=True)
  print('[RESULT_ZIP]',archive,flush=True)
  if os.name=='nt':
   try:os.startfile(str(path))
   except OSError:pass
 return 0 if status=='PASS_FOUR_EXPLORATORY_SIMC_RUNS' else 2


def main(argv=None):
 p=argparse.ArgumentParser(description='M0 v014 bounded four-candidate exploratory CHMV SimC optimizer')
 p.add_argument('--mode',choices=('plan','run'),required=True)
 p.add_argument('--simc',default=DEFAULT_SIMC)
 p.add_argument('--results-root',default=str(HERE/'CHMV_V014_RESULTS'))
 a=p.parse_args(argv)
 try:
  if a.mode=='plan':
   dest=Path(a.results_root)/('PLAN_'+uuid.uuid4().hex[:8]);dest.parent.mkdir(parents=True,exist_ok=True)
   f=write_read_only_plan(dest);print('[OFFLINE_PLAN]',f);return 0
  return run(a.simc,a.results_root)
 except Exception as ex:
  print('[DENIED]',type(ex).__name__,str(ex),file=sys.stderr)
  return 2

if __name__=='__main__':raise SystemExit(main())
