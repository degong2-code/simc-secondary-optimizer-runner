#!/usr/bin/env python3
"""v030: bounded native-SimC DPS pilot with user-selected 334 trinkets.

Trinket 1 = Gebbo's Bottomless Bag (270164), trinket 2 = Twisted Horror's
Tendril (281215). Their actual proc and on-use DPS semantics belong to SimC.
The new item identity invalidates every v028/v029 DPS cache entry.
"""
from __future__ import annotations
import argparse
import copy
import datetime as dt
import json
import math
import os
from pathlib import Path
import re
import statistics
import sys
import uuid
import zipfile

import CHMV_FOUR_STAT_FLASK_SEARCH_v029 as previous
import CHMV_ADAPTIVE_v015 as adaptive

HERE=Path(__file__).resolve().parent
STATS=previous.STATS
TOTAL=previous.TOTAL
BAG_ID=270164
TENDRIL_ID=281215
ILVL=334
OLD_LINE='trinket1=v020_trinket1_250215,id=250215,ilevel=334,source=local'
BAG_LINE=f'trinket1=v030_gebbos_bottomless_bag_{BAG_ID},id={BAG_ID},ilevel={ILVL},source=local'
TRINKET2_LINE=f'trinket2=v020_trinket2_{TENDRIL_ID},id={TENDRIL_ID},ilevel={ILVL},source=local'
RUNS=6
CONFIRMS=2

class NoDpsReuse:
    enabled=False
    source_identity='V028_AND_V029_DIFFERENT_TRINKETS_REJECTED'
    def get(self, *args): return None

def need(flag, why):
    if not flag: raise previous.Rejected(why)

def load_new_reference(gem_choice):
    """Use already-verified native gem/profile identity, then change ONLY trinket1.

    Replacing the old snapshot's identity is not proof that the new item works;
    the live JSON2 is required to match that expectation before accepting DPS.
    """
    origin=previous.old.load_pinned(gem_choice)
    source=origin['source_simc']
    need(source.count(OLD_LINE)==1, 'LEGACY_TRINKET1_LINE_MISSING_OR_DUPLICATE')
    need(source.count(TRINKET2_LINE)==1, 'TENDRIL_SOURCE_LINE_MISSING_OR_DUPLICATE')
    ref=copy.deepcopy(origin)
    new_source=source.replace(OLD_LINE,BAG_LINE)
    need('id=250215' not in new_source, 'OLD_TRINKET_LEAK')
    need(new_source.count('id=270164,ilevel=334,source=local')==1,'BAG_NOT_UNIQUE')
    ref['source_simc']=new_source
    identity=ref['reference']['item_identity']
    need('trinket1' in identity and identity['trinket1'][1]=='id=250215', 'OLD_ITEM_IDENTITY_UNEXPECTED')
    need(identity['trinket2'][1]=='id=281215','TENDRIL_IDENTITY_UNEXPECTED')
    identity['trinket1']=['v030_gebbos_bottomless_bag_270164','id=270164','ilevel=334']
    ref['trinket_identity']={'trinket1':{'name':"Gebbo's Bottomless Bag",'item_id':BAG_ID,'ilevel':ILVL},
                            'trinket2':{'name':"Twisted Horror's Tendril",'item_id':TENDRIL_ID,'ilevel':ILVL}}
    ref['pinned_previous_dps_evidence_reusable']=False
    need(ref['reference']['gear_total']==2847,'NATIVE_STATIC_GEAR_BUDGET_CHANGED')
    return ref

def vector(record):
    return tuple(int(record['candidate'][s]) for s in STATS)

def distance(a,b):
    return sum(abs(x-y) for x,y in zip(a,b))//2

def _linear_solve(matrix, rhs):
    n=len(rhs);aug=[list(row)+[rhs[i]] for i,row in enumerate(matrix)]
    for col in range(n):
        row=max(range(col,n),key=lambda i:abs(aug[i][col]))
        need(abs(aug[row][col])>1e-10,'ILL_CONDITIONED_EXPLORATION_DESIGN')
        aug[col],aug[row]=aug[row],aug[col]
        pivot=aug[col][col]
        for j in range(col,n+1):aug[col][j]/=pivot
        for i in range(n):
            if i==col:continue
            factor=aug[i][col]
            for j in range(col,n+1):aug[i][j]-=factor*aug[col][j]
    return [aug[i][-1] for i in range(n)]

def fit_exploratory_surface(records, baseline):
    """Ridge-regularized 3-DOF weighted local guide, NOT a DPS predictor claim.

    All four ratings sum to a constant, so fitting four independent slopes is
    singular. We represent CRIT/HASTE/MASTERY; VERS is the residual.
    """
    need(len(records)>=5 and len({vector(r) for r in records})>=5,'TOO_FEW_DIVERSE_SCOUTS')
    need(all(previous.valid(vector(r)) for r in records),'INVALID_SCOUT_VECTOR')
    sems=[max(1,float(r['mean_standard_error'])) for r in records]
    scale=statistics.median(sems)
    xx=[];yy=[];ww=[]
    for r,sem in zip(records,sems):
        v=vector(r)
        xx.append([1.0]+[(v[i]-baseline[i])/500.0 for i in range(3)])
        y=float(r['dps_mean']);need(math.isfinite(y) and y>0,'NONFINITE_DPS')
        yy.append(y)
        ww.append(max(0.25,min(4.,(scale/sem)**2)))
    ridge=0.6
    lhs=[[sum(w*x[i]*x[j] for w,x in zip(ww,xx))+(ridge if i==j and i!=0 else 0.0)
          for j in range(4)] for i in range(4)]
    rhs=[sum(w*x[i]*y for w,x,y in zip(ww,xx,yy)) for i in range(4)]
    beta=_linear_solve(lhs,rhs)
    return {'intercept':beta[0], 'slopes_per_500_rating':beta[1:],
            'baseline':list(baseline),'median_scout_sem':scale,
            'ridge':ridge,'training_scout_count':len(records),
            'not_validated_dps_prediction':True}

def _model_value(model,v):
    baseline=model['baseline']
    return model['intercept']+sum(model['slopes_per_500_rating'][i]*(v[i]-baseline[i])/500.0
                                  for i in range(3))

def choose_guided(records,baseline,step=240):
    model=fit_exploratory_surface(records,baseline)
    seen={vector(r) for r in records}
    ranked=sorted(records,key=lambda r:(-r['dps_mean'],vector(r)))
    candidates=[]
    # Search around multiple anchors; do not declare a winner from 120 iterations.
    for anchor_rank,record in enumerate(ranked[:3]):
        anchor=vector(record)
        for i in range(4):
            for j in range(4):
                if i==j:continue
                arr=list(anchor);arr[i]-=step;arr[j]+=step
                v=tuple(arr)
                if not previous.valid(v) or v in seen:continue
                novelty=min(distance(v,prev)/TOTAL for prev in seen)
                gain=_model_value(model,v)-_model_value(model,anchor)
                # Small exploration credit with uncertainty, not a fake
                # statement that predicted gain is statistically significant.
                score=gain + 0.15*model['median_scout_sem']*novelty - anchor_rank*0.08*model['median_scout_sem']
                candidates.append((score,gain,novelty,-anchor_rank,v,anchor))
    need(bool(candidates),'NO_NEW_GUIDED_CANDIDATE')
    best=max(candidates,key=lambda c:(c[0],c[2],c[1],tuple(-x for x in c[4])))
    vec,anchor=best[4],best[5]
    leaders=sorted(ranked,key=lambda r:-r['dps_mean'])
    gap=leaders[0]['dps_mean']-leaders[1]['dps_mean']
    sem=math.hypot(leaders[0]['mean_standard_error'],leaders[1]['mean_standard_error'])
    rationale={'method':'REGULARIZED_3_DOF_UNCERTAINTY_AWARE_SCOUT',
               'anchor':list(anchor),'candidate':list(vec),'move_step':step,
               'predicted_local_gain_guide_only':round(best[1],2),
               'nearest_scout_distance_rating':round(best[2]*TOTAL),
               'top_two_scout_difference_dps':round(gap,2),
               'top_two_difference_standard_error':round(sem,2),
               'top_two_significant_95pct':bool(gap>1.96*sem),
               'model':model,'no_global_optimum_claim':True}
    return vec,rationale

def confirmation_seeds(scouts,min_dist=250):
    need(len(scouts)>=2,'INSUFFICIENT_SCOUTS')
    ordered=sorted(scouts,key=lambda r:(-r['dps_mean'],vector(r)))
    best=ordered[0]
    first=vector(best)
    for alternative in ordered[1:]:
        d=distance(first,vector(alternative))
        # Statistically indistinguishable alternatives benefit from a
        # meaningfully different second confirmation rather than a clone.
        error=1.96*math.hypot(float(best['mean_standard_error']),
                               float(alternative['mean_standard_error']))
        if d>=min_dist and best['dps_mean']-alternative['dps_mean']<=error:
            return (best,alternative),{'method':'DIVERSE_UNRESOLVED_ALTERNATIVE',
                                      'distance_rating':d,'ci95_difference_bound':error}
    return (best,ordered[1]),{'method':'TOP_TWO_SCOUT_MEANS_NOT_STATISTICALLY_CERTIFIED',
                              'distance_rating':distance(first,vector(ordered[1]))}

def validated_live_case(binary,reference,folder,tag,vec,iters,cfg):
    # v029's strict native parser and invocation are reused, not copied.
    # No v028/v029 DPS records are accepted under the new trinket identity.
    return previous.run_case(binary,reference['source_simc'],folder,tag,vec,iters,
                             reference,cfg['flask_policy'],NoDpsReuse())

def settings(scout_iterations=120,confirm_iterations=320,policy='auto'):
    old=previous.settings(scout_iterations,confirm_iterations,policy)
    return {**old,'v030_new_trinket_id':BAG_ID,
            'twisted_horror_tendril_id':TENDRIL_ID,
            'both_trinkets_ilevel':ILVL,
            'old_v029_dps_cache_reuse':False,
            'new_simc_calls_max':RUNS+CONFIRMS,
            'trinket_proc_dps_semantics_owner':'NATIVE_SIMC'}

def run(binary,reference,cfg,folder):
    need(binary.is_file(),'SIMC_BINARY_NOT_FOUND')
    need(previous.sha_file(binary)==previous.old.native.BINARY_SHA,'SIMC_BINARY_IDENTITY_MISMATCH')
    base=tuple(reference['raw_base'][s] for s in STATS)
    seeds=previous.seed_candidates(base)
    scout=[];confirm=[];attempts=[]
    report={'schema':'SIMCSecondaryTrinketGuidedReceipt-v030','status':'PENDING',
            'settings':cfg,'trinkets':reference['trinket_identity'],
            'budget':{'gear':2847,'gems':138,'flask':165,'fixed_oil':previous.OIL,'total':TOTAL},
            'previous_v029_dps_cache_hits':0,'global_optimum_proven':False,
            'simc_effect_semantics_delegated':True}
    try:
        for i in range(RUNS):
            vec=seeds[i] if i<len(seeds) else choose_guided(scout,base)[0]
            if i==RUNS-1:report['guided_rationale']=choose_guided(scout,base)[1]
            tag=f'SCOUT_{i+1:02d}'
            attempts.append(tag)
            print('[SCOUT]',i+1,'/',RUNS,'CHMV',vec,flush=True)
            r=validated_live_case(binary,reference,folder/tag,tag,vec,cfg['iterations_scout'],cfg)
            scout.append(r)
            previous.save(folder/'PROGRESS_v030.json',{'completed':attempts,'pending':'SCOUT' if i<RUNS-1 else 'CONFIRM'})
        pair,decision=confirmation_seeds(scout)
        report['confirmation_strategy']=decision
        for i,src in enumerate(pair):
            vec=vector(src);tag=f'CONFIRM_{i+1:02d}'
            attempts.append(tag)
            print('[CONFIRM]',i+1,'/',CONFIRMS,'CHMV',vec,flush=True)
            confirm.append(validated_live_case(binary,reference,folder/tag,tag,vec,cfg['iterations_confirm'],cfg))
            previous.save(folder/'PROGRESS_v030.json',{'completed':attempts,'pending':'DONE' if i==1 else 'CONFIRM'})
        data={vector(r):r for r in confirm}
        report['judgment']=adaptive.judge([vector(r) for r in pair],data)
        report['status']='PASS_BOUNDED_USER_TRINKET_FOUR_STAT_DPS'
    except (Exception,KeyboardInterrupt) as e:
        report.update({'status':'PARTIAL_OR_BLOCKED','error':type(e).__name__+':'+str(e)})
    attempt_receipts=[]
    for tag in attempts:
        p=folder/tag/'case_attempt_v029.json'
        if p.is_file(): attempt_receipts.append(json.loads(p.read_text(encoding='utf-8')))
    report.update({'scouts':scout,'confirmations':confirm,'attempts':attempts,
                   'actual_new_simc_calls':sum(bool(r.get('new_simc_call')) for r in attempt_receipts),
                   'completed_scouts':len(scout),'completed_confirmations':len(confirm),
                   'total_iterations_requested':sum(r['iterations_requested'] for r in scout+confirm)})
    return report

def archive(folder):
    path=folder/'TRINKET_GUIDED_DPS_RESULTS_v030.zip'
    contents=[p for p in sorted(folder.rglob('*')) if p.is_file() and p!=path]
    previous.save(folder/'FILE_INDEX_v030.json',{'files':[
      {'path':p.relative_to(folder).as_posix(),'sha256':previous.sha_file(p),'size':p.stat().st_size}
      for p in contents]})
    with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(folder.rglob('*')):
            if p.is_file() and p!=path:z.write(p,p.relative_to(folder).as_posix())
    with zipfile.ZipFile(path) as z:need(z.testzip() is None,'ZIP_CRC_FAILURE')
    return path

def main(argv=None):
    p=argparse.ArgumentParser(description='SimC v030 user 334 trinkets + bounded adaptive DPS')
    p.add_argument('--mode',choices=['plan','local-probe'],default='plan')
    p.add_argument('--gem-choice',choices=tuple(previous.GEM_CHOICES),default='primary23_four_colors')
    p.add_argument('--flask-policy',choices=['auto',*previous.ALIAS],default='auto')
    p.add_argument('--simc-executable')
    p.add_argument('--output-root',default=str(HERE/'V030_OUTPUTS'))
    p.add_argument('--scout-iterations',type=int,default=120)
    p.add_argument('--confirm-iterations',type=int,default=320)
    args=p.parse_args(argv)
    try:
        cfg=settings(args.scout_iterations,args.confirm_iterations,args.flask_policy)
        ref=load_new_reference(args.gem_choice)
        base=tuple(ref['raw_base'][s] for s in STATS)
        seeds=previous.seed_candidates(base)
        root=Path(args.output_root).resolve();root.mkdir(exist_ok=True,parents=True)
        folder=root/('RUN_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ_')+uuid.uuid4().hex[:8])
        folder.mkdir(exist_ok=False)
        plan={'schema':'SIMCSecondaryTrinketGuidedPlan-v030','status':'OFFLINE_PLAN_READY',
              'native_live_executed':False,'gem_choice':args.gem_choice,
              'trinkets':ref['trinket_identity'],'total_chmv':TOTAL,
              'gear_secondary_sample_provenance':'V027_ARCANE334_EXCLUDING_TRINKETS',
              'new_trinket_not_yet_simc_verified':True,
              'v028_v029_dps_cache_reuse_allowed':False,'config':cfg,
              'first_five_scout_vectors':[dict(zip(STATS,v)) for v in seeds]}
        previous.save(folder/'PLAN_v030.json',plan)
        for i,vec in enumerate(seeds):
            text,info=previous.make_profile(ref['source_simc'],folder/f'PREVIEW_{i+1:02d}.json',
                                            vec,cfg['iterations_scout'],cfg['flask_policy'])
            need(text.count(BAG_LINE)==1,'BAG_REMOVED_FROM_PREVIEW')
            (folder/f'PREVIEW_{i+1:02d}.simc').write_text(text,encoding='utf-8')
        if args.mode=='plan':
            receipt={'schema':'SIMCSecondaryTrinketGuidedReceipt-v030',
                     'status':'OFFLINE_PLAN_PASS','actual_new_simc_calls':0,
                     'trinkets':ref['trinket_identity'],
                     'new_trinket_simc_live_verification_pending':True,
                     'old_dps_cache_hits':0}
        else:
            need(args.simc_executable is not None,'SIMC_EXECUTABLE_REQUIRED')
            receipt=run(Path(args.simc_executable).resolve(),ref,cfg,folder)
        previous.save(folder/'TRINKET_GUIDED_DPS_RECEIPT_v030.json',receipt)
        notes=['SIMC SECONDARY OPTIMIZER v030 — 334 장신구 변경/4스탯 DPS 시험',
               '장신구1: Gebbo\'s Bottomless Bag (270164, ilevel=334)',
               '장신구2: Twisted Horror\'s Tendril (281215, ilevel=334)',
               '상태: '+receipt['status'],
               '기존 장신구로 측정한 v028/v029 DPS 기록 재사용: 없음',
               'CHMV 총량 3182 / 300초 Patchwerk / 1타겟 / 레이드 버프 / 시작 블러드',
               '후속 후보는 신규 SimC DPS 탐색 데이터를 사용하며 전역 최적해 증명 아님','']
        for label,key in [('초기 탐색','scouts'),('재확인','confirmations')]:
            if receipt.get(key):
                notes.append(label)
                for r in receipt[key]:
                    notes.append('  '+str(r['candidate'])+' DPS '+format(r['dps_mean'],'.2f')+
                                 ' ±'+format(r['ci95_half_width'],'.1f')+' (95% CI)')
        if receipt.get('error'):notes.append('오류: '+receipt['error'])
        (folder/'RESULT_SUMMARY_KO_v030.txt').write_text('\n'.join(notes)+'\n',encoding='utf-8')
        result=archive(folder)
        print('[STATUS]',receipt['status'],flush=True)
        print('[RESULT_ZIP]',result,flush=True)
        print('[RESULT_FOLDER]',folder,flush=True)
        if os.name=='nt':
            try:os.startfile(str(folder))
            except (OSError,AttributeError):pass
        return 0 if receipt['status'] in ('OFFLINE_PLAN_PASS','PASS_BOUNDED_USER_TRINKET_FOUR_STAT_DPS') else 2
    except Exception as e:
        print('[BLOCKED]',type(e).__name__,str(e),file=sys.stderr)
        return 2

if __name__=='__main__':raise SystemExit(main())
