#!/usr/bin/env python3
"""v024: user-selected Midnight special gem with conditional color effects.

No assertion of actual installed socket positions, SimC gem activation, four-piece
activation, actual DPS benefit or discrete feasibility of optimized CHMV targets.
Existing scenario/CHMV engine files remain unchanged.
"""
from __future__ import annotations
import argparse
from collections import Counter
from dataclasses import dataclass
from datetime import datetime, timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import zipfile

import SCENARIO_CONTRACT_v016 as scenario
import SIMC_NATIVE_CHMV_AUTHORITY_v023 as native

ROOT=Path(__file__).resolve().parent
SAMPLE_CONFIG=ROOT/'GEM_SELECTION_v024.json'
COLORS=('GARNET','PERIDOT','AMETHYST','LAPIS')
SPECIALS={
    'PRIMARY_32':{'item_id':240983,'item_name':'Indecipherable Eversong Diamond','primary_stat_rating':32,'effect_per_color_bps':0},
    'PRIMARY_23_CRIT_DAMAGE_UP_TO_0_6':{'item_id':240967,'item_name':'Powerful Eversong Diamond','primary_stat_rating':23,'effect_per_color_bps':15},
}
# Only the five publicly identified highest-quality +16/+7 cuts used in the tests.
# This is not a complete gemstone catalog. Item IDs are item-level 295 versions.
CATALOG={
    240908:('GARNET','crit_rating','mastery_rating'),
    240892:('PERIDOT','haste_rating','mastery_rating'),
    240918:('LAPIS','versatility_rating','mastery_rating'),
    240900:('AMETHYST','mastery_rating','haste_rating'),
    240910:('GARNET','crit_rating','versatility_rating'),
}
STAT_KEYS=('crit_rating','haste_rating','mastery_rating','versatility_rating')


def need(cond,reason):
    if not cond:raise ValueError(reason)


def strict_config(cfg):
    need(type(cfg) is dict and set(cfg)=={'schema','regular_gem_item_ids','special_gem_choice'},'INVALID_SELECTION_KEYS')
    need(cfg['schema']=='MidnightGemSelection-v024','INVALID_SCHEMA')
    need(cfg['special_gem_choice'] in (None,*SPECIALS),'INVALID_SPECIAL_GEM_CHOICE')
    x=cfg['regular_gem_item_ids']
    need(x is None or type(x) is list and len(x)==6,'SIX_REGULAR_GEMS_OR_UNSELECTED_REQUIRED')
    if x is not None:
        for item_id in x:
            need(type(item_id) is int and item_id in CATALOG,'UNSUPPORTED_OR_NON_HIGHEST_QUALITY_GEM_ID')
    return cfg


def resolved_gems(item_ids):
    need(type(item_ids) is list and len(item_ids)==6,'EXACTLY_SIX_REGULAR_GEMS_REQUIRED')
    rows=[]
    ratings={k:0 for k in STAT_KEYS}
    for gid in item_ids:
        need(type(gid) is int and gid in CATALOG,'UNKNOWN_GEM_ID_NO_COLOR_ASSUMPTIONS')
        color,primary,secondary=CATALOG[gid]
        need(primary!=secondary,'NOT_TWO_DIFFERENT_SECONDARIES')
        ratings[primary]+=16;ratings[secondary]+=7
        rows.append({'item_id':gid,'color':color,'secondary_rating':{primary:16,secondary:7}})
    distinct=sorted({x['color'] for x in rows})
    need(sum(ratings.values())==138,'GEM_TOTAL_NOT_138')
    return {'gem_count':6,'per_gem_budget':23,'total_secondary_rating':138,
            'colors':distinct,'distinct_color_count':len(distinct),'by_stat':ratings,
            'gem_rows':rows,'color_count_observed_from_declared_gem_ids':True,
            'actual_simc_gem_equipping_verified':False}


def select(config):
    cfg=strict_config(config)
    ch=cfg['special_gem_choice']
    gems=resolved_gems(cfg['regular_gem_item_ids']) if cfg['regular_gem_item_ids'] is not None else None
    if ch is None:
        special={'selection_status':'USER_SELECTION_REQUIRED','choice':None,'item_id':None,
                 'primary_stat_rating':None,'crit_effectiveness_bonus_bps':None}
    else:
        spec=SPECIALS[ch]
        bonus=0 if ch=='PRIMARY_32' else (spec['effect_per_color_bps']*gems['distinct_color_count'] if gems is not None else None)
        special={'selection_status':'SELECTED_EFFECT_RESOLVED' if bonus is not None else 'SELECTED_COLOR_EFFECT_UNRESOLVED',
                 'choice':ch,'item_id':spec['item_id'],'item_name':spec['item_name'],
                 'primary_stat_rating':spec['primary_stat_rating'],
                 'crit_effectiveness_bonus_bps':bonus,
                 'crit_effectiveness_bonus_percent':None if bonus is None else bonus/100,
                 'max_possible_crit_effectiveness_percent':0.6 if ch!='PRIMARY_32' else 0.0}
    doc={'schema':'MidnightGemPolicyReport-v024','policy':'SIX_MAX_QUALITY_DUAL_SECONDARY_PLUS_ONE_SPECIAL',
         'general_gem_chmv_budget':138, 'general_gem_count':6,
         'highest_quality_secondary_per_gem':[16,7],
         'special_gem':special,'regular_gem_loadout':gems,
         'special_gem_affects_chmv_total':False,
         'special_gem_effect_requires_actual_gem_color_count':ch=='PRIMARY_23_CRIT_DAMAGE_UP_TO_0_6',
         'actual_simc_gem_effect_verified':False,'simulation_executed':False,
         'dps_measured':False,'four_piece_effect_verified':False,
         'warning':['Gem colors (Garnet/Peridot/Amethyst/Lapis) are not interchangeable with presence of CHMV stats.',
                    'Six-gem +138 is a continuous budget abstraction; an arbitrary optimized target may not be attainable by six physical +16/+7 gems.',
                    'The selected special gem contributes primary stat and possibly critical effectiveness, not secondary rating.',
                    'Do not award 0.6 percent unless four different colors are shown by an actual specified gem-ID set.',
                    'Specific gem IDs and installation/sockets require live SimC validation before optimizer readiness.']}
    return doc


def legacy_overlay(choice):
    """Read-only copy of v016 scenario selection; do not change legacy contract."""
    need(choice in SPECIALS,'INVALID_SPECIAL_GEM_CHOICE')
    config=json.loads((ROOT/'SCENARIO_CONTRACT_v016.json').read_text(encoding='utf-8'))
    config['budget']['special_gem']['choice']=choice
    scenario.validate_contract(config)
    return config


def native_334_example(config):
    receipt,oil,both=native.read_v022()
    authority=native.authority_record(receipt,oil,both)
    selected=select(config)
    gear=authority['native_gear_rating_total']
    need(gear==2847,'NATIVE_GEAR_SAMPLE_CHANGED')
    native_total=gear+165+32+selected['general_gem_chmv_budget']
    need(native_total==3182,'SECONDARY_BUDGET_CHANGED')
    return {'schema':'GemSelectedNativeExample-v024','sample':'334_ARCANE_TWO_HAND_NATIVE_7bc1071',
            'native_gear_secondary':gear,'regular_gem_budget_abstract':138,
            'flask_secondary':165,'weapon_oil_secondary':32,
            'provisional_final_chmv':native_total,'special_gem':selected['special_gem'],
            'primary_stat_delta_vs_other_special_gem':9 if config['special_gem_choice']=='PRIMARY_32' else -9 if config['special_gem_choice'] in SPECIALS else None,
            'actual_six_gems_applied':False,'simc_executed_this_step':False,
            'not_a_dps_comparison':True}


def digest(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def cli(argv=None):
    ap=argparse.ArgumentParser(description='v024 offline gem selection, no new SimC')
    ap.add_argument('--config',default=str(SAMPLE_CONFIG))
    ap.add_argument('--special-gem',choices=list(SPECIALS),default=None,help='Override config choice')
    ap.add_argument('--output-root',default=str(ROOT/'V024_OUTPUTS'))
    args=ap.parse_args(argv)
    cfg=json.loads(Path(args.config).read_text(encoding='utf-8'))
    if args.special_gem:cfg['special_gem_choice']=args.special_gem
    report=select(cfg)
    example=native_334_example(cfg)
    overlay=legacy_overlay(cfg['special_gem_choice']) if cfg['special_gem_choice'] is not None else None
    out=Path(args.output_root).resolve();out.mkdir(parents=True,exist_ok=True)
    outputs={'GEM_POLICY_REPORT_v024.json':report,'NATIVE_334_GEM_EXAMPLE_v024.json':example}
    if overlay is not None:outputs['SCENARIO_SPECIAL_GEM_SELECTED_v024.json']=overlay
    for name,data in outputs.items():
        (out/name).write_text(json.dumps(data,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
    result=out/'GEM_SELECTION_RESULTS_v024.zip'
    with zipfile.ZipFile(result,'w',zipfile.ZIP_DEFLATED) as z:
        for name in sorted(outputs):z.write(out/name,name)
    with zipfile.ZipFile(result) as z:need(z.testzip() is None,'ZIP_CRC_INVALID')
    print('[PASS] v024 GEM_SELECTION_OFFLINE')
    print('[SPECIAL]',report['special_gem']['choice'],report['special_gem']['item_id'])
    print('[COLOR_EFFECT_BPS]',report['special_gem']['crit_effectiveness_bonus_bps'])
    print('[CHMV_ABSTRACT]',example['provisional_final_chmv'],'NOT_SIMC_GEM_VERIFIED')
    print('[RESULT_ZIP]',result,'\n[OUTPUT_FOLDER]',out)
    try:
        if os.name=='nt':os.startfile(str(out))
    except (AttributeError,OSError):pass
    return 0

if __name__=='__main__':
    try:sys.exit(cli())
    except (KeyError,ValueError,OSError,zipfile.BadZipFile) as e:
        print('[FAIL]',type(e).__name__,str(e));sys.exit(2)
