#!/usr/bin/env python3
"""Strict, offline Scenario Contract v016. No SimulationCraft invocation.

Preserves the 3000/60s SimC v015 pilot unchanged. A future validated adapter
must map this contract to SimC. Never derives unverified itemlevel budgets.
"""
from __future__ import annotations
import argparse
import copy
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import sys
import uuid

ROOT = Path(__file__).resolve().parent
DEFAULT_CONFIG = ROOT / "SCENARIO_CONTRACT_v016.json"
STAT_KEYS = ("crit", "haste", "mastery", "versatility")
BASE_SLOTS = ("head", "neck", "shoulders", "back", "chest", "wrists", "hands", "waist", "legs", "feet", "finger1", "finger2", "main_hand")
OPTIONAL_SLOTS = ("off_hand",)
BUDGET_MODES = ("ITEMLEVEL_VERIFIED_TABLE", "MANUAL_TOTAL_INCLUSIVE", "MANUAL_GEAR_EXCLUSIVE")
WEAPON_STYLES = ("TWO_HAND", "DUAL_WIELD", "ONE_HAND_OFFHAND", "ONE_HAND_SHIELD")


class ContractError(ValueError):
    pass


def need(ok: bool, reason: str):
    if not ok:
        raise ContractError(reason)


def no_duplicates(pairs):
    obj = {}
    for k, v in pairs:
        need(k not in obj, "DUPLICATE_JSON_KEY:" + k)
        obj[k] = v
    return obj


def load_strict(path: Path):
    need(path.is_file(), "FILE_NOT_FOUND:" + str(path))
    return json.loads(path.read_text(encoding="utf-8-sig"), object_pairs_hook=no_duplicates,
                      parse_constant=lambda x: (_ for _ in ()).throw(ContractError("NONFINITE_JSON_NUMBER:" + x)))


def write_json(path: Path, doc):
    path.write_text(json.dumps(doc, ensure_ascii=False, sort_keys=True, indent=2, allow_nan=False) + "\n", encoding="utf-8")


def sha(path: Path):
    h = hashlib.sha256()
    with path.open("rb") as fh:
        for part in iter(lambda: fh.read(1024 * 1024), b""):
            h.update(part)
    return h.hexdigest()


def exact_keys(doc, expected, path):
    need(type(doc) is dict, "OBJECT_REQUIRED:" + path)
    need(set(doc) == set(expected), "SCHEMA_KEYS_MISMATCH:" + path)


def integral(v, label, lo=0, hi=10_000_000):
    need(type(v) is int and lo <= v <= hi, "INVALID_NONNEGATIVE_INTEGER:" + label)
    return v


def finite(v, label, lo=0., hi=1.):
    need(type(v) in (int, float) and lo <= v <= hi, "INVALID_FRACTION:" + label)
    return float(v)


def slot_names(style):
    need(style in WEAPON_STYLES, "UNKNOWN_WEAPON_STYLE")
    return (*BASE_SLOTS, *OPTIONAL_SLOTS) if style != "TWO_HAND" else BASE_SLOTS


def validate_contract(doc):
    example = load_strict(DEFAULT_CONFIG)
    exact_keys(doc, example, "root")
    need(doc["schema"] == example["schema"], "SCHEMA_VERSION_MISMATCH")
    need(doc["objective"] == "TOTAL_DPS", "ONLY_TOTAL_DPS_SUPPORTED")
    need(doc["optimization_scope"] == example["optimization_scope"], "EQUIPMENT_SEARCH_NOT_ALLOWED")
    for section in ("character", "gear", "budget", "search", "encounter", "execution"):
        exact_keys(doc[section], example[section], section)
    c = doc["character"]
    for field in ("class", "specialization", "race", "talent_code", "optional_simc_profile"):
        need(c[field] is None or (type(c[field]) is str and len(c[field].strip()) > 0 and len(c[field]) <= 4096), "INVALID_CHARACTER_FIELD:" + field)
    need(c["apl"] == "SIMC_DEFAULT", "CUSTOM_APL_OUT_OF_CURRENT_CONTRACT")

    g = doc["gear"]
    integral(g["target_item_level"], "target_item_level", 1, 2000)
    need(g["budget_mode"] in BUDGET_MODES, "INVALID_BUDGET_MODE")
    for f in ("manual_total_chmv_including_gems_flask", "manual_gear_chmv_excluding_gems_flask"):
        if g[f] is not None:
            integral(g[f], f, 1)
    if g["budget_mode"] == "MANUAL_TOTAL_INCLUSIVE":
        need(g["manual_total_chmv_including_gems_flask"] is not None and g["manual_gear_chmv_excluding_gems_flask"] is None, "MANUAL_TOTAL_MODE_AMBIGUOUS")
    elif g["budget_mode"] == "MANUAL_GEAR_EXCLUSIVE":
        need(g["manual_gear_chmv_excluding_gems_flask"] is not None and g["manual_total_chmv_including_gems_flask"] is None, "MANUAL_GEAR_MODE_AMBIGUOUS")
    else:
        need(g["manual_total_chmv_including_gems_flask"] is None and g["manual_gear_chmv_excluding_gems_flask"] is None, "ITEMLEVEL_MODE_MANUAL_VALUES_NOT_ALLOWED")
    need(g["weapon_style"] is None or g["weapon_style"] in WEAPON_STYLES, "UNKNOWN_WEAPON_STYLE")
    need(g["standard_items_have_special_effects"] is False, "STANDARD_GEAR_EFFECT_NOT_ALLOWED")
    need(g["tier_set_pieces"] == 4, "TIER4_REQUIRED_FOR_V016")
    need(type(g["special_gear"]) is list, "SPECIAL_GEAR_NOT_ARRAY")
    need(type(g["trinkets"]) is list and len(g["trinkets"]) == 2, "TWO_TRINKET_SLOTS_REQUIRED")
    need(type(g["embellishments"]) is list and len(g["embellishments"]) == 2, "TWO_EMBELLISHMENT_SLOTS_REQUIRED")
    for category in ("trinkets", "embellishments"):
        for x in g[category]:
            need(x is None or type(x) is dict and type(x.get("item_id")) is int and x["item_id"] > 0 and x.get("source_status") == "VERIFIED_RAW", "UNVERIFIED_SELECTION:" + category)
    chosen = set()
    for item in g["special_gear"]:
        need(type(item) is dict, "SPECIAL_GEAR_ENTRY_NOT_OBJECT")
        exact_keys(item, ("slot", "item_id", "item_level", "fixed_secondary", "source_status"), "special_gear_entry")
        slot = item["slot"]
        need(slot in (*BASE_SLOTS, *OPTIONAL_SLOTS) and slot not in chosen, "DUPLICATE_OR_INVALID_SPECIAL_SLOT")
        chosen.add(slot)
        integral(item["item_id"], "special_gear.item_id", 1)
        integral(item["item_level"], "special_gear.item_level", 1, 2000)
        need(item["source_status"] == "VERIFIED_RAW", "UNVERIFIED_SPECIAL_GEAR")
        exact_keys(item["fixed_secondary"], STAT_KEYS, "special_gear.fixed_secondary")
        for stat in STAT_KEYS:
            integral(item["fixed_secondary"][stat], "special_gear.fixed_secondary." + stat)
        need("effect_equivalent" not in item and "uptime" not in item, "EFFECT_EQUIVALENT_EXCLUDED")

    b = doc["budget"]
    for section in ("general_gems", "special_gem", "flask", "enchants"):
        exact_keys(b[section], example["budget"][section], "budget." + section)
    gems = b["general_gems"]
    need((gems["count"], gems["primary_rating"], gems["secondary_rating"], gems["total_rating"], gems["model"]) == (6,16,7,138,"FLEXIBLE_BUDGET_APPROXIMATION"), "GENERAL_GEM_POLICY_CHANGED")
    need(b["special_gem"]["choices"] == example["budget"]["special_gem"]["choices"], "SPECIAL_GEM_OPTIONS_CHANGED")
    need(b["special_gem"]["choice"] in (None, *b["special_gem"]["choices"]), "INVALID_SPECIAL_GEM_SELECTION")
    integral(b["flask"]["secondary_rating_budget"], "flask_rating")
    need(b["flask"]["distribution"] == "UNSELECTED_FREE_BUDGET", "FLASK_TYPE_MUST_NOT_BE_PINNED")
    need(b["flask"]["source_status"] in ("PILOT_MATCHED_NOT_UNIVERSAL_VERIFICATION", "VERIFIED_RAW"), "UNKNOWN_FLASK_PROVENANCE")
    need(b["enchants"]["included_in_optimization_budget"] is False, "ENCHANT_BUDGET_EXCLUDED")
    need(type(b["enchants"]["by_slot"]) is dict, "ENCHANT_MAP_REQUIRED")
    for f in ("food", "potion", "augmentation_rune", "temporary_weapon_enchant"):
        need(b[f] is None or isinstance(b[f], (str, dict)), "INVALID_CONSUMABLE:" + f)

    s = doc["search"]
    need(s["stat_order"] == list(STAT_KEYS), "STAT_ORDER_CHANGED")
    for bound in ("minimum_share", "maximum_share"):
        exact_keys(s[bound], STAT_KEYS, bound)
        for stat in STAT_KEYS:finite(s[bound][stat], bound + "." + stat)
    for stat in STAT_KEYS:
        need(s["minimum_share"][stat] <= s["maximum_share"][stat], "MIN_MAX_INVERTED:" + stat)
    need(sum(s["minimum_share"].values()) <= 1.0+1e-9, "INFEASIBLE_MINIMUM_SHARES")
    need(sum(s["maximum_share"].values()) >= 1.0-1e-9, "INFEASIBLE_MAXIMUM_SHARES")
    finite(s["near_dps_loss_max_fraction"], "near_dps_loss_max_fraction")
    finite(s["meaningful_l1_distance_min_fraction"], "meaningful_l1_distance_min_fraction")
    need(s["iterations_policy"] == "ADAPTIVE_CAPPED", "ITERATIONS_POLICY_CHANGED")
    e = doc["encounter"]
    need(e["fight_style"] in ("Patchwerk", "HecticAddCleave", "DungeonSlice"), "FIGHT_STYLE_NOT_SUPPORTED_IN_CONTRACT")
    integral(e["targets"], "targets", 1, 50)
    integral(e["duration_seconds"], "duration_seconds", 1, 7200)
    finite(e["vary_combat_length_fraction"], "vary_combat_length_fraction", 0, 0.5)
    need(type(e["optimal_raid"]) is bool, "RAID_FLAG_MUST_BE_BOOL")
    integral(e["bloodlust_time_seconds"], "bloodlust_time_seconds", 0, 7200)
    for field in ("external_buffs", "custom_raid_events"):
        need(type(e[field]) is list, "ENC_OPTIONS_MUST_BE_ARRAY:" + field)
    need(doc["execution"] == {"simc_invocation_requested":False,"shared_state_mutation":False}, "EXECUTION_DISABLED_V016")
    return doc


def budget_table_amount(table, target_ilvl, style):
    need(type(table) is dict and table.get("schema") == "WEQUIP_RawItemlevelBudgetExport-v016", "UNSUPPORTED_BUDGET_EXPORT_SCHEMA")
    need(table.get("status") == "VERIFIED_RAW", "UNVERIFIED_BUDGET_EXPORT")
    levels = table.get("levels")
    need(type(levels) is dict, "LEVELS_OBJECT_REQUIRED")
    records = levels.get(str(target_ilvl))
    need(type(records) is dict and style in records, "NO_VERIFIED_BUDGET_FOR_LEVEL_AND_WEAPON_STYLE")
    record = records[style]
    need(type(record) is dict and set(record) == {"slots", "source_id"}, "INVALID_BUDGET_RECORD")
    slots = record["slots"]
    expected = slot_names(style)
    need(type(slots) is dict and set(slots) == set(expected), "SLOT_COVERAGE_MISSING_OR_UNEXPECTED")
    need(type(record["source_id"]) is str and bool(record["source_id"].strip()), "BUDGET_PROVENANCE_MISSING")
    for k,v in slots.items():integral(v, "slot_budget."+k)
    return slots, record["source_id"]


def calculate_budget(config, verified_table=None):
    """No rating returned without explicit manual input or verified external table."""
    validate_contract(config)
    gear = config["gear"]
    b = config["budget"]
    gem_rating = b["general_gems"]["total_rating"]
    flask_rating = b["flask"]["secondary_rating_budget"]
    mode = gear["budget_mode"]
    base_detail = None
    budget_origin = None
    if mode == "ITEMLEVEL_VERIFIED_TABLE":
        if verified_table is None or gear["weapon_style"] is None:
            return {"budget_resolved":False,"blockers":["VERIFIED_ITEMLEVEL_BUDGET_AND_WEAPON_STYLE_REQUIRED"],"total":None}
        slots, source_id = budget_table_amount(verified_table, gear["target_item_level"], gear["weapon_style"])
        for item in gear["special_gear"]:
            need(item["slot"] in slots, "SPECIAL_ITEM_SLOT_NOT_IN_STANDARD_GEAR")
            slots = dict(slots)
            slots[item["slot"]] = sum(item["fixed_secondary"].values())
        gear_rating = sum(slots.values())
        base_detail = slots
        budget_origin = source_id
    elif mode == "MANUAL_TOTAL_INCLUSIVE":
        total = gear["manual_total_chmv_including_gems_flask"]
        need(total >= gem_rating + flask_rating, "TOTAL_SMALLER_THAN_GEMS_AND_FLASK")
        gear_rating = total - gem_rating - flask_rating
        budget_origin = "USER_EXPLICIT_TOTAL_INCLUSIVE"
    else:
        gear_rating = gear["manual_gear_chmv_excluding_gems_flask"]
        budget_origin = "USER_EXPLICIT_GEAR_EXCLUSIVE"
    total = gear_rating + gem_rating + flask_rating
    locked = {stat: sum(s["fixed_secondary"][stat] for s in gear["special_gear"]) for stat in STAT_KEYS}
    reserved = sum(locked.values())
    need(reserved <= gear_rating, "SPECIAL_LOCKED_STATS_EXCEED_GEAR_BUDGET")
    flex = total - reserved
    limits = config["search"]
    mins = {k:max(locked[k],int(__import__("math").ceil(total*limits["minimum_share"][k]-1e-9))) for k in STAT_KEYS}
    maxes = {k:int(__import__("math").floor(total*limits["maximum_share"][k]+1e-9)) for k in STAT_KEYS}
    need(all(mins[k] <= maxes[k] for k in STAT_KEYS), "LOCKED_STATS_VIOLATE_SHARE_CAP")
    need(sum(mins.values()) <= total <= sum(maxes.values()), "INTEGER_SHARE_BOUNDS_INFEASIBLE")
    return {"budget_resolved":True,"total":total,"gear":gear_rating,"general_gems":gem_rating,"flask":flask_rating,
            "locked_special_secondary":locked,"locked_special_total":reserved,"flexible_rating_pool":flex,
            "minimum_absolute_inclusive":mins,"maximum_absolute_inclusive":maxes,"slot_breakdown":base_detail,
            "budget_origin":budget_origin,"blockers":[]}


def preflight(config, table=None):
    """Offline readiness only. No SimC launch permission or actual execution construction."""
    budget = calculate_budget(config, table)
    issues = list(budget.get("blockers", []))
    for f in ("class", "specialization", "race", "talent_code"):
        if config["character"][f] is None:issues.append("CHARACTER_SELECTION_REQUIRED:"+f)
    if config["gear"]["weapon_style"] is None:issues.append("WEAPON_STYLE_REQUIRED")
    for f in ("trinkets", "embellishments"):
        if any(x is None for x in config["gear"][f]):issues.append("FIXED_SELECTION_REQUIRED:"+f)
    if config["budget"]["special_gem"]["choice"] is None:issues.append("SPECIAL_GEM_EFFECT_NOT_SELECTED")
    if config["budget"]["flask"]["source_status"] != "VERIFIED_RAW":issues.append("FLASK_UNIVERSAL_SEASON_BUDGET_NOT_VERIFIED")
    issues.append("REPRESENTATIVE_PROFILE_SIMC_SEMANTICS_NOT_VERIFIED")
    issues.append("STATS_INJECTION_DOUBLE_COUNT_NOT_VALIDATED")
    return {"status":"SCENARIO_CONTRACT_OFFLINE_ONLY", "budget":budget,
            "scenario_selection_complete":not any(x.endswith("_REQUIRED") or "SELECTION_REQUIRED" in x or x.startswith("CHARACTER_SELECTION_REQUIRED") or x.startswith("SPECIAL_GEM_EFFECT") for x in issues),
            "execution_ready":False,"simc_executed":False,"official_m0_pass":False,
            "blockers":list(dict.fromkeys(issues)),"v015_original_pilot_unchanged":True}


def main(argv=None):
    ap=argparse.ArgumentParser(description="v016 offline, no SimC execution")
    ap.add_argument("--config", default=str(DEFAULT_CONFIG))
    ap.add_argument("--budget-export", default=None)
    ap.add_argument("--output-root", default=str(ROOT / "SCENARIO_V016_RESULTS"))
    args=ap.parse_args(argv)
    config_path=Path(args.config).resolve()
    out_root=Path(args.output_root).resolve()
    try:
        conf=load_strict(config_path)
        table=load_strict(Path(args.budget_export).resolve()) if args.budget_export else None
        report=preflight(conf, table)
        report["config_sha256"]=sha(config_path)
        report["budget_source_sha256"]=sha(Path(args.budget_export).resolve()) if args.budget_export else None
        exit_code=0
    except (OSError, ValueError, TypeError, KeyError, json.JSONDecodeError) as ex:
        report={"status":"DENIED_SCENARIO_CONTRACT", "execution_ready":False,"simc_executed":False,
                "reason":type(ex).__name__ + ": " + str(ex)}
        exit_code=2
    out_root.mkdir(parents=True,exist_ok=True)
    run_dir=out_root / (dt.datetime.now(dt.timezone.utc).strftime("SCENARIO_%Y%m%dT%H%M%S_%fZ_")+uuid.uuid4().hex[:7])
    run_dir.mkdir()
    target=run_dir/"scenario_preflight_receipt.json"
    write_json(target,report)
    print("[" + ("PASS_OFFLINE" if exit_code == 0 else "DENIED") + "] " + report["status"])
    print("Receipt: " + str(target))
    try:
        if os.name=="nt":os.startfile(str(run_dir))
    except (OSError, AttributeError):
        pass
    return exit_code


if __name__ == "__main__":
    sys.exit(main())
