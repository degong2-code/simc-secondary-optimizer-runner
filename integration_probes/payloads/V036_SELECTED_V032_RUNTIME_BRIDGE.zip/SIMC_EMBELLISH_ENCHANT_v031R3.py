#!/usr/bin/env python3
"""v031R3: correct mage cloth crafted wrists while preserving v031R2 food and Omnium.

No Work OS mutation. No separate SimC effect A/B tests. Native SimC has authority.
"""
from __future__ import annotations
import argparse,datetime as dt,hashlib,json,math,os,re,subprocess,sys,uuid,zipfile
from pathlib import Path

import CHMV_TRINKET_GUIDED_SEARCH_v030 as old
import CHMV_FOUR_STAT_FLASK_SEARCH_v029 as prev

ROOT=Path(__file__).resolve().parent
DEFAULT_RACE='dwarf'
DEFAULT_TALENTS='C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzYmFMzQzMzMAAAGAwMz0sssMDAgNAAAzMDbWmxMLzYMzMzMswMzMzMAADAAwAMzAmBADzMD'
BASE_RACE='void_elf'
BASE_TALENTS='C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAAEwMzMLLzMxCAAwMzMjNLzMzsMjxYmZwCzYmZGAgBAAYmZBAMDAGmZG'
ALLOWED_RACES=frozenset('blood_elf draenei dwarf gnome human night_elf orc tauren troll undead goblin worgen pandaren pandaren_alliance pandaren_horde void_elf highmountain_tauren lightforged_draenei nightborne dark_iron_dwarf maghar_orc zandalari_troll kul_tiran vulpera mechagnome earthen'.split())
STAT_KEYS=('crit_rating','haste_rating','mastery_rating','versatility_rating')
TIER={'head':271564,'shoulders':271562,'chest':271567,'legs':271563}
CRAFT={'back':239656,'wrists':239648}
TRINKETS={'trinket1':270164,'trinket2':281215}
ENCHANT={
 'finger1':'eyes_of_the_eagle_2',
 'finger2':'eyes_of_the_eagle_2',
 'main_hand':'rite_of_the_hashey_2',
 'chest':'mark_of_the_worldsoul_2',
 'legs':'arcanoweave_spellthread_2',
}
# 334 sample crafted items; genuine crafted equipment is used, rather than pretending
# that a raid drop is craftable. Native SimC still must accept/evaluate both items.
CRAFT_LINES={
 'back':'back=adherents_silken_shroud,id=239656,ilevel=334,source=local,embellishment=arcanoweave_lining,crafted_stats=49/36',
 'wrists':'wrists=martyrs_bindings,id=239648,ilevel=334,source=local,gem_id=240892,embellishment=arcanoweave_lining,crafted_stats=49/36',
}
EXPECTED_4SET_NAME='cumulative_power'
EXPECTED_SIMC_SHA=prev.old.native.BINARY_SHA
DEFAULT_OMNIUM='136822:1/136817:1/136821:1/136814:1'
DEFAULT_FOOD='royal_roast'
# Proven by actual native SimC exit 82: 237834 is plate, invalid on mage.
# 239648 is Midnight crafted cloth wrists, compatible with mage.
KNOWN_COMPATIBLE_CLOTH_WRISTS = frozenset({239648})
class Refuse(RuntimeError):pass

def need(ok,msg):
 if not ok:raise Refuse(msg)
def dump(path,x):
 Path(path).write_text(json.dumps(x,ensure_ascii=False,indent=2,sort_keys=True,allow_nan=False)+'\n',encoding='utf-8')
def sha(path):
 h=hashlib.sha256()
 with Path(path).open('rb') as f:
  for b in iter(lambda:f.read(1048576),b''):h.update(b)
 return h.hexdigest()

def source_profile(choice='primary23_four_colors', *, race=DEFAULT_RACE, talents=DEFAULT_TALENTS):
 need(race in ALLOWED_RACES, 'INVALID_RACE_OPTION')
 need(bool(re.fullmatch(r'[A-Za-z0-9_\-]{60,160}',talents)), 'INVALID_TALENT_EXPORT_FORMAT')
 need(CRAFT.get('wrists') in KNOWN_COMPATIBLE_CLOTH_WRISTS, 'CRAFT_WRISTS_NOT_MAGE_CLOTH')
 need('id=239648,' in CRAFT_LINES['wrists'] and 'martyrs_bindings' in CRAFT_LINES['wrists'], 'WRISTS_ITEM_ID_NAME_INCONSISTENT')
 base=old.load_new_reference(choice)['source_simc'].replace('\r\n','\n')
 old_race='race='+BASE_RACE
 old_talents='talents='+BASE_TALENTS
 need(base.splitlines().count(old_race)==1, 'OLD_RACE_IDENTITY_NOT_UNIQUE')
 need(base.splitlines().count(old_talents)==1, 'OLD_TALENT_IDENTITY_NOT_UNIQUE')
 base=base.replace(old_race+'\n','race='+race+'\n',1)
 base=base.replace(old_talents+'\n','talents='+talents+'\n',1)
 need(base.splitlines().count('race='+race)==1, 'NEW_RACE_NOT_EXACT')
 need(base.splitlines().count('talents='+talents)==1, 'NEW_TALENTS_NOT_EXACT')
 base=base.replace('# Four selected tier item IDs; set bonus actual application is not yet verified',
     '# Four tier pieces; v030 native combat JSON2 contains Cumulative Power tier-4pc buff')
 lines=[];done=set()
 for row in base.splitlines():
  key,eq,rest=row.partition('=')
  if eq and key in CRAFT_LINES:
   need(key not in done,'DUPLICATE_CRAFT_SLOT:'+key);done.add(key)
   lines.append(CRAFT_LINES[key]);continue
  if eq and key in ENCHANT:
   need(key not in done,'DUPLICATE_ENCHANT_SLOT:'+key);done.add(key)
   need(not re.search(r'(?:^|,)enchant(?:_id)?=',rest),'PREEXISTING_ENCHANT_REQUIRES_REVIEW:'+key)
   lines.append(row+',enchant='+ENCHANT[key]);continue
  lines.append(row)
 need(set(CRAFT_LINES)|set(ENCHANT)==done,'MISSING_CRAFT_OR_ENCHANT_SLOT')
 # A primary-stat meal is actual SimC input, not part of CHMV rating budget.
 food_rows=[i for i,x in enumerate(lines) if x.startswith('food=')]
 need(len(food_rows)==1, 'MISSING_OR_DUPLICATE_FOOD_OPTION')
 need(lines[food_rows[0]]=='food=disabled','UNEXPECTED_PREVIOUS_FOOD')
 lines[food_rows[0]]='food='+DEFAULT_FOOD
 omnium_rows=[x for x in lines if x.startswith('omnium_talents=')]
 need(omnium_rows==['omnium_talents='+DEFAULT_OMNIUM],'OMNIUM_CHANGED_REQUIRES_USER_APPROVAL')
 txt='\n'.join(lines)+'\n'
 need(sum('embellishment=arcanoweave_lining' in x for x in lines)==2,'LINING_COUNT_NOT_TWO')
 for slot,id in (TIER|TRINKETS|CRAFT).items():
  rows=[x for x in lines if x.startswith(slot+'=')]
  need(len(rows)==1 and re.search(r'(?:^|,)id='+str(id)+r'(?:,|$)',rows[0]) is not None,'ITEM_ID_MISMATCH:'+slot)
 for slot in ('neck','head','waist','finger1','finger2','wrists'):
  need(any(x.startswith(slot+'=') and 'gem_id=' in x for x in lines),'GEMS_MISSING_ON_SLOT:'+slot)
 return txt

def input_profile(base,out,*,kind,total=None,iterations=1):
 # Readonly native calibration has NO CHMV override; creates a representative
 # profile solely to sample SimC's actual 334 crafted-item secondary ratings.
 rows=[];oldgear=0
 for x in base.splitlines():
  if x.startswith('json2=') or re.match(r'^gear_(crit|haste|mastery|versatility)_rating=',x):oldgear+=1;continue
  if x.startswith('iterations='):x='iterations='+str(iterations)
  if x.startswith('max_time='):x='max_time='+('5' if kind=='native-calibrate' else '300')
  rows.append(x)
 if not any(x.startswith('optimal_raid=') for x in rows):rows.append('optimal_raid=1')
 need(sum(x.startswith('optimal_raid=') for x in rows)==1,'DUPLICATE_RAID_BUFF_OPTION')
 if kind=='dps':
  need(type(total)==int and 2500<=total<=4000,'SUSPICIOUS_NATIVE_TOTAL')
  # keep v030 confirmed scout reference shape while preserving total.
  target=[600,1140,1113,329]
  delta=total-sum(target)
  target[2]+=delta
  need(all(0<=x<=total//2 for x in target),'INVALID_DPS_CANDIDATE')
  need(target[0]>=16 and target[1]>=16,'OIL_FLOOR_BROKEN')
  # Auto flask: highest stat for this candidate, determined here not reused
  # from the old profile. Sums across gear override and flask == target.
  ix=max(range(4),key=lambda i:(target[i],-i))
  if any(x.startswith('flask=') for x in rows):
   rows=[('flask='+prev.FLASKS[STAT_KEYS[ix]]) if x.startswith('flask=') else x for x in rows]
  else:raise Refuse('MISSING_FLASK_OPTION')
  inject=list(target);inject[ix]-=165
  need(all(x>=0 for x in inject),'NEGATIVE_GEAR_INJECTION')
  for s,val in zip(STAT_KEYS,inject):rows.append('gear_'+s+'='+str(val))
 else:target=None
 rows.append('json2='+str(Path(out).resolve()))
 txt='\n'.join(rows)+'\n'
 need('temporary_enchant=main_hand:thalassian_phoenix_oil_2' in txt,'PHOENIX_OIL_REMOVED')
 return txt,dict(zip(STAT_KEYS,target)) if target else None

def ids_from_native(p):
 out={}
 for slot,row in p['gear'].items():
  m=re.search(r'(?:^|,)id=(\d+)(?:,|$)',row.get('encoded_item',''))
  if m:out[slot]=int(m.group(1))
 return out

def item_sum_native(p):
 result={k:0 for k in STAT_KEYS}
 for slot,row in p['gear'].items():
  if slot.startswith('trinket'):continue
  for k in STAT_KEYS:
   v=row.get(k,0)
   need(type(v) in (float,int) and math.isfinite(v) and v>=0,'BAD_NATIVE_SLOT_STATS:'+slot+':'+k)
   result[k]+=round(v)
 return result

def native_check(doc,*,has_dps=False,total=None,target=None,race=DEFAULT_RACE,talents=DEFAULT_TALENTS):
 need(doc.get('report_version')=='2.0.0','JSON2_VERSION_MISMATCH')
 need(doc.get('git_revision')==prev.EXPECTED_REV,'SIMC_REVISION_CHANGED')
 sim=doc.get('sim',{});need(len(sim.get('players',[]))==1,'PLAYER_COUNT_NOT_ONE')
 p=sim['players'][0]
 need(p.get('race')==race,'ACTUAL_RACE_MISMATCH:'+str(p.get('race')))
 need(p.get('talents')==talents,'ACTUAL_TALENTS_MISMATCH:'+str(p.get('talents')))
 need(p.get('specialization')=='Arcane Mage','WRONG_SPECIALIZATION')
 need(p.get('food')==DEFAULT_FOOD,'ACTUAL_FOOD_MISMATCH:'+str(p.get('food')))
 ids=ids_from_native(p)
 for slot,id in (TIER|TRINKETS|CRAFT).items():
  need(ids.get(slot)==id,'ACTUAL_ITEM_ID_MISMATCH:'+slot)
  need(p['gear'][slot]['ilevel']==334,'ACTUAL_ITEM_ILVL_NOT_334:'+slot)
 for slot in CRAFT:
  text=p['gear'][slot]['encoded_item']
  need('embellishment=arcanoweave_lining' in text,'NATIVE_EMBELLISHMENT_NOT_ECHOED:'+slot)
 for slot,token in ENCHANT.items():
  text=p['gear'][slot]['encoded_item']
  need('enchant='+token in text or 'enchant_id=' in text,'ENCHANT_NOT_ECHOED:'+slot)
 gem_ids=prev.old.gems.parse_gem_ids(p['gear'])
 need(sum(len(g) for g in gem_ids.values())==7,'NOT_7_NATIVE_GEMS')
 need(any('cumulative_power'==b.get('name') for b in p.get('buffs',[])), 'TIER4_BUFF_NOT_PRESENT') if has_dps else None
 warnings=[l.get('message','') for l in doc.get('logs',[]) if str(l.get('level','')).lower() in ('error','warning')]
 # Preserve all engine warnings; don't assert unsupported effects are correct.
 fatal=[m for m in warnings if any(t in m.lower() for t in ('unknown enchant','unknown embellish','unsupported enchant','not recognized','invalid embellish'))]
 need(not fatal,'SIMC_UNSUPPORTED_REQUESTED_EFFECT:'+str(fatal[:2]))
 gear=item_sum_native(p)
 if has_dps:
  got=p['collected_data']['buffed_stats']['stats']
  actual={k:int(round(got[k])) for k in STAT_KEYS}
  need(actual==target,'FINAL_CHMV_MISMATCH:'+str(actual)+' expected '+str(target))
  need(sum(actual.values())==total,'FINAL_CHMV_TOTAL_WRONG')
  opts=sim['options']
  need(opts['fight_style']=='Patchwerk' and opts['desired_targets']==1 and opts['fixed_time']==1,'FIGHT_SCENARIO_CHANGED')
  d=p['collected_data']['dps']
  need(d['count']>0 and float(d['mean'])>0,'DPS_MISSING')
  return {'native_gear_static_chmv':gear,'final_applied':actual,'dps_mean':d['mean'],
          'dps_mean_sem':d.get('mean_std_dev'),'dps_count':d['count'],
          'tier4_buff_recorded':True,'warnings':warnings}
 return {'native_gear_static_chmv':gear,'warnings':warnings}

def run_native(binary,folder,content,tag):
 folder.mkdir(exist_ok=True,parents=True)
 inp=folder/'input.simc';result=folder/'result.json'
 inp.write_text(content,encoding='utf-8')
 with (folder/'stdout.txt').open('w',encoding='utf-8') as so,(folder/'stderr.txt').open('w',encoding='utf-8') as se:
  p=subprocess.run([str(binary),str(inp)],cwd=str(binary.parent),stdin=subprocess.DEVNULL,
                   stdout=so,stderr=se,timeout=900,check=False)
 need(p.returncode==0,'SIMC_FAILED_'+tag+'_EXIT_'+str(p.returncode))
 need(result.is_file() and result.stat().st_size>1000,'MISSING_NATIVE_JSON_'+tag)
 return json.loads(result.read_text(encoding='utf-8-sig'))

def package(folder):
 path=folder/'EMBELLISH_ENCHANT_RESULTS_v031R3.zip'
 files=[p for p in sorted(folder.rglob('*')) if p.is_file() and p!=path]
 dump(folder/'FILE_INDEX_v031R3.json',{'files':[{'file':p.relative_to(folder).as_posix(),'size':p.stat().st_size,'sha256':sha(p)} for p in files]})
 files=[p for p in sorted(folder.rglob('*')) if p.is_file() and p!=path]
 with zipfile.ZipFile(path,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
  for p in files:z.write(p,p.relative_to(folder).as_posix())
 with zipfile.ZipFile(path) as z:need(z.testzip() is None,'ZIP_CRC_ERROR')
 return path

def main(argv=None):
 a=argparse.ArgumentParser()
 a.add_argument('--mode',choices=['plan','local-probe'],default='plan')
 a.add_argument('--simc-executable')
 a.add_argument('--gem-choice',choices=['primary23_four_colors','primary32'],default='primary23_four_colors')
 a.add_argument('--iterations',type=int,default=320)
 a.add_argument('--race',default=DEFAULT_RACE)
 a.add_argument('--talents',default=DEFAULT_TALENTS)
 a.add_argument('--output-root',default=str(ROOT/'V031R2_OUTPUTS'))
 args=a.parse_args(argv)
 try:
  need(60<=args.iterations<=1000,'ITERATIONS_OUTSIDE_BOUNDED_RANGE')
  source=source_profile(args.gem_choice,race=args.race,talents=args.talents)
  out=Path(args.output_root).resolve();out.mkdir(exist_ok=True,parents=True)
  folder=out/('RUN_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ_')+uuid.uuid4().hex[:8]);folder.mkdir()
  calpath=folder/'CALIBRATE_NATIVE'/'result.json';dpspath=folder/'DPS_NATIVE'/'result.json'
  cal_input,_=input_profile(source,calpath,kind='native-calibrate',iterations=1)
  (folder/'CALIBRATION_PREVIEW_v031R3.simc').write_text(cal_input,encoding='utf-8')
  receipt={'schema':'SIMCSecondaryEmbellishEnchant-v031R3','status':'PENDING',
           'character_race':args.race,'character_spec':'arcane','talent_string':args.talents,'omnium_talents':DEFAULT_OMNIUM,'food':DEFAULT_FOOD,'food_is_primary_stat_not_chmv':True,'omnium_talents_mode':'KEEP_LEGACY_SEPARATE_TREE','tier_ids':TIER,'trinket_ids':TRINKETS,'crafted_ids':CRAFT,'enchants':ENCHANT,
           'embellishments':['arcanoweave_lining','arcanoweave_lining'],
           'expected_effect_owner':'NATIVE_SIMC', 'previous_dps_cache_hits':0,
           'native_simc_calls':0,'chmv_total_legacy_3182_not_unconditionally_assumed':True}
  try:
   if args.mode=='plan':
    target=[600,1140,1113,329]
    dps_input,dps_target=input_profile(source,dpspath,kind='dps',total=3182,iterations=args.iterations)
    (folder/'DPS_PREVIEW_UNCALIBRATED_v031R3.simc').write_text(dps_input,encoding='utf-8')
    receipt.update({'status':'OFFLINE_PLAN_PASS','native_gear_total_unverified':True,'provisional_chmv_total':3182})
   else:
    need(args.simc_executable is not None,'SIMC_BINARY_REQUIRED')
    binary=Path(args.simc_executable).resolve()
    need(binary.is_file(),'SIMC_EXE_NOT_FOUND')
    need(sha(binary)==EXPECTED_SIMC_SHA,'SIMC_BINARY_HASH_CHANGED')
    print('[SIMC] native crafted gear calibration (one 5-sec input)')
    receipt['native_simc_calls']=1
    cal=native_check(run_native(binary,calpath.parent,cal_input,'CALIBRATE'),race=args.race,talents=args.talents)
    observed=cal['native_gear_static_chmv'];g=sum(observed.values())
    total=g+138+165+32
    need(2500<=total<=4000,'UNEXPECTED_NEW_CHMV_BUDGET')
    receipt['calibration']={'native_nontrinket_gear_vector':observed,'native_gear_total':g,
                             'general_gems_budget':138,'flask_budget':165,'oil_fixed_budget':32,
                             'corrected_total_chmv':total,'warnings':cal['warnings']}
    dps_input,dps_target=input_profile(source,dpspath,kind='dps',total=total,iterations=args.iterations)
    (folder/'DPS_PREVIEW_AFTER_CALIBRATION_v031R3.simc').write_text(dps_input,encoding='utf-8')
    print('[SIMC] 300-sec DPS smoke with two linings + five enchants; target=',dps_target)
    receipt['native_simc_calls']=2
    dps=native_check(run_native(binary,dpspath.parent,dps_input,'DPS'),has_dps=True,total=total,target=dps_target,race=args.race,talents=args.talents)
    # No new simulation with old gear signature can populate this cache.
    receipt['dps']=dps
    receipt['status']='PASS_V031R2_PRIMARY_FOOD_NATIVE_DPS'
  except Exception as e:
   receipt['status']='PARTIAL_OR_BLOCKED';receipt['error']=type(e).__name__+':'+str(e)
  dump(folder/'EMBELLISH_ENCHANT_RECEIPT_v031R3.json',receipt)
  (folder/'SUMMARY_KO_v031R3.txt').write_text('v031R3 Omnium 보존·Royal Roast·Dwarf·지정 특성 · '+receipt['status']+'\n'+
    '종족: '+args.race+'\n특성: '+args.talents+'\n'+
    'Omnium: '+DEFAULT_OMNIUM+'\n음식: '+DEFAULT_FOOD+' (주능력치, CHMV 제외)\n'+
    '등과 손목: 실제 제작 장비 아이템 ID 239656,239648\n'+
    '장식: Arcanoweave Lining 2개; 4세트 유지\n'+
    '반지: Eyes of the Eagle ×2; 무기: Rite of the Hash\'ey\n'+
    '가슴: Mark of the Worldsoul (+50 주능력치); 다리: Arcanoweave Spellthread (+41 지능)\n'+
    '실제 SimC 효과 DPS 계산에 위임. 과거 장신구 DPS 캐시 재사용 없음.\n'+
    ('총량(신규 SimC 검증): '+str(receipt.get('calibration',{}).get('corrected_total_chmv'))+'\n' if 'calibration' in receipt else '')+
    ('오류: '+receipt['error']+'\n' if receipt.get('error') else ''),encoding='utf-8')
  zipout=package(folder)
  print('[STATUS]',receipt['status']);print('[RESULT]',zipout);print('[FOLDER]',folder)
  if os.name=='nt':
   try:os.startfile(str(folder))
   except (AttributeError,OSError):pass
  return 0 if receipt['status'] in ('OFFLINE_PLAN_PASS','PASS_V031R2_PRIMARY_FOOD_NATIVE_DPS') else 2
 except Exception as e:
  print('[BLOCKED]',type(e).__name__,str(e),file=sys.stderr);return 2

if __name__=='__main__':raise SystemExit(main())
