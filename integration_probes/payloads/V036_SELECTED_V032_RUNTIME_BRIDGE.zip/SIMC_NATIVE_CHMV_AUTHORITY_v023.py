#!/usr/bin/env python3
"""v023: SimC JSON2 native equipment stats are authoritative, WEQUIP is context.

Read-only. The exact v022 PC evidence is pinned, and no season-wide or other-ilvl
budget is extrapolated. This file does not run SimC or perform gem injection.
"""
from __future__ import annotations
import argparse
import csv
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import uuid
import zipfile

import CHMV_FINAL_APPLIED_v022 as final
import STANDARD_BUDGET_PROFILE_v020 as budget

ROOT=Path(__file__).resolve().parent
EVIDENCE=ROOT/'EVIDENCE_V023_INPUTS'/'FINAL_APPLIED_CHMV_RESULTS_v022_USER_PC.zip'
EVIDENCE_SHA256='869038bb495b5428d7de520b44b6f0928fa380e820ee6d458535cdd2572e6b14'
STATS=final.STATS
TRINKETS=('trinket1','trinket2')
EXPECTED_SLOTS=('head','neck','shoulders','back','chest','wrists','hands','waist',
                'legs','feet','finger1','finger2','trinket1','trinket2','main_hand')


def need(cond,code):
    if not cond:raise ValueError(code)


def digest(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as handle:
        for chunk in iter(lambda:handle.read(1024*1024),b''):h.update(chunk)
    return h.hexdigest()


def native_slots(doc,expected_level=334):
    """Return exact base secondary vectors for all 15 slots in ONE observed SimC run.

    Do not use player buffed_stats or WEQUIP scaling as raw gear stats.
    """
    need(type(expected_level) is int and expected_level>0,'INVALID_TARGET_ILEVEL')
    need(doc.get('git_revision')=='7bc1071','SIMC_VERSION_UNVERIFIED')
    sim=doc.get('sim',{})
    need(sim.get('options',{}).get('dbc',{}).get('Live',{}).get('wow_version')=='12.1.5.70448','SIMC_GAME_BUILD_UNVERIFIED')
    players=sim.get('players')
    need(isinstance(players,list) and len(players)==1,'NATIVE_ONE_PLAYER_REQUIRED')
    gear=players[0].get('gear')
    need(isinstance(gear,dict) and set(gear)==set(EXPECTED_SLOTS),'STANDARD_GEAR_SLOT_SET_MISMATCH')
    result=[]
    for slot in EXPECTED_SLOTS:
        item=gear[slot]
        need(isinstance(item,dict),'INVALID_GEAR_ITEM:'+slot)
        raw=item.get('encoded_item','')
        iid=re.search(r'(?:^|,)id=(\d+)(?:,|$)',raw)
        need(iid is not None,'MISSING_ITEM_ID:'+slot)
        need('source=local' in raw,'ITEM_NOT_LOCAL_SOURCE:'+slot)
        need(item.get('ilevel')==expected_level,'NATIVE_LEVEL_MISMATCH:'+slot)
        values={}
        for k in STATS:
            value=item.get(k,0)
            need(type(value) is int and value>=0,'INVALID_NATIVE_STAT:'+slot+':'+k)
            values[k]=value
        result.append({'slot':slot,'item_id':int(iid.group(1)),'ilevel':expected_level,
                       'native_secondary':values,'native_secondary_total':sum(values.values()),
                       'excluded_from_redistributable_gear_budget':slot in TRINKETS})
    return result


def read_v022(zip_path=EVIDENCE):
    p=Path(zip_path)
    need(p.is_file(),'V022_PC_EVIDENCE_MISSING')
    need(digest(p)==EVIDENCE_SHA256,'V022_PC_EVIDENCE_SHA_MISMATCH')
    with zipfile.ZipFile(p) as z:
        need(z.testzip() is None,'V022_PC_ZIP_BAD_CRC')
        needed={'FINAL_APPLIED_CHMV_RECEIPT_v022.json','oil_only.json','flask_and_oil.json'}
        need(needed.issubset(set(z.namelist())),'V022_PC_JSON_MISSING')
        receipt=json.loads(z.read('FINAL_APPLIED_CHMV_RECEIPT_v022.json'))
        oil=json.loads(z.read('oil_only.json'))
        both=json.loads(z.read('flask_and_oil.json'))
    need(receipt.get('status')=='OIL_PROBE_PASS','V022_PC_OIL_NOT_PASS')
    need(receipt.get('oil_probe',{}).get('all_verified') is True,'V022_PC_OIL_NOT_VERIFIED')
    need(all(receipt['oil_probe'][case].get('exit_code')==0 and receipt['oil_probe'][case].get('stat_delta_verified') is True
             for case in ('oil_only','flask_and_oil')),'V022_PC_CASE_NOT_VALID')
    return receipt,oil,both


def authority_record(receipt,oil,both,nominal_snapshot=None,level=334):
    """Pin selected profile/native level. Full same-level item coverage is mandatory.

    Nominal references may be attached for auditing, never substituted.
    """
    oil_slots=native_slots(oil,level)
    both_slots=native_slots(both,level)
    need(oil_slots==both_slots,'NATIVE_EQUIPMENT_CHANGED_BETWEEN_CASES')
    a=__import__('SIMC_STAT_ATTRIBUTION_v021').snapshot(oil)
    b=__import__('SIMC_STAT_ATTRIBUTION_v021').snapshot(both)
    gear={k:sum(x['native_secondary'][k] for x in oil_slots if not x['excluded_from_redistributable_gear_budget']) for k in STATS}
    need(gear==a['gear_secondary']==b['gear_secondary'],'NATIVE_GEAR_TOTAL_INCONSISTENT')
    need(a['buffed_minus_gear']==final.OIL,'NATIVE_OIL_DELTA_MISMATCH')
    both_expected={k:final.OIL[k]+(final.FLASK if k=='haste_rating' else 0) for k in STATS}
    need(b['buffed_minus_gear']==both_expected,'NATIVE_FLASK_OIL_DELTA_MISMATCH')
    need(receipt['oil_probe']['oil_only']['observed']['gear_secondary']==gear,'RECEIPT_NATIVE_MISMATCH')
    need(receipt['oil_probe']['flask_and_oil']['observed']['gear_secondary']==gear,'RECEIPT_NATIVE_MISMATCH')
    # Native factual authority is deliberately scoped to this SimC build, item IDs, level and slot configuration.
    nominal=None
    if nominal_snapshot is not None:
        slot_budgets=nominal_snapshot['levels'][str(level)]['TWO_HAND']['slot_budgets']
        nominal={'source':'WEQUIP_SCALED_NOMINAL_NONAUTHORITATIVE',
                 'expected_total':sum(slot_budgets.values()),'per_slot':dict(slot_budgets)}
    details=[]
    for row in oil_slots:
        ref=nominal['per_slot'].get(row['slot']) if nominal else None
        details.append({**row,'wequip_nominal_comparison_only':ref,
                        'native_minus_nominal':row['native_secondary_total']-ref if ref is not None else None,
                        'authoritative_source':'SIMC_JSON2_NATIVE'})
    gtotal=sum(gear.values())
    return {'schema':'SIMC_NATIVE_CHMV_AUTHORITY_v023','status':'SIMC_NATIVE_334_PROFILE_AUTHORITY_PASS',
            'precedence':['SIMC_JSON2_NATIVE_PER_ITEM_ILEVEL','SIMC_NATIVE_ITEM_SCALING_WHEN_INDEPENDENTLY_OBSERVED',
                          'WEQUIP_SEASON_ELIGIBILITY_ONLY'],
            'simc_version':'12.1.5.70448','simc_git_revision':'7bc1071',
            'covered_levels':[level],'covered_weapon_styles':['TWO_HAND'],
            'coverage':'OBSERVED_SELECTED_ARCANE_PROFILE_15_SLOTS_ONLY',
            'native_gear_secondary_excluding_trinkets':gear,'native_gear_rating_total':gtotal,
            'native_oil_fixed':dict(final.OIL),'native_flask_fixed':{'crit_rating':0,'haste_rating':165,'mastery_rating':0,'versatility_rating':0},
            'native_flask_oil_applied':b['buffed_rating'],
            'general_gems_budget_unapplied':138,'provisional_target_including_six_gems':gtotal+165+32+138,
            'gear_slot_details':details,'wequip_reference':nominal,
            'actual_six_gems_verified':False,'four_piece_effect_verified':False,
            'simc_chmv_candidate_injection_verified':False,'new_simc_runs':0,
            'season_wide_itemlevel_budget_authority':False,
            'warnings':['Never promote WEQUIP nominal counts as actual SimC stats or fill unobserved levels from them.',
                        'No 321/331 or non-TWO_HAND native standard profile coverage is established here.',
                        'Only native gear, oil and flask were observed; six gems and exact CHMV candidate injection remain pending.']}


def resolve_gear_budget(rec,level,style,master_nominal=None):
    """No nominal fallback. Missing native coverage must block exact scenario readiness."""
    if level not in rec['covered_levels'] or style not in rec['covered_weapon_styles']:
        raise ValueError('SIMC_NATIVE_BUDGET_COVERAGE_REQUIRED')
    need(rec['status']=='SIMC_NATIVE_334_PROFILE_AUTHORITY_PASS','SIMC_AUTHORITY_NOT_READY')
    return {'gear':rec['native_gear_rating_total'],'source':'SIMC_JSON2_NATIVE',
            'level':level,'style':style,'master_nominal_ignored_for_authority':master_nominal is not None}


def produce(output_root=ROOT/'V023_OUTPUTS'):
    receipt,oil,both=read_v022()
    master=budget.load_master()
    nominal=budget.make_budget_snapshot(master)
    rec=authority_record(receipt,oil,both,nominal)
    selected=resolve_gear_budget(rec,334,'TWO_HAND',master_nominal=nominal)
    plan=final.plan_from_budget(selected['gear'])
    need(plan['final_applied_total']==rec['provisional_target_including_six_gems'],'V022_PLAN_NATIVE_TOTAL_MISMATCH')
    rec['v022_candidate_plan_source']='SIMC_NATIVE_JSON2_334_SELECTED_PROFILE'
    rec['v022_seed_count']=plan['candidate_count']
    rec['evidence_sha256']=digest(EVIDENCE)
    out=Path(output_root).resolve()/('RUN_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ_')+uuid.uuid4().hex[:8])
    out.mkdir(parents=True,exist_ok=False)
    (out/'SIMC_NATIVE_AUTHORITY_RECEIPT_v023.json').write_text(json.dumps(rec,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    with (out/'NATIVE_PER_SLOT_VS_WEQUIP_NOMINAL_v023.csv').open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.writer(f);w.writerow(['slot','item_id','ilevel','simc_native_secondary','wequip_nominal_reference','native_minus_nominal','authoritative_source','excluded_from_free_gear_budget'])
        for s in rec['gear_slot_details']:
            w.writerow([s['slot'],s['item_id'],s['ilevel'],s['native_secondary_total'],s['wequip_nominal_comparison_only'],s['native_minus_nominal'],s['authoritative_source'],s['excluded_from_redistributable_gear_budget']])
    zipout=out/'SIMC_NATIVE_AUTHORITY_RESULTS_v023.zip'
    with zipfile.ZipFile(zipout,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(out.iterdir()):
            if p.is_file() and p!=zipout:z.write(p,p.name)
    with zipfile.ZipFile(zipout) as z:need(z.testzip() is None,'OUTPUT_CRC_ERROR')
    print('[PASS] SIMC_NATIVE_AUTHORITY_V023')
    print('[NATIVE] 334 TWO_HAND',rec['native_gear_rating_total'])
    print('[NOMINAL_REFERENCE_ONLY]',rec['wequip_reference']['expected_total'])
    print('[CONFIRMED] OIL +16 crit / +16 haste; FLASK +165 haste')
    print('[UNVERIFIED] actual gems, four-piece, other levels, CHMV injection')
    print('[RESULT_ZIP]',zipout)
    print('[OUTPUT_FOLDER]',out)
    try:
        if os.name=='nt':os.startfile(str(out))
    except (OSError,AttributeError):pass
    return rec,zipout


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--output-root',default=str(ROOT/'V023_OUTPUTS'))
    args=ap.parse_args()
    try:produce(args.output_root);return 0
    except (OSError,ValueError,KeyError,TypeError,IndexError,zipfile.BadZipFile) as e:
        print('[FAIL]',type(e).__name__,str(e));return 2

if __name__=='__main__':sys.exit(main())
