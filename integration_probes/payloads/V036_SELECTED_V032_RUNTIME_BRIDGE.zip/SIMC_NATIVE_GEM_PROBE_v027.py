#!/usr/bin/env python3
"""v027: bounded native gem socket / final CHMV evidence probe.

Four 1-iteration runs: two real gem choices, each with and without gear_*.
Native effects remain SimC-owned. Four-color crit-damage bonus is NOT inferred
from arithmetic, a short DPS sample, or merely seeing the item in a profile.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import re
import subprocess
import sys
import uuid
import zipfile

import CHMV_GEAR_OVERRIDE_CALIBRATION_v026 as v026
import CHMV_FIXED_FLOOR_INJECTION_v025 as v025
import GEM_SELECTION_v024 as gems
import SIMC_STAT_ATTRIBUTION_v021 as stat

ROOT=Path(__file__).resolve().parent
EVIDENCE=ROOT/'EVIDENCE_V027_INPUTS'/'GEAR_OVERRIDE_CALIBRATION_RESULTS_v026_USER_PC.zip'
EXPECTED_EVIDENCE_SHA='c308cedd167316ae78755539ce7217057a07c611e1bd4746ce86167663462b0a'
OLD_V022=ROOT/'EVIDENCE_V023_INPUTS'/'FINAL_APPLIED_CHMV_RESULTS_v022_USER_PC.zip'
REGULAR=(240908,240892,240918,240900,240908,240892)
# Demonstration sockets, not proven in-game socket eligibility for these sample items.
SLOTS=('head','neck','wrists','waist','finger1','finger2')
# Exact 7 gems: 1 meta, 6 two-stat gems.
LAYOUT={'head':('SPECIAL',),'neck':(REGULAR[0],),
        'wrists':(REGULAR[1],),'waist':(REGULAR[2],),
        'finger1':(REGULAR[3],REGULAR[4]),'finger2':(REGULAR[5],)}
CHOICES={'primary32':'PRIMARY_32','primary23_four_colors':'PRIMARY_23_CRIT_DAMAGE_UP_TO_0_6'}
CASES=('raw_primary32','raw_primary23_four_colors','override_primary32','override_primary23_four_colors')
TARGET={'crit_rating':940,'haste_rating':1040,'mastery_rating':873,'versatility_rating':329}
FLASK_NATIVE={k:(165 if k=='haste_rating' else 0) for k in stat.STATS}
OVERRIDES=v025.gear_override_for_final(TARGET,FLASK_NATIVE)


def need(ok,code):
    if not ok:raise ValueError(code)


def verified_evidence():
    need(EVIDENCE.is_file() and stat.sha_file(EVIDENCE)==EXPECTED_EVIDENCE_SHA,'V026_NATIVE_RESULT_SHA_MISMATCH')
    with zipfile.ZipFile(EVIDENCE) as z:
        need(z.testzip() is None,'V026_BAD_CRC')
        receipt=json.loads(z.read('GEAR_OVERRIDE_CALIBRATION_RECEIPT_v026.json'))
        doc=json.loads(z.read('corrected_flask_oil.json'))
        profile=z.read('corrected_flask_oil.simc').decode('utf-8-sig')
    need(receipt['status']=='CORRECTED_SINGLE_PROBE_PASS','V026_NOT_A_PASS')
    need(receipt['simc_native_probe']['all_stats_exact'] is True,'V026_STAT_MATCH_NOT_PROVEN')
    need(v026.judge(doc,stat.snapshot(doc)['gear_secondary'])['all_stats_exact'],'V026_SNAPSHOT_INVALID')
    need(stat.snapshot(doc)['buffed_rating']==v026.TARGET,'V026_NATIVE_DATA_CONFLICT')
    need('temporary_enchant=main_hand:thalassian_phoenix_oil_2' in profile,'OIL_MISSING')
    need('flask=flask_of_the_blood_knights_2' in profile,'FLASK_MISSING')
    with zipfile.ZipFile(OLD_V022) as z:
        need(z.testzip() is None,'V022_BAD_CRC')
        untreated=json.loads(z.read('flask_and_oil.json'))
    raw_original=stat.snapshot(untreated)
    need(raw_original['buffed_rating']=={'crit_rating':808,'haste_rating':1101,'mastery_rating':822,'versatility_rating':313},'V022_RAW_BASE_CHANGED')
    need(raw_original['gear_secondary']==stat.snapshot(doc)['gear_secondary'],'PINNED_ITEMS_NOT_IDENTICAL')
    return profile,raw_original,receipt


def config(choice):
    cfg={'schema':'MidnightGemSelection-v024','special_gem_choice':CHOICES[choice],
         'regular_gem_item_ids':list(REGULAR)}
    selected=gems.select(cfg)
    need(selected['regular_gem_loadout']['total_secondary_rating']==138,'GEM_BUDGET_INVALID')
    need(selected['regular_gem_loadout']['distinct_color_count']==4,'FOUR_COLORS_NOT_REALIZED')
    return selected


def ids_for_slot(slot,choice):
    vals=LAYOUT[slot]
    selected_id=gems.SPECIALS[CHOICES[choice]]['item_id']
    return tuple(selected_id if v=='SPECIAL' else v for v in vals)


def make_profile(base_profile,out_json,case):
    need(case in CASES,'UNKNOWN_PROBE_CASE')
    overlaid=case.startswith('override_')
    choice='primary32' if case.endswith('primary32') else 'primary23_four_colors'
    selected=config(choice)
    lines=[];seen=set()
    for line in base_profile.splitlines():
        if line.startswith('json2=') or re.match(r'^gear_(crit|haste|mastery|versatility)_rating=',line):continue
        m=re.match(r'^(head|neck|wrists|waist|finger1|finger2)=(.*)$',line)
        if m:
            slot,item=m.groups()
            need(slot not in seen,'DUPLICATE_ITEM_SLOT:'+slot);seen.add(slot)
            need('gem_id=' not in item and 'gems=' not in item,'EXISTING_GEMS_NEED_EXPLICIT_ACCOUNTING')
            ids=ids_for_slot(slot,choice)
            need(all(type(i) is int and i>0 for i in ids),'INVALID_GEM_ID')
            line+=',gem_id='+'/'.join(str(i) for i in ids)
        lines.append(line)
    need(seen==set(SLOTS),'MISSING_SOCKET_HOST_ITEM')
    need(sum(len(ids_for_slot(slot,choice)) for slot in SLOTS)==7,'MISSING_GEM')
    need(sum(gems.CATALOG[i][0] in gems.COLORS for i in REGULAR)==6,'UNKNOWN_GEM_COLOR')
    if overlaid:lines.extend(f'{k}={v}' for k,v in OVERRIDES.items())
    lines.append('json2='+str(Path(out_json).resolve()))
    rendered='\n'.join(lines)+'\n'
    need(rendered.count('temporary_enchant=main_hand:thalassian_phoenix_oil_2')==1,'OIL_DROPPED')
    need(rendered.count('flask=flask_of_the_blood_knights_2')==1,'FLASK_DROPPED')
    need('food=disabled' in rendered and 'potion=disabled' in rendered,'CONSUMABLE_CONTAMINATION')
    need('iterations=1' in rendered and 'max_time=5' in rendered,'UNBOUNDED_SIMULATION')
    need('item_db_source=local' in rendered,'LOCAL_NATIVE_REQUIRED')
    return rendered,selected


def parse_gem_ids(gear):
    found={}
    for slot in SLOTS:
        encoded=gear.get(slot,{}).get('encoded_item','')
        m=re.search(r'(?:^|,)gem_id=([0-9/]+)(?:,|$)',encoded)
        found[slot]=[int(x) for x in m.group(1).split('/')] if m else []
    return found


def examine(doc,case,reference,raw_original):
    snap=stat.snapshot(doc)
    need(snap['simc_git_revision']=='7bc1071','SIMC_REVISION_UNEXPECTED')
    need(snap['simc_build']=='12.1.5.70448','SIMC_GAME_BUILD_UNEXPECTED')
    need(snap['item_identity']==reference['item_identity'],'BASE_ITEM_ID_LEVEL_CHANGED')
    need(snap['flask']=='flask_of_the_blood_knights_2','FLASK_CONFIG_LOST')
    need('thalassian_phoenix_oil' in str(snap['temporary_enchant']),'OIL_CONFIG_LOST')
    choice='primary32' if case.endswith('primary32') else 'primary23_four_colors'
    expected_ids={slot:list(ids_for_slot(slot,choice)) for slot in SLOTS}
    observed_ids=parse_gem_ids(doc['sim']['players'][0]['gear'])
    recognized=observed_ids==expected_ids
    present=[i for row in observed_ids.values() for i in row]
    observed_primary=doc['sim']['players'][0]['collected_data']['buffed_stats']['attribute'].get('intellect')
    buff=snap['buffed_rating']
    expected_raw={k:raw_original['buffed_rating'][k]+config(choice)['regular_gem_loadout']['by_stat'][k] for k in stat.STATS}
    is_override=case.startswith('override_')
    target=TARGET if is_override else expected_raw
    rating_exact=buff==target
    return {'simc_gem_ids_encoded':observed_ids,'requested_gem_ids':expected_ids,
            'gem_ids_encoded_exact':recognized,'recognized_gem_count':len(present),
            'expected_final':target,'observed_final':buff,
            'final_chmv_exact':rating_exact,'original_item_identity_same':True,
            'observed_native_gear_rating':snap['gear_secondary'],
            'observed_buffed_intellect':observed_primary,
            'is_gear_override_case':is_override,
            'crit_damage_0_6_effect_active_proven':False,
            'no_direct_crit_damage_effect_evidence':True,
            'note':'Item echo and CHMV equality do not independently prove special gem critical-damage bonus.'}


def run_cases(executable,base_profile,raw_original,reference,out):
    exe=Path(executable).resolve()
    need(exe.is_file(),'SIMC_BINARY_NOT_FOUND')
    need(stat.sha_file(exe)==stat.BINARY_SHA,'SIMC_BINARY_HASH_MISMATCH')
    results={}
    for case in CASES:
        jp=out/(case+'.json');sp=out/(case+'.simc')
        profile,_=make_profile(base_profile,jp,case)
        sp.write_text(profile,encoding='utf-8')
        rec={'exit_code':None,'json_created':False,'pass':False,'reason':None}
        try:
            proc=subprocess.run([str(exe),str(sp)],capture_output=True,text=True,
                                encoding='utf-8',errors='replace',timeout=90)
            rec['exit_code']=proc.returncode;stdout=proc.stdout;stderr=proc.stderr
        except subprocess.TimeoutExpired as e:
            rec['reason']='SIMC_TIMEOUT';stdout=str(e.stdout or '');stderr=str(e.stderr or '')
        (out/(case+'_stdout.txt')).write_text(stdout,encoding='utf-8')
        (out/(case+'_stderr.txt')).write_text(stderr,encoding='utf-8')
        rec['json_created']=jp.is_file()
        if rec['exit_code']==0 and rec['json_created']:
            try:
                observed=examine(json.loads(jp.read_text(encoding='utf-8-sig')),case,reference,raw_original)
                rec['observed']=observed
                rec['pass']=observed['gem_ids_encoded_exact'] and observed['final_chmv_exact']
                if not rec['pass']:rec['reason']='GEM_ID_OR_STAT_MISMATCH'
            except (OSError,KeyError,ValueError,TypeError,IndexError) as e:
                rec['reason']=type(e).__name__+':'+str(e)
        elif rec['reason'] is None:rec['reason']='SIMC_EXIT_OR_JSON2_MISSING'
        results[case]=rec
    return results


def main(argv=None):
    parser=argparse.ArgumentParser(description='v027 native gem socketing & CHMV overlay probe')
    parser.add_argument('--mode',choices=('inspect','local-probe'),default='inspect')
    parser.add_argument('--simc-executable',default=None)
    parser.add_argument('--output-root',default=str(ROOT/'V027_OUTPUTS'))
    args=parser.parse_args(argv)
    try:
        base,raw,previous=verified_evidence()
        baseline=json.loads(zipfile.ZipFile(EVIDENCE).read('corrected_flask_oil.json'))
        reference=stat.snapshot(baseline)
        dest=Path(args.output_root).resolve()/('RUN_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ_')+uuid.uuid4().hex[:8])
        dest.mkdir(parents=True,exist_ok=False)
        # Even offline mode emits the exact generated SIMC inputs, with actual output paths.
        for case in CASES:
            jp=dest/(case+'.json');sp=dest/(case+'.simc')
            s,selected=make_profile(base,jp,case)
            sp.write_text(s,encoding='utf-8')
        cases=run_cases(args.simc_executable,base,raw,reference,dest) if args.mode=='local-probe' else None
        allpass=(cases is not None and all(rec['pass'] for rec in cases.values()))
        observed_diff=None
        if cases is not None:
            p32=cases['raw_primary32'].get('observed',{}).get('observed_buffed_intellect')
            p23=cases['raw_primary23_four_colors'].get('observed',{}).get('observed_buffed_intellect')
            if p32 is not None and p23 is not None:observed_diff=p32-p23
        report={'schema':'SIMCSecondaryGemNativeProbe-v027',
                'status':'OFFLINE_INPUTS_ONLY' if cases is None else ('NATIVE_GEM_STAT_PROBES_PASS' if allpass else 'NATIVE_GEM_PROBES_REQUIRE_REVIEW'),
                'native_simc_runs':0 if cases is None else 4,
                'evidence_v026_sha256':EXPECTED_EVIDENCE_SHA,
                'prior_v026_status':previous['status'],
                'simc_git_revision_expected':'7bc1071',
                'general_gems':list(REGULAR),
                'per_regular_gem_rating':23,
                'regular_gem_total_rating':138,
                'distinct_gem_colors':config('primary23_four_colors')['regular_gem_loadout']['colors'],
                'special_choices':{c:gems.SPECIALS[v]['item_id'] for c,v in CHOICES.items()},
                'socket_host_slots':{slot:('SPECIAL' if slot=='head' else list(LAYOUT[slot])) for slot in SLOTS},
                'socket_host_eligibility_in_game_verified':False,
                'gear_override_final_target':TARGET,
                'gear_override_values':OVERRIDES,
                'raw_no_gem_native_baseline':raw['buffed_rating'],
                'results':cases,
                'observed_primary32_minus_primary23_intellect':observed_diff,
                'primary_stat_nominal_difference_expected':9,
                'native_crit_damage_bonus_effect_verified':False,
                'native_four_piece_effect_verified':False,
                'optimizer_ready':False,
                'notes':['This probe is low-iteration stat/ItemID diagnostic, never a meaningful DPS benchmark.',
                         'The special primary+23 four-color bonus is CRITICAL DAMAGE / effectiveness, not critical strike rating.',
                         'SimC must calculate the special effect; this script must never multiply DPS by 0.6%.',
                         'Gem socket eligibility, meta effect and tier bonus still require independent evidence.',
                         'Only six regular gem secondary ratings are abstractly redistributable; none is pinned as a CHMV floor.',
                         'Failed native gem reads remain failed rather than using manual rating compensation.']}
        (dest/'GEM_NATIVE_PROBE_RECEIPT_v027.json').write_text(json.dumps(report,ensure_ascii=False,indent=2,sort_keys=True)+'\n',encoding='utf-8')
        resultzip=dest/'GEM_NATIVE_PROBE_RESULTS_v027.zip'
        with zipfile.ZipFile(resultzip,'w',zipfile.ZIP_DEFLATED) as z:
            for p in sorted(dest.iterdir()):
                if p.is_file() and p!=resultzip:z.write(p,p.name)
        with zipfile.ZipFile(resultzip) as z:need(z.testzip() is None,'INVALID_RESULT_ZIP')
        print('[RESULT]',report['status'])
        print('[RAW_EXPECTED_CHMV]',{k:raw['buffed_rating'][k]+config('primary32')['regular_gem_loadout']['by_stat'][k] for k in stat.STATS})
        print('[OVERRIDE_FINAL_CHMV]',TARGET)
        print('[SPECIAL_PRIMARY_DELTA]',observed_diff,'NOT_CRIT_DAMAGE_PROOF')
        print('[RESULT_ZIP]',resultzip)
        print('[OUTPUT_FOLDER]',dest)
        try:
            if os.name=='nt':os.startfile(str(dest))
        except (OSError,AttributeError):pass
        return 0 if cases is None or allpass else 2
    except (OSError,ValueError,KeyError,TypeError,zipfile.BadZipFile) as e:
        print('[FAIL]',type(e).__name__,str(e));return 2

if __name__=='__main__':sys.exit(main())
