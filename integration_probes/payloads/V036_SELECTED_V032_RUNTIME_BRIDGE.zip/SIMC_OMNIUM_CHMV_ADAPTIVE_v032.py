#!/usr/bin/env python3
"""v032 user-selectable Omnium row-4 + bounded real native CHMV DPS exploration.

Runtime input uses the v031R3 user-tested equipment/food/embellishment profile.
Keep one Omnium rune fixed for the whole run. No four-rune optimization.
This is a pilot, NOT an optimization-convergence or global-optimum claim.
"""
from __future__ import annotations
import argparse
import datetime as dt
import hashlib
import json
import math
import os
from pathlib import Path
import re
import statistics
import subprocess
import sys
import uuid
import zipfile

import SIMC_EMBELLISH_ENCHANT_v031R3 as r3
import CHMV_TRINKET_GUIDED_SEARCH_v030 as model

HERE=Path(__file__).resolve().parent
STATS=r3.STAT_KEYS
TOTAL=3184
STATIC_GEAR=2849
OIL=(16,16,0,0)
FLASK=165
SCOUTS=6
CONFIRMS=2
RUNE_IDS={'crit':136815,'haste':136821,'mastery':136820,'versatility':136818}
RUNE_NAMES={'crit':'Rune of Critical Power','haste':'Rune of Burning Haste',
            'mastery':'Rune of Masterful Cunning','versatility':'Rune of the Versatile Warrior'}
RUNE_BUFF_TOKEN={'crit':'rune_of_critical_power','haste':'rune_of_burning_haste',
                 'mastery':'rune_of_masterful_cunning','versatility':'rune_of_the_versatile_warrior'}
OMNIUM_BASE=(136822,136817,136814)
OLD_OMNIUM='136822:1/136817:1/136821:1/136814:1'
FLASKS={
 'crit': 'flask_of_the_shattered_sun_2',
 'haste':'flask_of_the_blood_knights_2',
 'mastery':'flask_of_the_magisters_2',
 'versatility':'flask_of_thalassian_resistance_2',
}
EVIDENCE=HERE/'EVIDENCE_V032_INPUTS'/'EMBELLISH_ENCHANT_RESULTS_v031R3_USER_PC.zip'
# A separate test verifies this archived evidence's SHA against the shipped pinned value.
EVIDENCE_SHA='a84b9c806da8029396b3ab7952f01a5f897cc8eaa3bd919651cc50b4ec9a96f6'

class Refuse(ValueError): pass

def need(ok,msg):
    if not ok:raise Refuse(msg)

def sha_bytes(value):return hashlib.sha256(value).hexdigest()

def native_source(*,rune='crit',gem_choice='primary23_four_colors'):
    need(rune in RUNE_IDS,'INVALID_OMNIUM_RUNE')
    s=r3.source_profile(gem_choice)
    old='omnium_talents='+OLD_OMNIUM
    need(s.splitlines().count(old)==1,'UNEXPECTED_OMNIUM_SOURCE')
    new='omnium_talents='+('/'.join(f'{i}:1' for i in
             (OMNIUM_BASE[0],OMNIUM_BASE[1],RUNE_IDS[rune],OMNIUM_BASE[2])))
    s=s.replace(old,new,1)
    need(s.splitlines().count(new)==1 and s.count('omnium_talents=')==1,'OMNIUM_SELECTION_NOT_UNIQUE')
    for other,rid in RUNE_IDS.items():
        if other!=rune:need(f'{rid}:1' not in new,'MORE_THAN_ONE_ROW4_RUNE')
    return s

def load_calibration_evidence():
    need(EVIDENCE.is_file(),'MISSING_V031R3_NATIVE_EVIDENCE')
    raw=EVIDENCE.read_bytes()
    need(sha_bytes(raw)==EVIDENCE_SHA,'V031R3_EVIDENCE_SHA_MISMATCH')
    with zipfile.ZipFile(EVIDENCE) as z:
        need(z.testzip() is None,'V031R3_EVIDENCE_CRC_FAILURE')
        receipt=json.loads(z.read('EMBELLISH_ENCHANT_RECEIPT_v031R3.json'))
        need(receipt['status']=='PASS_V031R2_PRIMARY_FOOD_NATIVE_DPS','V031R3_NOT_SUCCESSFUL')
        need(receipt['calibration']['native_gear_total']==STATIC_GEAR,'NATIVE_GEAR_NOT_2849')
        need(receipt['calibration']['corrected_total_chmv']==TOTAL,'NATIVE_BUDGET_NOT_3184')
        baseline=z.read('CALIBRATE_NATIVE/input.simc').decode('utf-8-sig').replace('\r\n','\n')
        dps_doc=json.loads(z.read('DPS_NATIVE/result.json'))
        # The actual SimC result is evidence, rather than the receipt alone.
        need(sum(r3.item_sum_native(dps_doc['sim']['players'][0]).values())==STATIC_GEAR,
             'V031R3_NATIVE_JSON2_DISAGREES')
        need(dps_doc['sim']['players'][0]['talents']==r3.DEFAULT_TALENTS,'USER_TALENTS_EVIDENCE_MISMATCH')
        need(dps_doc['sim']['players'][0]['race']=='dwarf','USER_RACE_EVIDENCE_MISMATCH')
        need('omnium_talents='+OLD_OMNIUM in baseline,'PREVIOUS_OMNIUM_BASE_MISSING')
        for name in ('primary23_four_colors','primary32'):
            wanted=native_source(rune='haste',gem_choice=name)
            # The source of the R3 real run is the primary23 build.
            if name=='primary23_four_colors':
                for oldrow in baseline.splitlines():
                    key=oldrow.partition('=')[0]
                    if key in (*r3.TIER.keys(),*r3.CRAFT.keys(),*r3.TRINKETS.keys(),
                               'race','talents','omnium_talents','food'):
                        need(oldrow in wanted.splitlines(),'SOURCE_GEAR_OR_SETTINGS_DRIFT:'+key)
        return {'native_static_gear_chmv':STATIC_GEAR,'final_total':TOTAL,
                'sha256':EVIDENCE_SHA,'source':'v031R3 user-native JSON2'}

def valid(vec, locked=(0,0,0,0)):
    return (isinstance(vec,tuple) and len(vec)==4 and len(locked)==4 and
            all(type(x)==int for x in vec+tuple(locked)) and sum(vec)==TOTAL and
            all(v>=o+l and v<=TOTAL//2 for v,o,l in zip(vec,OIL,locked)))

def seeds():
    base=(600,1140,1115,329)
    need(valid(base),'BASELINE_INVALID')
    vals=[base]
    focus=round(TOTAL*0.43);low=(TOTAL-focus)//3
    for i in range(4):
        candidate=[low]*4;candidate[i]=focus
        candidate[(i+1)%4]+=TOTAL-sum(candidate)
        v=tuple(candidate)
        need(valid(v),'INVALID_FOUR_STAT_SEED')
        need(v not in vals,'DUPLICATE_FOUR_STAT_SEED')
        vals.append(v)
    return vals

def select_flask(vec):
    need(valid(vec),'BAD_VECTOR')
    # Deterministic, avoids creating a fake haste floor from the reference flask.
    i=max(range(4),key=lambda ix:(vec[ix],-ix))
    need(vec[i]>=FLASK,'NO_VALID_NATIVE_FLASK')
    return i,FLASKS[('crit','haste','mastery','versatility')[i]]

def make_profile(source,output,vec,iterations):
    need(valid(vec),'INVALID_CANDIDATE_OR_FIXED_OIL_FLOOR')
    need(type(iterations)==int and 60<=iterations<=1000,'ITERATIONS_OUT_OF_BOUNDS')
    # Reuse old verified profile generator's settings/SimC item layout; remove
    # its reference vector and replace every injected rating with our candidate.
    text,_=r3.input_profile(source,output,kind='dps',total=TOTAL,iterations=iterations)
    flask_i,flask_token=select_flask(vec)
    lines=[];seen=set()
    for line in text.splitlines():
        key,eq,_=line.partition('=')
        if key=='flask':
            need('flask' not in seen,'DUPLICATE_FLASK')
            line='flask='+flask_token;seen.add('flask')
        if key in ('gear_'+s for s in STATS):
            need(key not in seen,'DUPLICATE_GEAR_OPTION')
            j=STATS.index(key[5:]);rating=vec[j]-(FLASK if j==flask_i else 0)
            need(rating>=0,'NEGATIVE_GEAR_INJECTION')
            line=key+'='+str(rating);seen.add(key)
        lines.append(line)
    need(seen=={'flask',*('gear_'+s for s in STATS)},'INCOMPLETE_NATIVE_OVERRIDE')
    need(sum(int(x.split('=',1)[1]) for x in lines if x.startswith('gear_'))+FLASK==TOTAL,
         'GEAR_FLASK_TOTAL_MISMATCH')
    need(any(x.startswith('omnium_talents=') for x in lines),'NO_OMNIUM_IN_INPUT')
    need(sum('embellishment=arcanoweave_lining' in x for x in lines)==2,'LOST_TWO_LININGS')
    need(any(x=='food=royal_roast' for x in lines),'LOST_PRIMARY_FOOD')
    return '\n'.join(lines)+'\n',{'flask_stat':STATS[flask_i],
                    'flask_token':flask_token,'target':dict(zip(STATS,vec))}

def choose_guided(scouts,step=200):
    need(len(scouts)>=5,'TOO_FEW_SCOUTS')
    # Reuse v030 numeric ridge fitting, but explicitly apply *current* budget
    # and constraints rather than old v030's hard-coded TOTAL=3182.
    raw=[tuple(int(rec['target'][k]) for k in STATS) for rec in scouts]
    need(len(set(raw))>=5,'SCOUTS_NOT_DIVERSE')
    sems=[max(1,float(rec['sem'])) for rec in scouts]
    mid=statistics.median(sems)
    base=seeds()[0]
    xx=[[1.0]+[(v[i]-base[i])/500 for i in range(3)] for v in raw]
    yy=[rec['dps'] for rec in scouts]
    ww=[max(0.25,min(4,(mid/x)**2)) for x in sems]
    lhs=[[sum(w*x[i]*x[j] for w,x in zip(ww,xx))+(0.6 if i==j and i!=0 else 0)
          for j in range(4)] for i in range(4)]
    rhs=[sum(w*x[i]*y for w,x,y in zip(ww,xx,yy)) for i in range(4)]
    beta=model._linear_solve(lhs,rhs)
    def estimate(v):return beta[0]+sum(beta[i+1]*(v[i]-base[i])/500 for i in range(3))
    seen=set(raw);ranked=sorted(scouts,key=lambda r:(-r['dps'],tuple(r['target'][k] for k in STATS)))
    offers=[]
    for rank,rec in enumerate(ranked[:3]):
        anchor=tuple(rec['target'][k] for k in STATS)
        for i in range(4):
            for j in range(4):
                if i==j:continue
                v=list(anchor);v[i]-=step;v[j]+=step;v=tuple(v)
                if not valid(v) or v in seen:continue
                gain=estimate(v)-estimate(anchor)
                novelty=min(sum(abs(v[k]-s[k]) for k in range(4))/2 for s in seen)
                score=gain+0.15*mid*novelty/TOTAL-rank*0.08*mid
                offers.append((score,gain,novelty,-rank,v,anchor))
    need(offers,'NO_ELIGIBLE_GUIDED_CANDIDATE')
    selected=max(offers,key=lambda x:(x[0],x[2],x[1],tuple(-v for v in x[4])))
    return selected[4],{'model':'V030_WEIGHTED_3DOF_RIDGE_ADAPTED_TO_CURRENT_TOTAL',
        'stat_direction_only_not_statistically_proven':True,'anchor':selected[5],
        'candidate':selected[4],'estimated_gain_for_experiment_order_only':round(selected[1],2)}

def confirm_seeds(scouts):
    need(len(scouts)>=2,'TOO_FEW_CONFIRMS')
    order=sorted(scouts,key=lambda r:-r['dps'])
    first=order[0];a=tuple(first['target'][k] for k in STATS)
    for alt in order[1:]:
        b=tuple(alt['target'][k] for k in STATS)
        distance=sum(abs(x-y) for x,y in zip(a,b))/2
        bound=1.96*math.hypot(first['sem'],alt['sem'])
        if distance>=250 and first['dps']-alt['dps']<=bound:
            return [a,b],{'selection':'DISTINCT_UNRESOLVED_CANDIDATE','rating_distance':distance}
    b=tuple(order[1]['target'][k] for k in STATS)
    return [a,b],{'selection':'TOP_TWO_OBSERVED_SCOUTS_NOT_PROVEN','rating_distance':sum(abs(x-y) for x,y in zip(a,b))/2}

def read_native_result(doc,vec,gem_choice,rune):
    target=dict(zip(STATS,vec))
    # Checks entire actual profile including tier, food, two crafted items,
    # embellishments, trinkets, enchants, 7 gems and final native CHMV.
    result=r3.native_check(doc,has_dps=True,total=TOTAL,target=target)
    need(sum(result['native_gear_static_chmv'].values())==STATIC_GEAR,'NATIVE_GEAR_BUDGET_DRIFT')
    buffs={b.get('name','') for b in doc['sim']['players'][0].get('buffs',[])}
    token=RUNE_BUFF_TOKEN[rune]
    # Unrecognized/unsupported rune never silently scores as a valid DPS pilot.
    # SimC's buff name can vary; retain raw list if we fail.
    need(token in buffs,'SELECTED_OMNIUM_RUNE_BUFF_NOT_VISIBLE:'+token)
    for other,other_token in RUNE_BUFF_TOKEN.items():
        if other!=rune:need(other_token not in buffs,'UNSELECTED_OMNIUM_RUNE_BUFF_PRESENT:'+other_token)
    dps=doc['sim']['players'][0]['collected_data']['dps']
    sem=float(dps.get('mean_std_dev',0))
    need(math.isfinite(sem) and sem>0,'DPS_STANDARD_ERROR_MISSING')
    return {'target':target,'dps':float(dps['mean']),'sem':sem,
            'ci95':1.96*sem,'samples':int(dps['count']),
            'actual_chmv':result['final_applied'],'rune_buff_visible':token,
            'warnings':result['warnings']}

def run_case(binary,folder,source,vec,iterations,rune):
    folder.mkdir(exist_ok=False,parents=True)
    result_file=folder/'result.json'
    content,info=make_profile(source,result_file,vec,iterations)
    (folder/'input.simc').write_text(content,encoding='utf-8')
    data={'status':'ATTEMPTED','rune':rune,'flask':info['flask_token'],
          'iterations':iterations,'requested_target':info['target'],
          'input_sha256':r3.sha(folder/'input.simc')}
    try:
        need(r3.sha(binary)==r3.EXPECTED_SIMC_SHA,'SIMC_BINARY_IDENTITY_CHANGED')
        with (folder/'stdout.txt').open('w',encoding='utf-8') as out,(folder/'stderr.txt').open('w',encoding='utf-8') as err:
            p=subprocess.run([str(binary),str(folder/'input.simc')],cwd=str(binary.parent),
                             stdin=subprocess.DEVNULL,stdout=out,stderr=err,timeout=900,check=False)
        data['exit_code']=p.returncode
        need(p.returncode==0,'SIMC_NATIVE_EXIT_'+str(p.returncode))
        need(result_file.is_file() and result_file.stat().st_size>1000,'MISSING_SIMC_JSON2')
        doc=json.loads(result_file.read_text(encoding='utf-8-sig'))
        data.update(read_native_result(doc,vec,'primary23_four_colors',rune))
        data['result_sha256']=r3.sha(result_file)
        data['status']='NATIVE_STATS_AND_RUNE_PASS'
    finally:
        r3.dump(folder/'CASE_RECEIPT_v032.json',data)
    return data

def archive_run(folder):
    archive=folder/'OMNIUM_CHMV_DPS_RESULTS_v032.zip'
    files=[p for p in sorted(folder.rglob('*')) if p.is_file() and p!=archive]
    r3.dump(folder/'FILE_INDEX_v032.json',{'items':[{'path':p.relative_to(folder).as_posix(),
        'size':p.stat().st_size,'sha256':r3.sha(p)} for p in files]})
    with zipfile.ZipFile(archive,'x',compression=zipfile.ZIP_DEFLATED,compresslevel=6) as z:
        for p in sorted(folder.rglob('*')):
            if p.is_file() and p!=archive:z.write(p,p.relative_to(folder).as_posix())
    with zipfile.ZipFile(archive) as z:need(z.testzip() is None,'OUTPUT_ZIP_CRC_FAIL')
    return archive

def main(argv=None):
    ap=argparse.ArgumentParser(description='v032 Omnium selected-4th-rune, native CHMV adaptive pilot')
    ap.add_argument('--mode',choices=('plan','local-probe'),default='plan')
    ap.add_argument('--rune',choices=tuple(RUNE_IDS),default='crit')
    ap.add_argument('--gem-choice',choices=('primary23_four_colors','primary32'),default='primary23_four_colors')
    ap.add_argument('--scout-iterations',type=int,default=120)
    ap.add_argument('--confirm-iterations',type=int,default=320)
    ap.add_argument('--simc-executable')
    ap.add_argument('--output-root',default=str(HERE/'V032_OUTPUTS'))
    args=ap.parse_args(argv)
    try:
        need(60<=args.scout_iterations<=600 and 150<=args.confirm_iterations<=1000
             and args.confirm_iterations>=args.scout_iterations,'ITERATION_LIMIT_INVALID')
        # v031R3 native observation was only for primary23. primary32 may change
        # CHMV source provenance even when nominal J is equal: strict default.
        need(args.gem_choice=='primary23_four_colors','V032_PRIMARY32_NEEDS_SEPARATE_NATIVE_CALIBRATION')
        proof=load_calibration_evidence()
        src=native_source(rune=args.rune,gem_choice=args.gem_choice)
        root=Path(args.output_root).resolve();root.mkdir(parents=True,exist_ok=True)
        folder=root/('RUN_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ_')+uuid.uuid4().hex[:8]);folder.mkdir()
        status='PENDING'
        report={'schema':'SIMCSecondaryOmniumNativeAdaptive-v032','status':status,
            'rune':args.rune,'rune_name':RUNE_NAMES[args.rune],
            'rune_id':RUNE_IDS[args.rune], 'omnium_talents':next(
                x.split('=',1)[1] for x in src.splitlines() if x.startswith('omnium_talents=')),
            'fixed_omnium_rows':list(OMNIUM_BASE),'one_rune_only':True,
            'native_budget_evidence':proof,'static_chmv_target_total':TOTAL,
            'equipment_signature':'V031R3_DWARF_4TIER_2LININGS_5ENCHANTS_ROYAL_ROAST_TWO_TRINKETS',
            'scout_requested':SCOUTS,'confirm_requested':CONFIRMS,
            'max_new_simc_calls':SCOUTS+CONFIRMS,'previous_rune_dps_reuse':False,
            'gem_choice':args.gem_choice,'old_haste_rune_dps_not_reused':True,
            'not_joint_rune_optimization':True,'not_global_optimum_proven':True,
            'native_runs_attempted':0,'native_runs_completed':0,'scouts':[],'confirmations':[]}
        try:
            choices=seeds()
            for i,v in enumerate(choices):
                text,info=make_profile(src,folder/f'PREVIEW_{i+1:02d}.json',v,args.scout_iterations)
                (folder/f'PREVIEW_{i+1:02d}.simc').write_text(text,encoding='utf-8')
            if args.mode=='plan':report['status']='OFFLINE_PLAN_PASS'
            else:
                need(bool(args.simc_executable),'SIMC_EXECUTABLE_REQUIRED')
                binary=Path(args.simc_executable).resolve();need(binary.is_file(),'SIMC_EXE_NOT_FOUND')
                need(r3.sha(binary)==r3.EXPECTED_SIMC_SHA,'SIMC_BINARY_SHA_MISMATCH')
                for i in range(SCOUTS):
                    vec=choices[i] if i<len(choices) else choose_guided(report['scouts'])[0]
                    if i==SCOUTS-1:report['guided_rationale']=choose_guided(report['scouts'])[1]
                    tag=f'SCOUT_{i+1:02d}'
                    print('[SIMC]',tag,vec,'rune=',args.rune,flush=True)
                    report['native_runs_attempted']+=1
                    record=run_case(binary,folder/tag,src,vec,args.scout_iterations,args.rune)
                    report['scouts'].append(record)
                    report['native_runs_completed']+=1
                    r3.dump(folder/'PROGRESS_v032.json',report)
                confirm,selection=confirm_seeds(report['scouts']);report['confirmation_selection']=selection
                for i,v in enumerate(confirm):
                    tag=f'CONFIRM_{i+1:02d}'
                    print('[SIMC]',tag,v,'rune=',args.rune,flush=True)
                    report['native_runs_attempted']+=1
                    record=run_case(binary,folder/tag,src,v,args.confirm_iterations,args.rune)
                    report['confirmations'].append(record)
                    report['native_runs_completed']+=1
                    r3.dump(folder/'PROGRESS_v032.json',report)
                first,second=report['confirmations']
                error=1.96*math.hypot(first['sem'],second['sem'])
                report['comparison']={'observed_difference_dps':first['dps']-second['dps'],
                    'difference_95pct_halfwidth_approx':error,
                    'statistically_separated_95pct_approx':abs(first['dps']-second['dps'])>error,
                    'not_best_global_dps_proof':True}
                report['status']='PASS_BOUNDED_OMNIUM_NATIVE_DPS'
        except (Exception,KeyboardInterrupt) as e:
            report['status']='PARTIAL_OR_BLOCKED'
            report['error']=type(e).__name__+':'+str(e)
        r3.dump(folder/'OMNIUM_CHMV_RECEIPT_v032.json',report)
        lines=['SIMC SECONDARY OPTIMIZER v032 - Omnium 4열 사용자선택 및 실제 DPS','',
             '상태: '+report['status'], '룬: '+RUNE_NAMES[args.rune]+' ('+str(RUNE_IDS[args.rune])+')',
             '총량: 3184 (이전 v031R3 사용자 실측 재사용)',
             '전투: Patchwerk 1대상 300초, 레이드 버프 및 시작 블러드',
             '장비: Dwarf/사용자 특성/4T/Arcanoweave 2개/마법부여/음식/334 장신구 2개',
             '옴니움은 총량 및 고정 하한에 추가하지 않고 SimC 전투 효과로 계산',
             '4가지 룬 공동 탐색 아님. 최적해 보증 아님.']
        for label,kind in [('탐색','scouts'),('독립 재시험','confirmations')]:
            for rec in report[kind]:lines.append(label+' '+str(rec['target'])+' DPS '+str(round(rec['dps'],2))+
                    ' ±'+str(round(rec['ci95'],2)))
        if report.get('error'):lines.append('오류: '+report['error'])
        (folder/'RESULT_SUMMARY_KO_v032.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
        pack=archive_run(folder)
        print('[STATUS]',report['status']);print('[RESULT]',pack);print('[FOLDER]',folder)
        if os.name=='nt':
            try:os.startfile(str(folder))
            except (OSError,AttributeError):pass
        return 0 if report['status'] in ('OFFLINE_PLAN_PASS','PASS_BOUNDED_OMNIUM_NATIVE_DPS') else 2
    except Exception as e:
        print('[BLOCKED]',type(e).__name__,str(e),file=sys.stderr);return 2

if __name__=='__main__':raise SystemExit(main())
