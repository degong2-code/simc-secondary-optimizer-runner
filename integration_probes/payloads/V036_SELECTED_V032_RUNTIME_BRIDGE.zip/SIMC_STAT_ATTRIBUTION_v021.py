#!/usr/bin/env python3
"""v021: v020 actual JSON2 provenance and minimal explicit-consumable SimC probes.

The original v020 native snapshot is read-only. Neither a SimC 4-piece proof nor a
verified game-wide 334 budget or CHMV injection implementation is produced.
"""
from __future__ import annotations
import argparse, datetime as dt, hashlib, json, os, pathlib, subprocess, sys, uuid, zipfile

ROOT = pathlib.Path(__file__).resolve().parent
USER_V020 = ROOT/'EVIDENCE_V021_INPUTS'/'STANDARD_BUDGET_RESULTS_v020_USER_PC.zip'
BINARY_SHA = 'b0ea12ee3ac233a4a590609e2a5bd4c4db45c5f8ae6f8994b1b8d0de4d5acff4'
STATS = ('crit_rating','haste_rating','mastery_rating','versatility_rating')
SOURCE_SNAPSHOT_SHA = 'b3308abb046fcf22b316e41aa5a79a8e8d682cb05f58071f29b1345816e5801b'
DISABLED = {'flask':'disabled','food':'disabled','potion':'disabled','augmentation':'disabled','temporary_enchant':'disabled'}


def sha_bytes(b):return hashlib.sha256(b).hexdigest()
def sha_file(p):
    h=hashlib.sha256()
    with open(p,'rb') as fh:
        for b in iter(lambda:fh.read(1024*1024),b''):h.update(b)
    return h.hexdigest()
def save(path,obj):path.write_text(json.dumps(obj,indent=2,ensure_ascii=False,sort_keys=True)+'\n',encoding='utf-8')
def need(cond,message):
    if not cond:raise ValueError(message)


def load_baseline(src=USER_V020):
    need(pathlib.Path(src).is_file(),'V020_PC_RESULTS_MISSING')
    need(sha_file(src)==SOURCE_SNAPSHOT_SHA,'V020_PC_RESULTS_SHA_MISMATCH')
    with zipfile.ZipFile(src) as z:
        need(z.testzip() is None,'V020_BAD_ZIP_CRC')
        names=['native_standard_result.json','STANDARD_BUDGET_RECEIPT_v020.json','arcane_334_standard_probe.simc']
        need(all(n in z.namelist() for n in names),'V020_EVIDENCE_REQUIRED_FILES_MISSING')
        return json.loads(z.read(names[0])),json.loads(z.read(names[1])),z.read(names[2]).decode('utf-8')


def snapshot(doc, expect_base=True):
    player=doc['sim']['players'][0]
    gear=player['gear']
    per={k:sum(int(g.get(k,0) or 0) for slot,g in gear.items() if not slot.startswith('trinket')) for k in STATS}
    applied=player['collected_data']['buffed_stats']['stats']
    buffed={k:int(applied[k]) for k in STATS}
    delta={k:buffed[k]-per[k] for k in STATS}
    return {'gear_secondary':per,'gear_total':sum(per.values()),'buffed_rating':buffed,
            'buffed_minus_gear':delta,'flask':player.get('flask'),
            'food':player.get('food'),'potion':player.get('potion'),
            'augmentation':player.get('augmentation'),'temporary_enchant':player.get('temporary_enchant'),
            'item_identity':{slot:g.get('encoded_item','').split(',')[0:3] for slot,g in gear.items()},
            'simc_git_revision':doc.get('git_revision'), 'simc_build':doc['sim']['options']['dbc']['Live'].get('wow_version')}


def inspect(src=USER_V020):
    doc,receipt,profile=load_baseline(src)
    snap=snapshot(doc)
    native=receipt['native_pc_probe']['item_stat_receipt']
    need(receipt['native_pc_probe']['exit_code']==0,'PC_V020_EXECUTION_FAILED')
    need(native['native_level_identity_pass'],'PC_V020_ITEM_ID_OR_LEVEL_MISMATCH')
    need(native['native_gear_secondary_excluding_trinkets']==snap['gear_total'],'V020_RECEIPT_NATIVE_SUM_MISMATCH')
    need(native['nominal_gear_secondary']==2849,'V020_EXPECTED_NOMINAL_CHANGED')
    need(snap['gear_total']==2847,'V020_EXPECTED_NATIVE_CHANGED')
    need(snap['simc_git_revision']=='7bc1071','V020_GIT_REVISION_UNEXPECTED')
    return {'schema':'SimCStatAttributionOfflineReceipt-v021',
            'status':'V020_OBSERVED_DEFAULT_CONSUMABLES_NOT_NEUTRAL',
            'baseline_sha256':sha_file(src),
            'gear_budget_334_twohand_nominal':native['nominal_gear_secondary'],
            'gear_secondary_334_native':snap['gear_total'],
            'native_diff_from_nominal':snap['gear_total']-native['nominal_gear_secondary'],
            'default_stats':snap,
            'default_food_and_flask_auto_enabled':snap['flask']!='disabled' and snap['food']!='disabled',
            'expected_delta_annotation':'Default food and flask effects must be separated from the fixed G+J+F target; no exact attribution until controlled runs.',
            'native_gear_budget_validated_as_universal':False,
            'four_piece_effect_verified':False,
            'flask_gem_double_count_verified':False,
            'dps_optimization_performed':False,
            'policy_changes':[]},profile


def make_profile(original,out_json,variant):
    need(variant in ('neutral','flask_only'),'UNKNOWN_CASE')
    # Reuse precisely v020 character, talents, 15 item IDs, fixed 334 item level, APL and combat parameters.
    # Do not reintroduce user custom APL, proc-effective stat approximations or CHMV injection.
    raw=[]
    for line in original.splitlines():
        if line.strip().startswith('json2='):continue
        raw.append(line)
    settings=dict(DISABLED)
    if variant=='flask_only':settings['flask']='flask_of_the_blood_knights_2'
    raw.extend(f'{key}={val}' for key,val in settings.items())
    raw.append('json2='+str(out_json.resolve()))
    return '\n'.join(raw)+'\n'


def check_against_base(doc,origin):
    curr=snapshot(doc)
    need(curr['item_identity']==origin['item_identity'],'CHANGED_ITEM_IDENTITY')
    need(curr['gear_secondary']==origin['gear_secondary'],'CHANGED_GEAR_SECONDARY_WHEN_DISABLING_CONSUMABLES')
    return curr


def local_probe(executable,baseline_profile,base_snap,outdir):
    exe=pathlib.Path(executable).resolve()
    need(exe.is_file(),'SIMC_BINARY_MISSING')
    need(sha_file(exe)==BINARY_SHA,'SIMC_BINARY_HASH_MISMATCH')
    cases={}
    for var in ('neutral','flask_only'):
        json2=outdir/f'{var}.json'
        profile=outdir/f'{var}.simc'
        profile.write_text(make_profile(baseline_profile,json2,var),encoding='utf-8')
        try:
            run=subprocess.run([str(exe),str(profile)],capture_output=True,text=True,
                               encoding='utf-8',errors='replace',timeout=90)
            code=run.returncode; stdout=run.stdout;stderr=run.stderr
        except subprocess.TimeoutExpired as exc:
            code=None;stdout=str(exc.stdout or '');stderr=str(exc.stderr or '')+'\nTIMEOUT'
        (outdir/f'{var}_stdout.txt').write_text(stdout,encoding='utf-8')
        (outdir/f'{var}_stderr.txt').write_text(stderr,encoding='utf-8')
        res={'exit_code':code,'json2_created':json2.is_file()}
        if code==0 and json2.is_file():
            try:res['observed']=check_against_base(json.loads(json2.read_text(encoding='utf-8-sig')),base_snap)
            except (ValueError,TypeError,KeyError,IndexError) as ex:res['analysis_error']=str(ex)
        cases[var]=res
    n=cases['neutral'].get('observed'); f=cases['flask_only'].get('observed')
    if n and f:
        cases['flask_only_minus_neutral']={k:f['buffed_rating'][k]-n['buffed_rating'][k] for k in STATS}
        cases['neutral_minus_gear']={k:n['buffed_minus_gear'][k] for k in STATS}
    cases['both_runs_success']=(n is not None and f is not None)
    cases['four_piece_effect_verified']=False
    cases['free_chmv_injection_verified']=False
    return cases


def run(args):
    basereceipt,profile=inspect()
    root=pathlib.Path(args.output_root).resolve()
    out=root/('RUN_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ_')+uuid.uuid4().hex[:8])
    out.mkdir(parents=True,exist_ok=False)
    data={'schema':'SimCStatBoundaryReceipt-v021','status':'OFFLINE_V020_JSON2_ANALYZED','baseline':basereceipt,
          'simc_executed_new':False,'mode':args.mode,'local_probe':None,
          'four_piece_effect_verified':False,'native_334_budget_generalized':False,
          'user_settings_changed':False,'work_os_changed':False}
    save(out/'BASELINE_V020_STAT_ATTRIBUTION_v021.json',basereceipt)
    if args.mode=='local-probe':
        need(args.simc_executable is not None,'SIMC_BINARY_REQUIRED')
        data['local_probe']=local_probe(args.simc_executable,profile,basereceipt['default_stats'],out)
        data['simc_executed_new']=True
        data['status']='CONTROLLED_CONSUMABLE_PROBE_PASS' if data['local_probe']['both_runs_success'] else 'CONTROLLED_CONSUMABLE_PROBE_NEEDS_REVIEW'
    save(out/'STAT_ATTRIBUTION_RECEIPT_v021.json',data)
    zpath=out/'STAT_ATTRIBUTION_RESULTS_v021.zip'
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
        for path in sorted(out.iterdir()):
            if path.is_file() and path!=zpath:z.write(path,path.name)
    with zipfile.ZipFile(zpath) as z:need(z.testzip() is None,'OUTPUT_ZIP_BAD_CRC')
    print('[RESULT]',data['status'])
    print('[GEAR] nominal 2849, actual 2847; original default buffed +'+str(basereceipt['default_stats']['buffed_minus_gear']))
    if data['local_probe']:print('[PROBE]',data['local_probe'].get('flask_only_minus_neutral',{}))
    print('[RESULT_FILE]',str(zpath));print('[OUTPUT_FOLDER]',str(out))
    try:
        if os.name=='nt':os.startfile(str(out))
    except (OSError,AttributeError):pass
    return 0 if args.mode=='inspect' or data['local_probe']['both_runs_success'] else 2


def main():
    parser=argparse.ArgumentParser()
    parser.add_argument('--mode',choices=('inspect','local-probe'),default='inspect')
    parser.add_argument('--simc-executable',default=None)
    parser.add_argument('--output-root',default=str(ROOT/'V021_OUTPUTS'))
    args=parser.parse_args()
    try:return run(args)
    except (OSError,ValueError,KeyError,TypeError,zipfile.BadZipFile) as exc:
        print('[FAIL]',type(exc).__name__,str(exc));return 2

if __name__=='__main__':sys.exit(main())
