#!/usr/bin/env python3
"""v020: season snapshot-derived group CHMV budget + one Arcane Mage SimC local-data probe.

Not a validated itemlevel budget, stat injection method, complete character builder,
or authority to activate v016 VERIFIED_RAW interface. No WEQUIP runtime dependency.
"""
from __future__ import annotations
import argparse
import collections
import copy
import csv
import datetime as dt
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import uuid
import zipfile

import SCENARIO_CONTRACT_v016 as sc
import CHMV_ALLOCATION_PLAN_v017 as alloc

ROOT = Path(__file__).resolve().parent
MASTER = ROOT / 'SOURCE_SNAPSHOTS' / 'midnight_s2_master_gear_db_20260920_174943_optimizer_slots.json'
LOCAL_ZIP = ROOT / 'SOURCE_SNAPSHOTS' / 'V018_USER_LOCAL_PROBE_20261023.zip'
PINNED_BINARY_SHA256 = 'b0ea12ee3ac233a4a590609e2a5bd4c4db45c5f8ae6f8994b1b8d0de4d5acff4'
LEVELS = (321, 331, 334)
STATS = ('crit_rating', 'haste_rating', 'mastery_rating', 'versatility_rating')
GEAR_GROUP = {'head':'G1', 'neck':'G4', 'shoulders':'G2', 'back':'G3', 'chest':'G1',
              'wrists':'G3', 'hands':'G2', 'waist':'G2', 'legs':'G1', 'feet':'G2',
              'finger1':'G5', 'finger2':'G5', 'main_hand':'G6', 'off_hand':'G6'}
ALL_STYLES = ('TWO_HAND', 'DUAL_WIELD', 'ONE_HAND_OFFHAND', 'ONE_HAND_SHIELD')
# Known tier-piece identities were directly observed in v018 local SimC JSON2 at 334.
ARCANE_TIER4_IDS = {'head':271564, 'shoulders':271562, 'chest':271567, 'legs':271563}
# Only the two trinket identities/slot assignments are carried from prior actual local observations.
ARCANE_TRINKET_IDS = {'trinket1':250215, 'trinket2':281215}
STANDARD_MAGE_CLASS = {'mage', 'spec', 'level', 'race', 'role', 'position', 'talents', 'omnium_talents'}


def require(ok, msg):
    if not ok: raise ValueError(msg)


def strict_load(path):
    return sc.load_strict(Path(path))


def h256(path):
    return sc.sha(Path(path))


def write(path, value):
    sc.write_json(Path(path), value)


def load_master(path=MASTER):
    obj = strict_load(path)
    require(obj.get('season') == 'Midnight Season 2', 'WRONG_MASTER_SEASON')
    require(obj.get('database_type') == 'master_gear_db', 'NOT_A_MASTER_GEAR_DB')
    require(type(obj.get('items')) is dict and bool(obj['items']), 'MASTER_ITEMS_MISSING')
    items = obj['items']
    require(all(type(x.get('item_id')) is int and type(x.get('budget_group')) is str for x in items.values()), 'INVALID_MASTER_ITEM')
    require(set(obj.get('target_item_levels', [])) >= set(LEVELS), 'LEVELS_NOT_COVERED')
    return obj


def get_group_consensus(master, levels=None):
    """Uses secondary_budget_full only; never misuses actual special-effect secondary_total.

    Includes no trinket G7 in the freely allocatable budget.
    """
    levels = levels or master['target_item_levels']
    result = {}
    for level in levels:
        require(type(level) is int and 1 <= level <= 2000, 'BAD_LEVEL')
        groups = collections.defaultdict(list)
        for key, row in master['items'].items():
            gr = row.get('budget_group')
            if gr not in ('G1','G2','G3','G4','G5','G6'): continue
            data = row.get('scaled_stats', {}).get(str(level))
            require(type(data) is dict, 'MISSING_LEVEL_SCALED_STATS:'+key+':'+str(level))
            amount = data.get('secondary_budget_full')
            require(type(amount) is int and amount >= 0, 'INVALID_FULL_BUDGET:'+key)
            groups[gr].append((row['item_id'], amount))
        require(set(groups)=={'G1','G2','G3','G4','G5','G6'}, 'SLOT_GROUP_INCOMPLETE')
        result[str(level)] = {}
        for gr, observations in groups.items():
            values = sorted(set(v for _, v in observations))
            require(len(values)==1, 'GROUP_BUDGET_NONUNIFORM:'+str(level)+':'+gr+':'+str(values))
            result[str(level)][gr] = {'secondary_budget_full':values[0], 'item_count':len(observations)}
        require(abs(result[str(level)]['G4']['secondary_budget_full']-result[str(level)]['G5']['secondary_budget_full'])<=1,
                'NECK_RING_BUDGET_DISAGREEMENT_OVER_ROUNDING_TOLERANCE:'+str(level))
    return result


def slots_for_style(level, style, consensus):
    require(style in ALL_STYLES, 'UNKNOWN_WEAPON_STYLE')
    groups = consensus[str(level)]
    slots={slot:groups[grp]['secondary_budget_full'] for slot,grp in GEAR_GROUP.items() if slot != 'off_hand'}
    weapon_full=groups['G6']['secondary_budget_full']
    if style=='TWO_HAND':
        slots['main_hand']=weapon_full
    else:
        # WEQUIP scaled nominal floor half; 1H+OH applies two independently rounded half-budgets.
        half=weapon_full//2
        slots['main_hand']=half
        slots['off_hand']=half
    return slots


def make_budget_snapshot(master, master_path=MASTER):
    consensus=get_group_consensus(master)
    levels={}
    for lev in master['target_item_levels']:
        levels[str(lev)]={}
        for style in ALL_STYLES:
            slots=slots_for_style(lev,style,consensus)
            levels[str(lev)][style]={'gear_rating_nominal':sum(slots.values()), 'slot_budgets':slots,
                                     'trinkets_included':False,'basis':'SOURCE_WEQUIP_SCALED_SECONDARY_BUDGET_FULL'}
    return {'schema':'CHMVGroupBudgetCandidate-v020','status':'CANDIDATE_NOT_SIMC_NATIVE_VERIFIED',
            'source_master_sha256':h256(master_path),'source_master_created_at':master.get('created_at'),
            'season':'Midnight Season 2','source_scope':'RAID_MPLUS_DELVE_LAIR_20260920',
            'levels':levels,'consensus':consensus,
            'notes':['Full group budgets are WEQUIP-derived nominal numbers, not native SimC measurements.',
                     'Actual secondary_total may be zero on exceptional gear, including some trinkets/armor/offhands.',
                     'One-hand secondary half-budgets are rounded separately; native stats can differ by 1-2 per slot; neck/ring differ by 1 at some levels.',
                     'Flask 165 is a pilot value, not season-wide native validation.',
                     'These data cannot be labeled VERIFIED_RAW or used as v016 verified table automatically.'],
            'simc_executed':False,'dps_measured':False}


def inspect_native_v018(archive=LOCAL_ZIP, expected_master=None):
    """Historical independent observation; not a new run and not a purified representative profile."""
    require(Path(archive).is_file(),'V018_LOCAL_PROBE_ARCHIVE_MISSING')
    with zipfile.ZipFile(archive) as z:
        require(z.testzip() is None, 'BAD_V018_CRC')
        observed={}
        for lev in LEVELS:
            data=json.loads(z.read(f'LOCAL_ITEMLEVEL_{lev}/result.json'))
            player=data['sim']['players'][0]
            details=[]
            for slot, row in player['gear'].items():
                if slot not in GEAR_GROUP:continue
                actual=sum(int(row.get(key,0) or 0) for key in STATS)
                item_id=None
                for token in row.get('encoded_item','').split(','):
                    if token.startswith('id='):item_id=int(token[3:])
                details.append({'slot':slot,'item_id':item_id,'ilevel':row.get('ilevel'),
                                'actual_secondary_in_json2':actual, 'secondaries':{k:row.get(k,0) for k in STATS},
                                'zero_secondary':actual==0})
            observed[str(lev)]=details
    return {'schema':'HistoricalNativeObservation-v020','origin_archive_sha256':h256(archive),
            'status':'HISTORICAL_LOCAL_JSON2_SLOTS_ONLY_NOT_BUDGET_PROOF','levels':observed,
            'warnings':['v018 gear includes existing special items and unconventional no-secondary slots',
                        'It cannot prove a complete representative standard profile or valid 4pc item semantics.']}


def select_arcane_profile_items(master):
    items=list(master['items'].values())
    def select(slot,subclass=None,weapon=None,exclude=()):
        choices=[]
        for x in items:
            if x.get('slot') != slot or bool(x.get('spells')): continue
            if subclass is not None and x.get('item_subclass_name') != subclass:continue
            if weapon is not None and x.get('weapon_budget_type') != weapon:continue
            budget=x.get('scaled_stats',{}).get('334',{}).get('secondary_total_nominal')
            if type(budget) is not int or budget<=0: continue
            if x['item_id'] in exclude:continue
            choices.append(x)
        require(bool(choices),'NO_STANDARD_ITEM_FOR_SLOT:'+slot)
        src={'raid':0,'mplus':1,'delve':2,'lair':3}
        choices.sort(key=lambda x:(src.get(x['source_type'],4),x['item_id']))
        return choices[0]
    picked={}
    sources={}
    for slot,item_id in ARCANE_TIER4_IDS.items():
        picked[slot]=item_id
        sources[slot]='HISTORICAL_SIMC_V018_NATIVE_334_TIER_IDENTITY'
    choice_map={
        'neck':('NECK',None,None), 'back':('CLOAK','Cloth',None),
        'wrists':('WRIST','Cloth',None),'hands':('HAND','Cloth',None),
        'waist':('WAIST','Cloth',None), 'feet':('FEET','Cloth',None),
        'finger1':('FINGER',None,None),'finger2':('FINGER',None,None),
        'main_hand':('TWOHWEAPON','Staff','two_hand'),
    }
    chosen_ids=set(picked.values())
    for slot,(master_slot,subclass,weapon) in choice_map.items():
        x=select(master_slot,subclass,weapon,chosen_ids)
        picked[slot]=x['item_id']; chosen_ids.add(x['item_id'])
        sources[slot]='SEPT20_WEQUIP_MASTER_ITEM_ID_EFFECTS_LIST_EMPTY'
    picked.update(ARCANE_TRINKET_IDS)
    for slot in ARCANE_TRINKET_IDS:
        sources[slot]='HISTORICAL_SIMC_V018_NATIVE_334_TRINKET_IDENTITY'
    require(len(picked)==15 and len(chosen_ids)==13,'STANDARD_ARCANE_SLOT_COVERAGE_INCORRECT')
    return picked,sources


def make_arcane_profile(master, json_file, ilvl=334):
    require(ilvl in master['target_item_levels'], 'ARCANE_TARGET_LEVEL_NOT_COVERED')
    picked,sources=select_arcane_profile_items(master)
    # Keep only character/talent settings from previously executed pilot, not its handwritten APL
    # or consumption, trinket adjustments, gear-rating injection and potion/flask double count.
    lines=[
        'mage="V020_Arcane_Standard_Probe"',
        'source=default', 'spec=arcane', 'level=90', 'race=void_elf', 'role=spell',
        'talents=C4DAAAAAAAAAAAAAAAAAAAAAAYGGLzMzswMDamZGAAAGAAEwMzMLLzMxCAAwMzMjNLzMzsMjxYmZwCzYmZGAgBAAYmZBAMDAGmZG',
        'omnium_talents=136822:1/136817:1/136821:1/136814:1',
        '# No custom action list: SimC default class APL',
        '# Four selected tier item IDs; set bonus actual application is not yet verified',
        '# Item-level override is a native lookup experiment, NOT a real drop-level statement',
    ]
    order=['head','neck','shoulders','back','chest','wrists','hands','waist','legs','feet','finger1','finger2','trinket1','trinket2','main_hand']
    for slot in order:
        iid=picked[slot]
        lines.append(f'{slot}=v020_{slot}_{iid},id={iid},ilevel={ilvl},source=local')
    lines += ['', 'item_db_source=local', 'desired_targets=1', 'fight_style=Patchwerk',
              'iterations=1', 'threads=1', 'fixed_time=1', 'max_time=5','vary_combat_length=0',
              'calculate_scale_factors=0', 'json2='+str(Path(json_file).resolve())]
    return '\n'.join(lines)+'\n',picked,sources


def native_profile_receipt(doc, picked, level, budget):
    """Structural and per-slot CHMV check; does not assess DPS or effect semantics."""
    player=doc['sim']['players'][0]
    native=player.get('gear',{})
    expected=budget['levels'][str(level)]['TWO_HAND']['slot_budgets']
    details=[]; errors=[]; total=0
    for slot,pid in picked.items():
        row=native.get(slot)
        if not isinstance(row,dict):
            errors.append('MISSING_SLOT:'+slot);continue
        actual_id=None
        for s in row.get('encoded_item','').split(','):
            if s.startswith('id='):actual_id=int(s[3:])
        if actual_id!=pid:errors.append('ITEM_ID_MISMATCH:'+slot)
        if row.get('ilevel')!=level:errors.append('ILEVEL_MISMATCH:'+slot)
        secs={k:int(row.get(k,0) or 0) for k in STATS}
        rating=sum(secs.values())
        if slot not in ('trinket1','trinket2'):total+=rating
        ref=expected.get(slot)
        details.append({'slot':slot,'item_id':actual_id,'target_level':level,'observed_level':row.get('ilevel'),
                        'native_secondary':rating,'nominal_reference':ref,'delta':rating-ref if ref is not None else None,
                        'outside_free_budget':slot.startswith('trinket'),'native_secondary_breakdown':secs})
    matched_ids=not errors
    native_full=matched_ids and len(details)==len(picked)
    # Only checks summed static base; no actual flask, gems, enchants or full stats injection.
    return {'schema':'SimCStandardProfileProbeReceipt-v020','status':'LOOKUP_IDENTITIES_MATCH' if native_full else 'LOOKUP_INCOMPLETE',
            'slots':details,'native_gear_secondary_excluding_trinkets':total,
            'nominal_gear_secondary':sum(expected.values()),
            'nominal_minus_native_secondary':sum(expected.values())-total,
            'identity_or_level_errors':errors,'native_level_identity_pass':native_full,
            'standard_profile_completed':False,'four_piece_effect_verified':False,
            'flask_and_gems_injection_verified':False,'dps_optimization_performed':False}


def provisional_seeds(snapshot, ilvl=334, style='TWO_HAND', gem=138, flask=165):
    slots=snapshot['levels'][str(ilvl)][style]['slot_budgets']
    gear=sum(slots.values());total=gear+gem+flask
    budget={'budget_resolved':True,'total':total,'gear':gear,'general_gems':gem,'flask':flask,
            'minimum_absolute_inclusive':{k:0 for k in sc.STAT_KEYS},
            'maximum_absolute_inclusive':{k:total//2 for k in sc.STAT_KEYS},
            'locked_special_secondary':{k:0 for k in sc.STAT_KEYS},'locked_special_total':0,'flexible_rating_pool':total}
    seeds=alloc.diverse_seeds(budget,max_seeds=20,diversity_fraction=0.1)
    return {'schema':'CHMVProvisionalSeedPreview-v020','status':'PROVISIONAL_BUDGET_SEEDS_NOT_FOR_DPS',
            'target_level':ilvl,'weapon_style':style,'model_gear_rating':gear,
            'general_gems_assumed':gem,'flask_assumed_universal_unverified':flask,'model_chmv_total':total,
            'candidates':[{'label':x['seed_label'],'vector':dict(zip(sc.STAT_KEYS,x['vector']))} for x in seeds],
            'v016_verified_budget_table_issued':False,'simc_executed':False,'dps_measured':False,
            'warnings':['Sample outputs are not actual DPS-optimized distributions.',
                        '4pc, exact native slot stats, fixed equipment, actual gem/flask representation and double count remain unresolved.']}



def light_season_catalog(master, delta_path=ROOT / 'INPUT_SEASON_DELTA' / 'WEQUIP_MIDNIGHT_S2_12_1_5_FARMABLE_ITEMS_PARTIAL_20261023_v1.json'):
    """Read-only source-aware list; ordinary gear is not used in search."""
    delta=strict_load(delta_path)
    require(delta.get('completeness')=='PARTIAL__DO_NOT_TREAT_AS_COMPLETE_SEASON_ITEMS','DELTA_SCOPE_CHANGED')
    catalog={}
    for source_key,item in master['items'].items():
        iid=item['item_id']
        key=str(iid)
        base=catalog.setdefault(key, {'item_id':iid,'name':item['name'],'slot':item.get('slot'),
                        'classification':'TRINKET' if item.get('slot')=='TRINKET' else
                                         ('SPELL_METADATA_CANDIDATE' if item.get('spells') else 'ORDINARY_OR_UNCLASSIFIED'),
                        'source_records':[],'first_available_in_snapshot':'2026-09-20_BASELINE'})
        base['source_records'].append({'record_id':source_key,'source_type':item.get('source_type'),
                            'sources':item.get('sources',[]),'source_date':'2026-09-20'})
    old_count=len(catalog)
    for item in delta['items']:
        key=str(item['item_id'])
        require(key not in catalog,'DELTA_ID_ALREADY_IN_BASELINE:'+key)
        category='TRINKET' if item['category']=='TRINKET' else 'SPECIAL_EFFECT_CANDIDATE_FROM_PUBLIC_SOURCE'
        catalog[key]={'item_id':item['item_id'],'name':item['name_en'],'slot':item['slot'],
                      'classification':category,'first_available_in_snapshot':'12.1.5_KITHIX_DELTA',
                      'source_records':[{'source_type':item['source_family'],
                                        'instance':item['instance'],'encounter':item['encounter'],
                                        'acquisition_status':item['acquisition_status'],
                                        'item_page':item['item_page']}] }
    require(old_count==394 and len(catalog)==404,'UNEXPECTED_BASELINE_DELTA_COUNTS')
    return {'schema':'LightSeasonSources-v020','status':'SELECTED_PVE_SOURCE_SCOPE_NOT_ALL_SEASON_ACQUISITION',
            'total_unique_items':len(catalog),'baseline_unique_items':old_count,'kithix_delta_items':len(delta['items']),
            'sources_included':['VENOMOUS_ABYSS_RAID','SEASON2_MPLUS','DELVE','TIDEBOUND_GROTTO_LAIR','KITHIX_RAID_DELTA'],
            'intentionally_excluded':['KINDOJAN_LABYRINTH','AQIR_INVASIONS','GENERAL_CRAFTED_ITEMS','LOW_LEVEL_WORLD_DROPS'],
            'classification_note':'Spell metadata presence is not a SimC special-effect support guarantee.',
            'items':sorted(catalog.values(),key=lambda x:x['item_id'])}


def write_light_csv(path,cat):
    with Path(path).open('w',newline='',encoding='utf-8-sig') as fh:
        wr=csv.writer(fh)
        wr.writerow(['item_id','name','slot','classification','first_available_in_snapshot','sources'])
        for item in cat['items']:
            wr.writerow([item['item_id'],item['name'],item['slot'],item['classification'],
                         item['first_available_in_snapshot'],
                         ';'.join(s.get('source_type','') for s in item['source_records'])])

def run_probe(executable, profile, picked, level, snapshot, out_dir,timeout=90):
    exe=Path(executable).resolve()
    require(exe.is_file(),'SIMC_BINARY_MISSING')
    require(h256(exe)==PINNED_BINARY_SHA256,'SIMC_BINARY_SHA256_MISMATCH')
    input_file=out_dir/'arcane_334_standard_probe.simc'
    input_file.write_text(profile,encoding='utf-8')
    rawfile=out_dir/'native_standard_result.json'
    try:
        p=subprocess.run([str(exe),str(input_file)],capture_output=True,text=True,
                         encoding='utf-8',errors='replace',timeout=timeout)
        ret=p.returncode; stdout=p.stdout;stderr=p.stderr
    except subprocess.TimeoutExpired as ex:
        ret=None;stdout=str(ex.stdout or '');stderr=str(ex.stderr or '')+'\nTIMEOUT'
    (out_dir/'simc_stdout.txt').write_text(stdout,encoding='utf-8')
    (out_dir/'simc_stderr.txt').write_text(stderr,encoding='utf-8')
    receipt={'mode':'LOCAL_ONLY_1_ITERATION_5S_METADATA_PROBE','binary_sha256':h256(exe),
             'exit_code':ret,'native_json2_created':rawfile.is_file(),
             'item_stat_receipt':None,'executable':str(exe)}
    if rawfile.is_file():
        try:
            native=json.loads(rawfile.read_text(encoding='utf-8-sig'))
            receipt['item_stat_receipt']=native_profile_receipt(native,picked,level,snapshot)
        except (ValueError,TypeError,IndexError,KeyError) as ex:
            receipt['json2_error']=type(ex).__name__+':'+str(ex)
    return receipt


def run(mode,output, master_path=MASTER, simc_executable=None,ilvl=334):
    require(mode in ('inspect','local-probe'),'UNKNOWN_MODE')
    master=load_master(master_path)
    snap=make_budget_snapshot(master,master_path)
    obs=inspect_native_v018()
    preview=provisional_seeds(snap,ilvl,'TWO_HAND')
    catalog=light_season_catalog(master)
    profile_file=(output/'native_standard_result.json').resolve()
    profile,items,source=make_arcane_profile(master,profile_file,ilvl)
    output.mkdir(parents=True,exist_ok=False)
    write(output/'GROUP_CHMV_BUDGET_CANDIDATE_v020.json',snap)
    write(output/'SEASON_SOURCE_CATALOG_v020.json',catalog)
    write_light_csv(output/'SEASON_SOURCE_CATALOG_v020.csv',catalog)
    write(output/'V018_HISTORICAL_NATIVE_COMPARISON_v020.json',obs)
    write(output/'PROVISIONAL_CHMV_SEEDS_v020.json',preview)
    (output/'arcane_334_standard_probe.simc').write_text(profile,encoding='utf-8')
    selected={'schema':'SimCStandardGearSelection-v020','status':'CANDIDATE_NOT_REPRESENTATIVE_VALIDATED',
              'ilevel':ilvl,'weapon_style':'TWO_HAND','class':'mage','spec':'arcane',
              'tier_set_4pc_id_candidates':ARCANE_TIER4_IDS,'selected_slot_item_ids':items,
              'source_provenance':source,'simc_default_apl_requested':True,
              'selected_trinkets_fixed_outside_chmv_budget':True,
              'all_item_effects_in_simc_verified':False, 'four_piece_effect_verified':False}
    write(output/'ARCANE_334_PROFILE_SELECTION_v020.json',selected)
    record={'schema':'StandardGearBudgetReceipt-v020','status':'OFFLINE_BUDGET_CANDIDATE_ONLY',
            'baseline_master_records':len(master['items']),
            'baseline_master_unique_ids':len({x['item_id'] for x in master['items'].values()}),
            'baseline_master_created_at':master['created_at'],
            'master_sha256':h256(master_path),'v018_local_probe_zip_sha256':h256(LOCAL_ZIP),
            'external_wequip_runtime_dependency':False,
            'catalog_unique_items_after_kithix':catalog['total_unique_items'],
            'excluded_activities':['KINDOJAN_LABYRINTH','AQIR_INVASIONS','CRAFTED_ITEM_COLLECTION','WORLD_QUESTS'],
            'g_334_twohand_nominal':snap['levels']['334']['TWO_HAND']['gear_rating_nominal'],
            't_334_twohand_138_plus_165_assumption':preview['model_chmv_total'],
            'source_group_consensus_pass':True,'native_profile_completed':False,
            'validated_budget_export_created':False,'simc_executed':False,'real_dps_calculated':False,
            'native_pc_probe':None}
    if mode=='local-probe':
        require(bool(simc_executable),'SIMC_EXECUTABLE_REQUIRED_FOR_PROBE')
        result=run_probe(simc_executable,profile,items,ilvl,snap,output)
        record['native_pc_probe']=result
        record['simc_executed']=True if result['exit_code'] is not None else False
        record['status']='LOCAL_NATIVE_PROBE_ATTEMPTED_NOT_OPTIMIZATION'
    write(output/'STANDARD_BUDGET_RECEIPT_v020.json',record)
    zpath=output/'STANDARD_BUDGET_RESULTS_v020.zip'
    with zipfile.ZipFile(zpath,'w',zipfile.ZIP_DEFLATED) as z:
        for p in sorted(output.iterdir()):
            if p.is_file() and p != zpath:z.write(p,p.name)
    require(zipfile.ZipFile(zpath).testzip() is None,'OUTPUT_ZIP_BAD_CRC')
    return record,zpath


def main(argv=None):
    p=argparse.ArgumentParser(description='v020 read-only group budget model and optional pinned SimC local profile lookup')
    p.add_argument('--mode',choices=('inspect','local-probe'),default='inspect')
    p.add_argument('--simc-executable',default=None)
    p.add_argument('--master',type=Path,default=MASTER)
    p.add_argument('--itemlevel',type=int,default=334)
    p.add_argument('--output-root',type=Path,default=ROOT/'V020_OUTPUTS')
    args=p.parse_args(argv)
    root=args.output_root.resolve()
    output=root/('RUN_'+dt.datetime.now(dt.timezone.utc).strftime('%Y%m%dT%H%M%S_%fZ_')+uuid.uuid4().hex[:8])
    try:
        receipt,zpath=run(args.mode,output,args.master,args.simc_executable,args.itemlevel)
        failed = (args.mode=='local-probe' and (receipt['native_pc_probe']['exit_code']!=0 or
                  not receipt['native_pc_probe']['native_json2_created'] or
                  not receipt['native_pc_probe'].get('item_stat_receipt',{}).get('native_level_identity_pass',False)))
        print('['+('REVIEW' if failed else 'PASS')+'] '+receipt['status'])
        print('[334 2H] Nominal G='+str(receipt['g_334_twohand_nominal'])+', assumed T='+str(receipt['t_334_twohand_138_plus_165_assumption']))
        print('[ZIP] '+str(zpath))
        code=2 if failed else 0
    except (OSError,ValueError,KeyError,TypeError,json.JSONDecodeError,zipfile.BadZipFile) as ex:
        print('[DENIED] '+type(ex).__name__+':'+str(ex))
        print('[OUTPUT_ROOT] '+str(root))
        code=2
    finally:
        try:
            if os.name=='nt' and root.exists():os.startfile(str(output if output.exists() else root))
        except (OSError,AttributeError):pass
    return code

if __name__ == '__main__':sys.exit(main())
