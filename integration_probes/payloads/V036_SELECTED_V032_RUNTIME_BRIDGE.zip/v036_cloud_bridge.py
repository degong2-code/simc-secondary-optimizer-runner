#!/usr/bin/env python3
"""Exact-source v032 cloud adapter: preserve imported original source bytes.

The original v032 Windows SimC SHA lock is replaced IN MEMORY ONLY after checking
that the cloud binary is a previously verified Linux build. Derived provenance
ZIP archives remove local Windows output path lines only, preserving JSON2.
"""
from __future__ import annotations
import argparse, hashlib, json, pathlib, sys, zipfile, os
ROOT=pathlib.Path(__file__).resolve().parent
LINUX_BIN_SHA='64089f2f917d552ab392ba311d128aa1b7ec559ead52b3546e2cc328ab479b8e'
SIMC_COMMIT='7bc10711b5a4514066fa402ca0a71c9ba4b7c9dd'
BUNDLE_ORIGINAL_SHA='072a18d24d37770d454a35ece1cb2a3d1b72624655c32e46dc4f2fc551a6968b'
def hash_file(p):
    h=hashlib.sha256()
    with pathlib.Path(p).open('rb') as f:
        for b in iter(lambda:f.read(1048576),b''):h.update(b)
    return h.hexdigest()
def validate():
    prov=json.loads((ROOT/'V036_PROVENANCE.json').read_text(encoding='utf-8'))
    assert prov['source_original_zip_sha256']==BUNDLE_ORIGINAL_SHA,'ORIGINAL_V032_PACKAGE_IDENTITY_CHANGED'
    assert prov['original_manifest_verified']==191, 'MISSING_SOURCE_MANIFEST_PROOF'
    for name,sha in prov['source_code_original_files'].items():
        assert hash_file(ROOT/name)==sha,'V032_SOURCE_CODE_CHANGED:'+name
    for name,rec in prov['derived_evidence'].items():
        assert hash_file(ROOT/name)==rec['derived_sha256'],'DERIVED_EVIDENCE_CHANGED:'+name
        with zipfile.ZipFile(ROOT/name) as z:
            assert z.testzip() is None, 'DERIVED_EVIDENCE_CRC_MISMATCH'
            for info in z.infolist():
                if info.filename.endswith('.json') and info.filename.startswith(('DPS_NATIVE/','override_primary')):
                    assert z.getinfo(info.filename).file_size>1000
                raw=z.read(info)
                assert b'C:\\Users\\' not in raw,'PRIVATE_WINDOWS_PATH_LEAK'
    return prov

def configure():
    prov=validate()
    sys.path.insert(0,str(ROOT))
    import SIMC_OMNIUM_CHMV_ADAPTIVE_v032 as m
    import CHMV_DPS_INTEGRATION_v028 as r28
    key28='EVIDENCE_V028_INPUTS/GEM_NATIVE_PROBE_RESULTS_v027_USER_PC.zip'
    key32='EVIDENCE_V032_INPUTS/EMBELLISH_ENCHANT_RESULTS_v031R3_USER_PC.zip'
    r28.EVIDENCE=ROOT/key28
    r28.EVIDENCE_SHA=prov['derived_evidence'][key28]['derived_sha256']
    m.EVIDENCE=ROOT/key32
    m.EVIDENCE_SHA=prov['derived_evidence'][key32]['derived_sha256']
    # Leave original source SHA checks as file-level immutable evidence.
    assert len(prov['source_code_original_files'])==17
    assert m.TOTAL==3184 and m.STATIC_GEAR==2849 and m.OIL==(16,16,0,0)
    assert m.RUNE_IDS['crit']==136815
    return m,prov

def main(argv=None):
    p=argparse.ArgumentParser()
    p.add_argument('--mode',choices=('plan','native-probe','native-full'),default='plan')
    p.add_argument('--binary',type=pathlib.Path)
    p.add_argument('--output',type=pathlib.Path,required=True)
    p.add_argument('--scout-iterations',type=int,default=60)
    p.add_argument('--confirm-iterations',type=int,default=150)
    args=p.parse_args(argv)
    m,prov=configure()
    args.output.mkdir(parents=True,exist_ok=True)
    if args.mode=='plan':
        proof=m.load_calibration_evidence()
        src=m.native_source(rune='crit')
        out=[]
        for index,vec in enumerate(m.seeds()):
            text,meta=m.make_profile(src,args.output/f'preview{index+1}.json',vec,args.scout_iterations)
            (args.output/f'preview{index+1}.simc').write_text(text,encoding='utf-8')
            out.append({'vector':vec,'input_sha256':hashlib.sha256(text.encode()).hexdigest()})
        (args.output/'V036_PLAN_RECEIPT.json').write_text(json.dumps({'status':'PASS_OFFLINE_ONLY','scouts':out,'budget':proof['final_total'],'original_v032_sha256':BUNDLE_ORIGINAL_SHA},indent=2)+'\n')
        print('V036_PLAN_PASS',len(out),'original v032 source unchanged')
        return 0
    assert args.binary and args.binary.is_file(),'BINARY_MISSING'
    assert hash_file(args.binary)==LINUX_BIN_SHA,'PINNED_LINUX_SIMC_BINARY_MISMATCH'
    m.r3.EXPECTED_SIMC_SHA=LINUX_BIN_SHA
    from datetime import datetime, timezone
    receipt={'schema':'v036_original_v032_cloud_bridge','stage':args.mode,'original_v032_sha256':BUNDLE_ORIGINAL_SHA,
             'binary_sha256':LINUX_BIN_SHA,'simc_commit':SIMC_COMMIT,
             'source_files':17,'derived_evidence_not_original':True,'status':'ATTEMPTED'}
    (args.output/'V036_BRIDGE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    if args.mode=='native-probe':
        root=args.output/'scout01'
        src=m.native_source(rune='crit')
        proof=m.load_calibration_evidence()
        assert proof['final_total']==3184
        r=m.run_case(args.binary.resolve(),root,src,m.seeds()[0],args.scout_iterations,'crit')
        assert r['status']=='NATIVE_STATS_AND_RUNE_PASS'
        receipt.update(status='PASS_NATIVE_ONE_SCOUT',result=r,completed_utc=datetime.now(timezone.utc).isoformat())
        (args.output/'V036_BRIDGE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
        print('V036_NATIVE_PROBE_PASS',r['dps'])
        return 0
    assert 60<=args.scout_iterations<=600 and 150<=args.confirm_iterations<=1000
    rc=m.main(['--mode','local-probe','--rune','crit','--gem-choice','primary23_four_colors',
               '--scout-iterations',str(args.scout_iterations),'--confirm-iterations',str(args.confirm_iterations),
               '--simc-executable',str(args.binary.resolve()),'--output-root',str(args.output/'native_full')])
    receipt.update(status='PASS_FULL_ADAPTIVE_PILOT' if rc==0 else 'BLOCKED_OR_PARTIAL',return_code=rc)
    (args.output/'V036_BRIDGE_RECEIPT.json').write_text(json.dumps(receipt,indent=2)+'\n')
    print('V036_FULL_STATUS',receipt['status'])
    return rc
if __name__=='__main__':
    raise SystemExit(main())
